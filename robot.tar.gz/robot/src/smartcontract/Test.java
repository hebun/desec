package smartcontract;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.web3j.contracts.token.ERC20BasicInterface;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.core.Request;
import org.web3j.protocol.core.methods.response.EthAccounts;
import org.web3j.protocol.core.methods.response.EthBlockNumber;
import org.web3j.protocol.core.methods.response.EthGasPrice;
import org.web3j.protocol.core.methods.response.EthGetBalance;
import org.web3j.protocol.core.methods.response.Web3ClientVersion;
import org.web3j.protocol.http.HttpService;

public class Test {
	private Web3j web;

	public EthAccounts getEthAccounts() {
		EthAccounts result = new EthAccounts();
		try {
			result = this.web.ethAccounts().sendAsync().get();
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public static void main(String[] args) {
		Test test = new Test();
		test.run();
	}

	public void run() {
		web = Web3j.build(new HttpService("http://127.0.0.1:8545"));
		try {
			EthAccounts accs = web.ethAccounts().send();
			// accs.
			List<String> accounts = accs.getAccounts();

			for (String string : accounts) {
				System.out.println(string);
			}
			EthGetBalance bal = web
					.ethGetBalance("0xA91AFb5b5021ccd3737A83364B3eD851d67B8A09", DefaultBlockParameterName.LATEST)
					.send();
			System.out.println("bal:" + bal.getBalance());

			// web.e

			// web.ethgetc
			// web3_clientVersion returns the current client version.
			Web3ClientVersion clientVersion = web.web3ClientVersion().send();

			// eth_blockNumber returns the number of most recent block.
			EthBlockNumber blockNumber = web.ethBlockNumber().send();

			// eth_gasPrice, returns the current price per gas in wei.
			EthGasPrice gasPrice = web.ethGasPrice().send();

			System.out.println("Client version: " + clientVersion.getWeb3ClientVersion());
			System.out.println("Block number: " + blockNumber.getBlockNumber());
			System.out.println("Gas price: " + gasPrice.getGasPrice());

		} catch (IOException ex) {
			throw new RuntimeException("Error whilst sending json-rpc requests", ex);
		}
	}
}
