package fullbot;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.stage.Stage;

public class Launcher extends Application {

	@Override
	public void start(Stage stage) throws Exception {

		stage.setOnShown(e -> {

			BotView view;
			view = new BotView();
			stage.setScene(view.getScene());
			view.onShown();
			Bot bot = new Bot(view);
			bot.start();
		});

	
		stage.setOnCloseRequest(e -> {

			System.out.println("on close");
			System.exit(0);

		});


		stage.setTitle("Bot");
		stage.show();
		
	}

	@Override
	public void init() throws Exception {
		// Springc
		super.init();

	}

	public static void main(String[] args) {
		
		launch(args);
	}
}
