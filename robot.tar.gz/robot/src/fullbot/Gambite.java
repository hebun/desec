package fullbot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Observer;

import javax.swing.SwingUtilities;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.cef.callback.CefStringVisitor;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import betting.BotBrowser;
import betting.BuroBase;
import bettingutil.Mac;
import util.Pro;
import util.Util;

/**
 * bug names with numbers
 * 
 * @author lazyCoding
 *
 */
public class Gambite extends BuroBase {
	public Gambite() {
		// TODO Auto-generated constructor stub
	}

	public List<Mac> parse(String content) {
		Document doc = Jsoup.parse(content);
		Elements select = doc.select("div[data-iframe-height]");
		ArrayList<Mac> macs = new ArrayList<Mac>();
		for (int i = 0; i < select.size(); i++) {
			Element element = select.get(i);
			Elements children = element.children();
			System.out.println(children.size());
			for (Element ele : children) {
				if (ele.tagName().equals("div")) {
					if (!ele.hasAttr("class")) {

						String macline = ele.text();

						if (!macline.contains("US Orleans 45")) {

							Mac mac = getMac(macline);
							if (mac != null)
								macs.add(mac);
						}
					}
				}
			}
		}
		return macs;
	}

	public String getUrl() {
		return "https://start.gambite.me/2ee121b4/1?lang=en&brand_id=1773043987561717760";
	}

	public static void main(String[] args) {

		Gambite gambite = new Gambite();
		BotBrowser browser = BotBrowser.getInstance();
		String url = "https://start.gambite.me/c2b96918/1?lang=en";

		Util.sleep(5);
		SwingUtilities.invokeLater(() -> {
			browser.loadUrl(url);
			Util.sleep(10);
			Pro.tick("a");
			browser.getBrowser_().getSource(new CefStringVisitor() {

				public void visit(String string) {
					Pro.tick("a");
					saveToFile("gambitebot.html", string);

					Document doc = Jsoup.parse(string);
					Elements select = doc.select("div[data-iframe-height]");

					for (int i = 0; i < select.size(); i++) {
						Element element = select.get(i);
						Elements children = element.children();
						System.out.println(children.size());
						for (Element ele : children) {
							if (ele.tagName().equals("div")) {
								if (!ele.hasAttr("class")) {

									String macline = ele.text();

									Mac mac = getMac(macline);

									System.out.println(macline);

								}
							}
						}
					}

				}

			});
		});
	}

	private static Mac getMac(String macline) {

		if (!macline.contains("draw"))
			return null;
		System.out.println(macline);

		int indexOfDraw = macline.indexOf("draw");
		Mac mac = new Mac();

		int afterDrawSpace = 0;
		for (int i = indexOfDraw; i < indexOfDraw + 10; i++) {
			if (macline.charAt(i) == ' ') {
				String draworan = macline.substring(indexOfDraw, i).replaceAll("[^\\d]", "");

				mac.setDraw(Util.getIntSafe(draworan));
				afterDrawSpace = i;
				break;
			}
		}

		String htoran = macline.substring(indexOfDraw - 5, indexOfDraw - 1).replaceAll("[^\\d]", "");

		mac.setHt(Util.getIntSafe(htoran));

		String htname = macline.substring(0, indexOfDraw - 1).replaceAll("[\\d\\.]", "");
		String httrim = htname.trim();

		mac.setHometeam(httrim);

		int showMainIndex = macline.indexOf("Show main");
		if (showMainIndex < 0)
			return null;

		String at = macline.substring(afterDrawSpace, showMainIndex - 1);

		String atoran = macline.substring(showMainIndex - 5, showMainIndex - 1).replaceAll("[^\\d]", "");

		mac.setAt(Util.getIntSafe(atoran));

		String atname = at.replaceAll("[\\d\\.]", "");
		mac.setAwayteam(atname.trim());
		mac.setBuro("wink");
		System.out.println(mac);
		return mac;
	}

	@Override
	public List<Map<String, String>> getMatchs(Observer ob) {
		return null;
	}

}
