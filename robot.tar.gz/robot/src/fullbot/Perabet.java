package fullbot;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JFrame;

import org.cef.OS;
import org.cef.callback.CefStringVisitor;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import betting.BotBrowser;
import betting.BuroBase;
import bettingutil.Mac;
import util.Util;


public class Perabet extends BuroBase {
	private String url;

	public Perabet(String url) {
		this.url = url;
	
	}
	public List<Mac> parse(String content) {
		Document doc = Jsoup.parse(content);
		List<Mac> macs = new ArrayList<Mac>();
		Elements countries = doc.getElementsByClass("countrySection");

		for (Element country : countries) {

			int ccode = Integer.parseInt(country.attr("data-cid"));

			if (ccode == 160 || ccode == 148 || ccode == 159 || ccode == 139 || ccode == 140 || ccode == 150
					|| ccode == 201 || ccode == 166||true) {

				Elements modulheaders = country.getElementsByClass("modul-header");

				for (Element element : modulheaders) {
					Elements spans = element.getElementsByTag("span");
					Element span = spans.get(0);
					String ligname = span.text();
					if (!isMajorLeague(ligname))
						continue;

					Elements fixturebodies = element.parent().getElementsByClass("fixture-body");

					int sayac = 0;
					for (Element fixture : fixturebodies) {
						Mac mac = new Mac();
						Element leftaligns = fixture.getElementsByClass("left-align").get(0);
						int k = 0;
						String htname = "", atname = "";
						for (Element ele : leftaligns.getElementsByTag("a")) {
							if (k == 0)
								mac.setHometeam(ele.text());
							else if (k == 1) {
								mac.setAwayteam(ele.text());
							} else {
								break;
							}
							k++;
						}

						Elements odds = fixture.getElementsByClass("betBtnOdds");
						k = 0;
						for (Element odd : odds) {
							String text = odd.text();
							int oddint = 0;
							try {
								String onlynumbes = text.replaceAll("[^\\d]", "");
								oddint = Integer.parseInt(onlynumbes);
							} catch (Exception ex) {
								break;
							}

							if (k == 0) {
								mac.setHt(oddint);
							} else if (k == 1) {
								mac.setDraw(oddint);
							} else if (k == 2) {
								mac.setAt(oddint);
							}
							k++;
						}
						mac.setBuro("perabet");
						macs.add(mac);

					}
				}
			}
		}
		for (Mac mac : macs) {
			//System.out.println(mac);
		}
		return macs;
	}

	public static void main(String[] args) {

		BotBrowser browser = BotBrowser.getInstance();
		Util.sleep(5);
		browser.loadUrl("http://perabet216.com/livebet/main");
//		Util.sleep(10);
//
//		browser.getBrowser_().getSource(new CefStringVisitor() {
//
//			public void visit(String string) {
//				saveToFile("prebet216.html", string);
//				Perabet perabet = new Perabet();
//		perabet.parsePerabet(string);
//
//			}
//
//		});

//		String fromFile = getFromFile("prebet216.html");
//		Perabet perabet = new Perabet();
//		perabet.parse(fromFile);

	}

	public static void saveToFile(String filename, String stringBuffer) {
		try {

			Files.write(Paths.get("./" + filename + ""), stringBuffer.getBytes());
		} catch (IOException e1) {

			e1.printStackTrace();
		}
	}

	@Override
	public List<Map<String, String>> getMatchs(Observer ob) {
		return null;
	}

	public String getPreLiveUrl() {
		
		return "http://"+url+".com/tr/bet/today-events/soccer";
	}
}
