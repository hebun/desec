package fullbot;

import java.util.List;

import bettingutil.DualMac;

public interface BotViewI {

	void refreshTab(String string, List<DualMac> dualMacs);

	int getSleepTime();

}
