package fullbot;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Observer;
import java.util.Set;

import javax.swing.SwingUtilities;

import org.cef.CefApp;
import org.cef.browser.CefBrowserFactory;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import betting.ASCIITable;
import betting.Betfair;
import betting.BotBrowser;
import betting.BuroBase;
import betting.Surebet;
import betting.Tempobet;
import bettingutil.DualMac;
import bettingutil.Mac;
import util.LevenshteinDistance;
import util.MyLogger;
import util.Util;
import javafx.collections.FXCollections;
import javafx.scene.control.TableRow;

import sun.rmi.runtime.Log;
import util.MyPrint;

public class Bot implements Runnable {
	private BotViewI view;
	boolean threadStarted = false;
	private Perabet perabet;
	private Betfair betfair;
	private BotBrowser browser;
	private Tempobet tempobet;
	Set<DualMac> muted;

	private Map<String, String> buros;
	private Gson gson;
	private Thread thread;
	private static Bot bot;

	public Bot(BotViewI view) {
		this.view = view;

		gson = new Gson();

		buros = new HashMap<String, String>();

		try {
			buros = (Map<String, String>) gson.fromJson(new FileReader(new File("buros.json")), buros.getClass());
		} catch (JsonSyntaxException | JsonIOException | FileNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		perabet = new Perabet(buros.get("perabet"));
		betfair = new Betfair(false, false);
		//
		tempobet = new Tempobet(buros.get("tempobet"));
		muted = new HashSet<>();

	}

	public static void main(String[] args) {
		Util.tone(1000, 100, 0.5);

		Util.tone(2000, 100, 0.5);

		Util.tone(800, 140, 0.5);

	}

	public void start() {

		if (threadStarted)
			return;

		thread = new Thread(this);
		thread.start();

	}

	public void stop() {
		thread.interrupt();
		threadStarted = false;
		browser.dispose();
		browser = null;
	}

	public List<DualMac> findDualMacs(List<Mac> bf, List<Mac> buro) {
		List<DualMac> dualmacs = new ArrayList<DualMac>();
		for (Mac buromac : buro) {
			for (Mac bfmac : bf) {

				try {

					if (buromac.getHometeam().contains("Mont") && bfmac.getHometeam().contains("Mont")) {
						// System.out.println();
					}

					double similarityAway = LevenshteinDistance.similarity(bfmac.getAwayteam().replaceAll("Live!", ""),
							buromac.getAwayteam());

					double similarityHome = LevenshteinDistance.similarity(bfmac.getHometeam(), buromac.getHometeam());
					if (similarityAway > 0.5 && similarityHome > 0.5) {
						if (buromac.getBuro().equals("tempo")) {
							try {
								Calendar calendar = Calendar.getInstance();
								calendar.setTime(buromac.getTarih());
								int hours = calendar.get(Calendar.HOUR_OF_DAY);
								int minutes = calendar.get(Calendar.MINUTE);

								Calendar calendarbf = Calendar.getInstance();
								calendarbf.setTime(bfmac.getTarih());
								int hoursbf = calendarbf.get(Calendar.HOUR_OF_DAY);
								int minutesbf = calendarbf.get(Calendar.MINUTE);

								if (minutes != minutesbf || Math.abs(hoursbf - hours) > 1) {
									// System.out.println("wrong times");
									// System.out.println(buromac);
									// System.out.println(bfmac);
									continue;
								}
							} catch (Exception e) {
								System.out.println(bfmac.getHometeam() + ":" + e.getMessage());
							}
						}
						DualMac dm = new DualMac(buromac, bfmac);
						/**
						 * only add low odds
						 */
						// if (dm.getOdds().startsWith("1") || dm.getOdds().startsWith("2") ||
						// dm.getOdds().startsWith("3"))
						dualmacs.add(dm);
					}
				} catch (Exception e) {
					e.printStackTrace();
					// System.err.println(buromac);
				}

			}
		}
		dualmacs.sort((o1, o2) -> Double.compare(o2.getRatio(), o1.getRatio()));

		return dualmacs;
	}

	private void warn(List<DualMac> dualmacs) {

		Surebet surebet = new Surebet(dualmacs);

		surebet.findSurebets();

		String surebets = surebet.getSurebets();

		if (surebets.length() > 5) {
			Util.tone(2000, 100, 0.5);
			Util.tone(1000, 100, 0.5);

			Util.tone(2000, 100, 0.5);
		}

	}

	private void oldwarn(List<DualMac> dualmacs) {

		for (DualMac dualMac : dualmacs) {

			double profit = dualMac.getProfit();
			boolean isGoodForWink = dualMac.getBuroname().equals("wink") && profit > -5;
			if (profit > 25 || isGoodForWink) {

				if (isGoodForWink) {
					String line = dualMac.getName() + " " + dualMac.getOdds();

					try {
						Files.write(Paths.get("wink.txt"), (line + "\n").getBytes(), StandardOpenOption.APPEND);
					} catch (IOException e) {

						e.printStackTrace();
					}
				}

				boolean isMuted = false;
				isMuted = isMuted(dualMac) != null;
				if (isMuted)
					continue;
				Util.tone();

				if (!dualMac.getBuro().isLive()) {
					Util.sleep(1);
					Util.tone();
				}

			}
		}
	}

	private DualMac isMuted(DualMac dualMac) {
		for (DualMac dm : muted) {
			if (dm.getName().equals(dualMac.getName())) {

				return dm;
			}
		}
		return null;
	}

	@Override
	public void run() {

		browser = BotBrowser.getInstance();
		Util.sleep(2);
		for (int i = 0; i < 1000; i++) {

			try {
				buros = (Map<String, String>) gson.fromJson(new FileReader(new File("buros.json")), buros.getClass());
			} catch (JsonSyntaxException | JsonIOException | FileNotFoundException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}

			int st = i == 0 ? 5 : view.getSleepTime();

			lastPage();

			Util.sleep(view.getSleepTime());
		}

	}

	MyLogger log = MyLogger.getInstance();

	public void lastPage() {

		SwingUtilities.invokeLater(() -> {
			browser.getCeffFrame().setVisible(true);
			 Util.sleep(2);
			browser.loadUrl(tempobet.getPreLiveUrl());
			Util.sleep(10);
			// browser.loadUrl(tempobet.getPreLiveUrl());
			browser.getBrowser_().getSource(tempocontent -> {

				List<Mac> tempoMacs = tempobet.parse(tempocontent);
				log.info(" tempo count:" + tempoMacs.size());
				Util.sleep(2); // end

//
				List<Mac> bfMacs = betfair.getOddsfairMatches();
				List<DualMac> dualMacs = new ArrayList<>();

				List<DualMac> tempDuals = findDualMacs(bfMacs, tempoMacs);

				dualMacs.addAll(tempDuals);

				dualMacs.sort((o1, o2) -> Double.compare(o2.getProfit(), o1.getProfit()));
				warn(dualMacs);

				view.refreshTab("prelive", dualMacs);

				log.info("hiding..");
				SwingUtilities.invokeLater(() -> {
					browser.getCeffFrame().setVisible(false);
				});
				log.info("sleepiig for ");
				;

//					
			});

		});
	}

	public BotBrowser getBrowser() {
		return browser;
	}

	public void setBrowser(BotBrowser browser) {
		this.browser = browser;
	}

}
