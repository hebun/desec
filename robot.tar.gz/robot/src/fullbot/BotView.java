package fullbot;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import javax.swing.plaf.basic.BasicTabbedPaneUI.TabbedPaneLayout;

import com.jogamp.common.os.Platform;

import betting.ASCIITable;
import betting.Betfair;
import betting.Surebet;
import bettingutil.DualMac;
import fxcomps.BaseWindow;
import fxcomps.Grid;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import robot.ProcessInt;
import util.MyPrint;
import util.Pro;
import util.Row;
import util.Util;

public class BotView extends BaseWindow<BorderPane> implements ProcessInt,BotViewI {

	private FlowPane catpane;
	public static String borderStyle = "-fx-padding: 5;-fx-border-style: solid inside;-fx-border-width: 1;-fx-border-insets: 5;-fx-border-radius: 5;-fx-border-color: darkcyan;";
	private TabPane tabs;

	private Grid<DualMac> dualgrid;
	private boolean running = false;
	private boolean sendMail = false;
	private Observer ob;

	public BotView() {

		this.width = 1400;
		this.height = 800;

		rootNode = new BorderPane();

		rootNode.setStyle(borderStyle);
		HBox top = new HBox();
		top.setPadding(new Insets(10));
		top.setAlignment(Pos.BASELINE_LEFT);
		top.setSpacing(10);

		Button now = new Button("Now");

		now.setOnAction(a -> {

			Runnable runnable = new Runnable() {

				@Override
				public void run() {
					while (true) {

						javafx.application.Platform.runLater(() -> {

						});
						Util.sleep(5);

					}
				}

			};

			Thread thread = new Thread(runnable);
			thread.start();
			now.setDisable(true);

		});
		Button prelive = new Button("prelive");

		prelive.setOnAction(a -> {

			Runnable runnable = new Runnable() {

				@Override
				public void run() {
					while (true) {

						javafx.application.Platform.runLater(() -> {

						});
						Util.sleep(30);

					}
				}

			};

			Thread thread = new Thread(runnable);
			thread.start();
			prelive.setDisable(true);

		});

		catpane = new FlowPane();
		catpane.setOrientation(Orientation.VERTICAL);
		catpane.setHgap(20);
		catpane.setVgap(20);
		tabs = new TabPane();

		Tab compareTab = new Tab("title");
		tabs.getTabs().add(compareTab);

		Row dmcols = new Row();

		dmcols.put("name", "name");
		dmcols.put("odds", "odds");
		dmcols.put("proOdd", "proOdd");
		dmcols.put("profit", "profit");

		dmcols.put("tarih", "tarih");
		dmcols.put("buroTarih", "buroTarih");

		dmcols.put("buroname", "buroname");
		dmcols.put("maxlimit", "maxlimit");
		dmcols.put("limitprofit", "limitprofit");

		dualgrid = new Grid<>(dmcols);

		compareTab.setContent(dualgrid);

		// tabs.setStyle(borderStyle);
		rootNode.setCenter(tabs);
		// grid.setonr

		top.getChildren().add(now);
		top.getChildren().add(prelive);

		rootNode.setTop(top);

		VBox option = new VBox(50);
		option.setStyle(borderStyle);
		rootNode.setLeft(option);
		dualgrid.setOnKeyPressed(new EventHandler<KeyEvent>() {

			@Override
			public void handle(KeyEvent event) {
				if (event.getCode() == KeyCode.C)
					;
				int selectedIndex = dualgrid.getSelectionModel().getSelectedIndex();
				ObservableList<DualMac> items = dualgrid.getItems();
				if (selectedIndex < items.size()) {
					DualMac dm = items.get(selectedIndex);

					System.out.println(dm);

					String myString = dm.getName() + "   " + dm.getOdds() + "    " + dm.getBuroname();
					StringSelection stringSelection = new StringSelection(myString);
					Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
					clipboard.setContents(stringSelection, null);
				} else {
					System.out.println("bad selection");
				}
			}
		});

	}


	public void update(Observable o, Object arg) {
		ob.update(o, arg);

	}

	public void refreshTab(String tabname, List<DualMac> dualMacs) {
		if (tabname.equals("prelive")) {
			ObservableList<DualMac> oal = FXCollections.observableArrayList(dualMacs);
			// Util.print(dualMacs);
			dualgrid.setData(oal);
		}
	}

	public Grid<DualMac> getDualgrid() {
		return dualgrid;
	}

	public void setDualgrid(Grid<DualMac> dualgrid) {
		this.dualgrid = dualgrid;
	}

	public boolean isRunning() {
		return running;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}

	@Override
	public String getTitle() {
		return "Bet Bot";
	}

	@Override
	public void start() {
	}

	@Override
	public void resume() {
		running = true;
	}

	@Override
	public void stop() {
		running = false;
	}
	@Override
	public void setObserver(Observer ob) {
		this.setOb(ob);
	
	}

	public Observer getOb() {
		return ob;
	}

	public void setOb(Observer ob) {
		this.ob = ob;
	}


	@Override
	public int getSleepTime() {
		return 1000;
	}

}
