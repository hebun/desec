package model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import net.bytebuddy.dynamic.TypeResolutionStrategy.Lazy;

@Entity
public class Wallet extends BaseEntity {

	@ManyToOne
	Category category;
	private boolean visible=true;
	@Transient
	private double currentValue;

	@ManyToOne
	Currency currency;

	@OneToMany(mappedBy = "wallet", fetch = FetchType.EAGER)
	@Cascade(CascadeType.ALL)
	private List<Move> moves;

	@Transient
	private double convertedValue;
	@Transient
	private String convertedCur;

	public double getConvertedValue() {
		return convertedValue;
	}

	public void setConvertedValue(double convertedValue) {
		this.convertedValue = convertedValue;
	}

	public String getConvertedCur() {
		if (convertedCur == null)
			convertedCur = currency.getCode();
		return convertedCur;
	}

	public void setConvertedCur(String convertedCur) {
		this.convertedCur = convertedCur;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Transient
	public String getCurrencyCode() {
		if (currency == null)
			return " ";
		return getCurrency().getCode();
	}

	@Transient
	public double getValueAsTL() {
		return currentValue * getCurrency().getValue();
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public List<Move> getMoves() {
		return moves;
	}

	public void setMoves(List<Move> moves) {
		this.moves = moves;
	}

	public double getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(double currentValue) {
		this.currentValue = currentValue;
	}

	@Override
	public String toString() {
		return "Wallet [category=" + category + ", currentValue=" + currentValue + ", name=" + name + "]";
	}

	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}
}
