package model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Currency extends BaseEntity {
	private double value;

	private String code;
	
	private Date lastUpdate;
	
	public double getValue() {
		return value;
	}

	@Override
	public String toString() {
		return "Currency [value=" + value + ", code=" + code + "]";
	}

	public void setValue(double value) {
		this.value = value;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

}
