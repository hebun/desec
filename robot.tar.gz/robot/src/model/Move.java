package model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.CreationTimestamp;

import util.Util;

@Entity
public class Move extends BaseEntity {

	@Override
	public String toString() {
		return Util.getFormattedTimeDot(tarih) + " -> " + total + " -> " + totalnow+" - >"+text;
	}

	double value;
	@CreationTimestamp
	Date tarih;
	boolean isSettled;
	double total;
	private String text;
	private double totalnow;
	@ManyToOne
	Wallet wallet;

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public Date getTarih() {
		return tarih;
	}

	public void setTarih(Date tarih) {
		this.tarih = tarih;
	}

	public boolean isSettled() {
		return isSettled;
	}

	public void setSettled(boolean isSettled) {
		this.isSettled = isSettled;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {

		int removePrec = (int) total;

		this.total = removePrec;
	}

	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	public double getTotalnow() {
		return totalnow;
	}

	public void setTotalnow(double totalnow) {
		int removePrec = (int) totalnow;

		this.totalnow = removePrec;

	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
