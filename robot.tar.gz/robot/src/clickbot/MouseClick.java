package clickbot;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.Panel;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.InputEvent;

import javax.swing.JFrame;


import jogamp.nativewindow.NWJNILibLoader;
import util.Util;

public class MouseClick {
	public static void main(String[] args) throws AWTException {
		MyRobot bot = new MyRobot();
		// collectMoohlahDividends();
//		java.awt.Point[x=370,y=876]
//				java.awt.Point[x=311,y=932]
//				java.awt.Point[x=305,y=924]

//		for (int i = 0; i < 100; i++) {
//
//			System.out.println(MouseInfo.getPointerInfo().getLocation());
//			Util.sleep(1);
//		}
//		scanScreen();

		 depositGoo(bot);
	}

	public static void scanScreen() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		double width = screenSize.getWidth();
		double height = screenSize.getHeight();
		Panel panel = new Panel() {
			@Override
			public void paint(Graphics g) {
				g.setFont(new Font("Tahoma", Font.BOLD, 10));
				for (int i = 0; i < width; i += 50) {
					for (int j = 0; j < height; j += 30) {
						g.drawString(i + ":" + j, i, j);
					}
				}

			}
		};
		JFrame frame = new JFrame(panel.getName());
		frame.setUndecorated(true);
		frame.setBackground(new Color(0, 0, 0, 150));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.setSize((int) width - 10, (int) height - 10);
		frame.setVisible(true);
		frame.getContentPane().add(panel);
		frame.setLocationRelativeTo(null);
	}

	public static void depositGoo(MyRobot bot) {
		Util.sleep(5);

		bot.click(370, 876);
		bot.click(305, 924);
		bot.click(280, 613);
	}

	public static void produceKnightKitty() throws AWTException {
		Robot bot = new Robot();
		int mask = InputEvent.BUTTON1_DOWN_MASK;
		Util.sleep(3);
		bot.mouseMove(1860, 600);
		Util.sleep(1);
		bot.mousePress(mask);
		bot.mouseRelease(mask);
		Util.sleep(5);
		bot.mouseMove(1760, 640);
		Util.sleep(1);
		bot.mousePress(mask);
		bot.mouseRelease(mask);

		Util.sleep(3);
		bot.mouseMove(280, 613);
		Util.sleep(1);
		bot.mousePress(mask);
		bot.mouseRelease(mask);
		Util.sleep(3);
		bot.mousePress(mask);
		bot.mouseRelease(mask);
	}

	public static void collectMoohlahDividends() throws AWTException {
		Robot bot = new Robot();
		int mask = InputEvent.BUTTON1_DOWN_MASK;
		Util.sleep(10);

		for (int i = 0; i < 100; i++) {

			bot.mousePress(mask);
			bot.mouseRelease(mask);

			Util.sleep(20);
		}
	}
}
