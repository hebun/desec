package clickbot;

import java.awt.AWTException;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Robot;
import java.awt.event.InputEvent;

import util.Util;

public class MyRobot {
	private Robot bot;
	int mask = InputEvent.BUTTON1_DOWN_MASK;

	public MyRobot() {
		try {
			bot = new Robot();
		} catch (AWTException e) {
			e.printStackTrace();
		}

	}

	public void click(int x, int y) {
		Point cl = MouseInfo.getPointerInfo().getLocation();
		int end_x = x, end_y = y, start_x = cl.x, start_y = cl.y;
		int steps = 50;
		for (int i = 0; i < steps; i++) {
			int mov_x = ((end_x * i) / steps) + (start_x * (steps - i) / steps);
			int mov_y = ((end_y * i) / steps) + (start_y * (steps - i) / steps);
			bot.mouseMove(mov_x, mov_y);
			bot.delay(10);
		}
		bot.mouseMove(x,y);
		Util.sleep(3);
//		Util.sleep(1);
//		bot.mouseMove(x, y);
//		Util.sleep(1);
//		bot.mousePress(mask);
//		bot.mouseRelease(mask);
//		
	}
}
