package tronscan;

import arbitrage.WebRequest;
import betting.BuroBase;

public class FetchTx {
	public static void main(String[] args) {

		WebRequest w = new WebRequest();
		StringBuffer fn = w
				.getFromNet("https://tronscan.org/#/address/TC6HkHRSd4G18a7UVN6PTMru3vWxcesKk7/internal-transactions");
		System.out.println(fn.toString());
		BuroBase.saveToFile("tronscan", fn.toString());

	}
}
