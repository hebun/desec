package work;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TController {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@Test
	void test() {
		ConsoleView view = new ConsoleView();
		WorkModel model = new WorkModel(new StaticDataImp());
		Controller cont = new Controller(view, model);
		view.setCont(cont);
		cont.start();
	}

}
