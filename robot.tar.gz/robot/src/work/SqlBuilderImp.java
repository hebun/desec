package work;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import util.Db;
import util.Sql;
import util.orm.Fetch;

public class SqlBuilderImp implements ServiceInt {

	@Override
	public void insertDaylies() {
		List<Map<String, String>> rw = new Fetch().from("repeatedwork").getTable();
		for (Map<String, String> map : rw) {
			String sql = "select id from work where date(start) = CURDATE() and daily=" + map.get("id");
			List<Map<String, String>> daylies = Db.selectTable(sql);
			if (daylies.size() < 1) {

				new Sql.Insert("work").add("name", map.get("name") + "  " + LocalDate.now().getDayOfMonth() + "."
						+ LocalDate.now().getMonthValue()).add("daily", map.get("id")).run();
			}

		}
	}

	@Override
	public List<Map<String, String>> getWorks() {
		List<Map<String, String>> table = new Fetch().from("work").order("id").desc().getTable();
		return table;
	}

	@Override
	public List<Map<String, String>> getDailyWorks() {
		List<Map<String, String>> rw = new Fetch().from("repeatedwork").getTable();
		return rw;
	}

}
