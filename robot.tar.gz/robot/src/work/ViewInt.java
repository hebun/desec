package work;

import java.util.List;

import bettingutil.Mac;

public interface ViewInt {

	String getNewWork();

	void showAddWork();

	void setCont(Controller cont);

	void setModel(WorkModel model);

	void refresh();

	default void showHighVolume(List<Mac> highVolume) {
		System.out.println("------high volume matches today ------");
		for (Mac mac : highVolume) {
			
			System.out.println(mac);
		}
	}
}
