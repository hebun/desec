package work;

import java.util.List;

import util.MyLogger;
import util.MyPrint;
import util.Pro;
import util.Util;

public class ConsoleView implements ViewInt {
	MyLogger log = MyLogger.getInstance();
	private Controller cont;
	private WorkModel model;

	public ConsoleView() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getNewWork() {
		return "some new work from junit";
	}

	@Override
	public void showAddWork() {
		log.test("showing addwork");
	}

	@Override
	public void setCont(Controller cont) {
		this.cont = cont;

	}

	public static void main(String[] args) {
		Pro.tick("console");
		ConsoleView view = new ConsoleView();
		Pro.tick("model");
		WorkModel model = new WorkModel(new SqlBuilderImp());
		Pro.tick("model");
		Controller cont = new Controller(view, model);
		view.setCont(cont);
		cont.start();

		
		Pro.tick("console");
	}

	@Override
	public void setModel(WorkModel model) {
		this.model = model;

	}

	@Override
	public void refresh() {

		model.fetch();
		int k = 0;
		List<Work> activeWorks = model.getActiveWorks();

		for (Work work : activeWorks) {
			System.out.println(work);
			if (k++ > 5)
				break;
		}

	}

}
