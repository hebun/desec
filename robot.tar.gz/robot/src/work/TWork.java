package work;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TWork {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@Test
	void test() {

		Calendar instance = Calendar.getInstance();
		instance.add(Calendar.HOUR, 48);
		Work fxbook = new Work.Builder("FXBook toparlama").setTime(Calendar.getInstance().getTime(), instance.getTime())
				.repeat(60).build();
		System.out.println(fxbook);

	}

}
