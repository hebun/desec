package work;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StaticDataImp implements ServiceInt {
	private List<Map<String, String>> works;

	public StaticDataImp() {
		works = new ArrayList<Map<String, String>>();

		HashMap<String, String> map = new HashMap<String, String>();

		map.put("name", "test work in static data imp");
		works.add(map);
	}

	@Override
	public void insertDaylies() {
		HashMap<String, String> map = new HashMap<String, String>();

		map.put("name", "test new daily");
		works.add(map);
	}

	@Override
	public List<Map<String, String>> getWorks() {
		return works;
	}

	@Override
	public List<Map<String, String>> getDailyWorks() {
		return null;
	}

}
