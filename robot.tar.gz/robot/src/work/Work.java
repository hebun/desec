package work;

import java.util.Date;
import java.util.Objects;

public class Work {
	@Override
	public String toString() {
		return "Work [status=" + status + ", start=" + start + ", end=" + end + ", repeatMin=" + repeatMin
				+ ", hourPerday=" + hourPerday + ", daily=" + daily + ", todayWarned=" + todayWarned + ", name=" + name
				+ "]";
	}

	int status = 0;
	Date start, end;
	int repeatMin;
	int hourPerday;
	boolean daily;
	boolean todayWarned;
	String name;
	int worktime;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Date getStart() {
		return start;
	}

	public void setStart(Date start) {
		this.start = start;
	}

	public Date getEnd() {
		return end;
	}

	public void setEnd(Date end) {
		this.end = end;
	}

	public int getRepeatMin() {
		return repeatMin;
	}

	public void setRepeatMin(int repeatMin) {
		this.repeatMin = repeatMin;
	}

	public int getHourPerday() {
		return hourPerday;
	}

	public void setHourPerday(int hourPerday) {
		this.hourPerday = hourPerday;
	}

	public boolean isDaily() {
		return daily;
	}

	public void setDaily(boolean daily) {
		this.daily = daily;
	}

	public boolean isTodayWarned() {
		return todayWarned;
	}

	public void setTodayWarned(boolean todayWarned) {
		this.todayWarned = todayWarned;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	private Work() {

	}

	public static class Builder {

		Work work;

		public Builder(String name) {
			work = new Work();
			work.name = name;
			work.daily = false;
			work.repeatMin = 60;
			work.status=0;
		}

		public Builder setTime(Date start, Date end) {
			work.start = start;
			work.end = end;
			return this;
		}

		public Builder daily(int hourPerDay) {

			work.daily = true;
			work.hourPerday = hourPerDay;
			return this;
		}

		public Builder repeat(int min) {
			work.repeatMin = min;
			return this;
		}

		public Builder status(String s) {
			work.status = Integer.parseInt(s);
			return this;
		}

		public Builder worktime(String s) {
			int parseInt =0;
			try {
				parseInt=Integer.parseInt(s);
			} catch (NumberFormatException e) {
			
			}
			work.worktime = parseInt;
			return this;
		}

		public Work build() {
//			Objects.requireNonNull(work);
//			Objects.requireNonNull(work.start);
//			Objects.requireNonNull(work.end);
//			Objects.requireNonNull(work.worktime);
			return work;
		}
	}
}
