package work;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import fxcomps.BaseWindow;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import util.Observable;
import util.Observer;
import util.Sql;
import util.Sql.Delete;

public class WorkField extends BaseWindow<GridPane> {
	private Work work;
	public static String border = "-fx-padding: 1;-fx-border-style: solid inside;-fx-border-width: 1;"
			+ "-fx-border-insets: 1;-fx-border-radius: 1;-fx-border-color:";
	public static String greenBorder = border + " darkcyan;";
	public static String redBorder = border + " darkred;";
	public static String yellowBorder = border + " yellow;";
	public static String blackBorder = border + " black;";
	

	List<Observer> obsl = new ArrayList<Observer>();

	public WorkField(Work work) {
		this.work = work;

		rootNode = new GridPane();

		Date now = Calendar.getInstance().getTime();
		if (work.getStatus() == 0) {
			rootNode.setStyle(yellowBorder);
		}
		else if (work.getStatus() == 1) {
			rootNode.setStyle(greenBorder);
		}
		else if (work.getStatus() == 4) {
			rootNode.setStyle(redBorder);

		}else {
			rootNode.setStyle(blackBorder);
		}
		rootNode.setPrefHeight(50);
		rootNode.getColumnConstraints().addAll(new ColumnConstraints(400), new ColumnConstraints(50),
				new ColumnConstraints(50), new ColumnConstraints(40));
		rootNode.add(new Label(work.getName()), 0, 0);

		Button donebut = new Button("done");
		donebut.setOnAction(e -> {
			Sql.Update update = new Sql.Update("work").add("status", "1");
			update.where("name", work.getName());
			update.run();
			notifyObservers();

		});
		rootNode.add(donebut, 2, 0);

		Button postponebut = new Button("postpone");
		postponebut.setOnAction(e -> {
			Sql.Update update = new Sql.Update("work").add("status", "2");
			update.where("name", work.getName());
			update.run();
			notifyObservers();
		});
		rootNode.add(postponebut, 3, 0);

		Button failbut = new Button("fail");
		failbut.setOnAction(e -> {
			Sql.Update update = new Sql.Update("work").add("status", "4");
			update.where("name", work.getName());
			update.run();
			notifyObservers();
		});
		rootNode.add(failbut, 5, 0);

		Button deletebut = new Button("del");
		deletebut.setOnAction(e -> {
			Sql.Update update = new Sql.Update("work").add("status", "3");
			update.where("name", work.getName());
			update.run();
			notifyObservers();
		});
		rootNode.add(deletebut, 4, 0);

	}

	@Override
	public void notifyObservers() {
		for (Observer observer : obsl) {
			observer.update();
		}
	}

	@Override
	public void addObserver(Observer obs) {
		obsl.add(obs);

	}

}
