package work;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import util.Db;
import util.orm.Fetch;

public class PlainSqlImp implements ServiceInt {

	@Override
	public void insertDaylies() {
		List<Map<String, String>> rw = Db.selectTable("select * from repeatedwork");
		for (Map<String, String> map : rw) {
			String sql = "select id from work where date(start) = CURDATE() and daily=" + map.get("id");
			List<Map<String, String>> daylies = Db.selectTable(sql);
			if (daylies.size() < 1) {

				String insert = "insert into work(name,daily) values(" + map.get("name") + "  "
						+ LocalDate.now().getDayOfMonth() + "." + LocalDate.now().getMonthValue() + "," + map.get("id");
				
			}

		}
	}

	@Override
	public List<Map<String, String>> getWorks() {
		List<Map<String, String>> table = new Fetch().from("work").order("id").desc().getTable();
		return table;
	}

	@Override
	public List<Map<String, String>> getDailyWorks() {
		return null;
	}

}
