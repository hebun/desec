package work;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import util.Db;
import util.Pro;
import util.Sql;
import util.Util;
import util.orm.Fetch;

public class WorkModel {
	private List<Work> works;
	private ServiceInt service;
	private ArrayList<Work> al;

	public WorkModel(ServiceInt service) {

		this.service = service;
		fetch();
	}

	public void fetch() {
		setWorks(new ArrayList<Work>());
		Pro.tick("startfetch");
		service.insertDaylies();
		Pro.tick("insertdailies");
		List<Map<String, String>> table = service.getWorks();
		Pro.tick("getworks");
		for (Map<String, String> map : table) {
			Work work = new Work.Builder(map.get("name")).repeat(60)
					.status(map.get("status") == null ? "0" : map.get("status")).build();
			getWorks().add(work);
		}
		Pro.tick("strongTyping");
	}

	public List<Work> getFailedWorks() {

		return getWorksByStatus(4);
	}

	public List<Work> getActiveWorks() {

		return getWorksByStatus(0);
	}

	public List<Work> getDoneWorks() {
		return getWorksByStatus(1);
	}

	public List<Work> getWorksByStatus(int status) {
		List<Work> aworks = new ArrayList<Work>();

		Date now = Calendar.getInstance().getTime();
		for (Work work : getWorks()) {

			if (work.getStatus() == status) {
				aworks.add(work);
			}
		}
		return aworks;
	}

	public List<Work> getWorks() {
		return works;
	}

	public void setWorks(List<Work> works) {
		this.works = works;
	}

	public ArrayList<Work> getDailyWorks() {
		al = new ArrayList<Work>();
		List<Map<String,String>> dailyWorks = service.getDailyWorks();
		
		for (Map<String, String> map : dailyWorks) {
			Work work = new Work.Builder(map.get("name")).repeat(60)
					.status("0").build();
			al.add(work);
			
		}
		return al;
	}

}
