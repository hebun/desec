package work;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.security.auth.Refreshable;

import com.jogamp.common.os.Platform;

import bettingutil.DualMac;
import fullbot.Bot;
import fullbot.BotView;
import fxcomps.BaseWindow;
import javafx.geometry.Orientation;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.ConstraintsBase;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import robot.Panel;
import util.ASCIITable;
import util.MyPrint;
import util.Observable;
import util.Observer;
import util.Util;

public class WorkView extends BaseWindow<BorderPane> implements ViewInt {
	private GridPane center;
	private WorkModel model;
	private Controller cont;
	public static String borderStyle = "-fx-padding: 5;-fx-border-style: solid inside;-fx-border-width: 1;-fx-border-insets: 5;-fx-border-radius: 5;-fx-border-color: darkcyan;";
	private AddWork addWork;
	public int oldWorksStatus = 4;// -1 for all
	private FlowPane left;

	public WorkView() {

		this.width = 1300;
		this.height = 950;

		rootNode = new BorderPane();
		rootNode.setStyle(borderStyle);
		FlowPane top = new FlowPane();
		top.getChildren().add(new Label("balba\nlbala"));
		Button addbut = new Button("add new");
		addbut.setOnAction(event -> {

			cont.addWork();

		});

		Button refresh = new Button("refresh");
		refresh.setOnAction(event -> {

			refresh();

		});

		top.getChildren().add(refresh);
		top.getChildren().add(addbut);
		rootNode.setTop(top);
		center = new GridPane();
		rootNode.setCenter(center);
		center.setStyle(borderStyle);

		left = new FlowPane(Orientation.VERTICAL);
		rootNode.setLeft(left);
		WorkStatus[] values = WorkStatus.values();
		int k = 0;
		for (WorkStatus st : values) {
			Button but = new Button(st.name());
			but.setOnAction(event -> {
				oldWorksStatus = st.ordinal();
				refresh();
			});
			top.getChildren().add(but);
		}

	}

	public void showAddWork() {
		addWork = new AddWork(cont);
		addWork.getStage().showAndWait();
		refresh();
	}

	public void refresh() {
		left.getChildren().clear();

		ArrayList<Work> dailyWorks = model.getDailyWorks();

//		for (Work work : dailyWorks) {
//			WorkField wf = new WorkField(work);
//			wf.getRootNode().setPrefWidth(100);
//			wf.addObserver(this);
//			left.getChildren().add(wf.getRootNode());
//		}

		center.getChildren().clear();
		model.fetch();
		List<Work> activeWorks = model.getActiveWorks();

		int k = 0;
		for (Work work : activeWorks) {
			WorkField wf = new WorkField(work);
			wf.addObserver(this);
			center.add(wf.getRootNode(), 0, k++);
		}

		List<Work> oldWorks = null;
		if (oldWorksStatus < 0) {
			oldWorks = model.getWorks();
		} else {
			oldWorks = model.getWorksByStatus(oldWorksStatus);
		}

		k = 0;
		for (Work work : oldWorks) {
			WorkField wf = new WorkField(work);
			wf.addObserver(this);
			center.add(wf.getRootNode(), 1, k++);
		}
	}

	@Override
	public void update() {
		refresh();
	}

	public Controller getCont() {
		return cont;
	}

	public void setCont(Controller cont) {
		this.cont = cont;
	}

	@Override
	public String getNewWork() {
		return addWork.getWname().getText();
	}

	public WorkModel getModel() {
		return model;
	}

	public void setModel(WorkModel model) {
		this.model = model;
	}

}
