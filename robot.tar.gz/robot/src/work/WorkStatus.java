package work;

public enum WorkStatus {
	ACTIVE, DONE, POSTPONED, DELETED, FAILED;
}
