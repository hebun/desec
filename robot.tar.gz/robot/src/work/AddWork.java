package work;

import java.time.LocalDate;

import fxcomps.BaseWindow;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import util.Sql;
import util.Sql.Insert;

public class AddWork extends BaseWindow<GridPane> {
	private TextField wname;
	private TextField sdate;
	private TextField edate;
	private Controller cont;

	public AddWork(Controller cont) {
		this.cont = cont;
		rootNode = new GridPane();
		width = 400;
		height = 400;
		rootNode.setHgap(10);
		rootNode.setVgap(10);
		rootNode.setPadding(new Insets(40, 40, 40, 40));

		setWname(new TextField(""));
		getWname().setPrefWidth(300);
		sdate = new TextField(LocalDate.now().toString());
		edate = new TextField(LocalDate.now().toString());

		Button add = new Button("add");
		add.setPrefSize(100, 30);
		add.setOnAction(event -> {
			cont.saveWork();
			this.getStage().close();
		});
		rootNode.add(getWname(), 0, 0);
		rootNode.add(sdate, 0, 1);
		rootNode.add(edate, 0, 2);
		rootNode.add(add, 0, 3);

	}

	public TextField getWname() {
		return wname;
	}

	public void setWname(TextField wname) {
		this.wname = wname;
	}

}
