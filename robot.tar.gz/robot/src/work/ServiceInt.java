package work;

import java.util.List;
import java.util.Map;

public interface ServiceInt {

	void insertDaylies();

	List<Map<String, String>> getWorks();

	List<Map<String, String>> getDailyWorks();

}
