package work;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

import arbitrage.JsonParser;
import arbitrage.SymbolPrice;
import betting.Betfair;
import bettingutil.DualMac;
import bettingutil.Mac;
import dynaInsert.DynaInsertDb;
import dynaInsert.InsertSpecial;
import fullbot.Bot;
import fullbot.BotViewI;
import util.MyLogger;
import util.Pro;
import util.Sql;
import util.Util;
import util.Sql.Insert;

public class Controller {
	MyLogger log = MyLogger.getInstance();
	private ViewInt view;

	public Controller(ViewInt view, WorkModel model) {
		this.view = view;
		view.setModel(model);

	}

	public void start() {
		reminderTone();
		view.refresh();
		// bettingBot();
		// startBetBot();
	//	startOddsfairBot();
	//	startDSPPriceBot();
	}

	public static void main(String[] args) {
		Pro.tick("fx");
		SwingView view = new SwingView();
		WorkModel model=new WorkModel(new SqlBuilderImp());
		Controller cont=new Controller(view,model);
		view.setCont(cont);
		cont.start();
Util.launchOneTab(view);
	
		Pro.tick("fx");

	}

	private void startOddsfairBot() {
		Timer timer = new Timer();
		Betfair betfair;
		betfair = new Betfair(false, false);
		TimerTask timerTask = new TimerTask() {

			@Override
			public void run() {

				List<Mac> of = betfair.getOddsfairMatches();
				List<Mac> highVolume = of.stream().filter((Mac e) -> e.getDepth() > 100000).collect(Collectors.toList());
				if (highVolume.size() == 0)
					return;
				toneHighVolume();
				view.showHighVolume(highVolume);

			}

		};
		timer.schedule(timerTask, 2000, 1000 * 60 * 120);

	}

	private static void startDSPPriceBot() {
		Timer timer = new Timer();
		InsertSpecial is = new InsertSpecial();
		DynaInsertDb insertDb = new DynaInsertDb(is);
		TimerTask timerTask = new TimerTask() {

			@Override
			public void run() {
				List<SymbolPrice> js = JsonParser.getJustSwapPrices();

				insertDb.insertJustSwap(js);

			}

		};
		timer.schedule(timerTask, 2000, 1000 * 60 * 2);

	}

	public void toneHighVolume() {
		Util.tone(1000, 100, 0.5);

		Util.tone(2000, 100, 0.5);

		Util.tone(800, 140, 0.5);
	}

	public void startBetBot() {

		// tempoCeffBot();

	}

	public void tempoCeffBot() {
		bot = new Bot(new BotViewI() {
			@Override
			public void refreshTab(String string, List<DualMac> dualMacs) {

				log.info("bot refresh");
				for (DualMac dualMac : dualMacs) {
					log.info(dualMac);
				}
			}

			@Override
			public int getSleepTime() {
				return 60 * 30;
			}
		});
		bot.start();
	}

	public Bot bot = null;

	public void bettingBot() {
		Timer timer = new Timer();
		TimerTask timerTask = new TimerTask() {

			@Override
			public void run() {
				System.out.println("run ");
				javafx.application.Platform.runLater(() -> {

				});
			}

		};
		timer.schedule(timerTask, 100, 1000 * 30);
	}

	private void reminderTone() {
		Timer timer = new Timer();
		TimerTask timerTask = new TimerTask() {

			@Override
			public void run() {
				Util.tone(700, 800, 0.5);
			}
		};
		timer.schedule(timerTask, 60 * 60000, 1000 * 60 * 60);
	}

	public void saveWork() {
		Insert insert = new Sql.Insert("work");
		insert.add("name", view.getNewWork());
		insert.run();
		view.refresh();

	}

	public void addWork() {
		view.showAddWork();
	}
}
