package work;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.function.Supplier;

import javax.swing.JButton;
import javax.swing.JPanel;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import util.Pro;
import util.Util;

public class SwingView extends JPanel implements ViewInt {
	private Controller cont;
	private WorkModel model;

	public SwingView() {
		setLayout(null);
		setName("Robot App Swing");
		JButton addbut = new JButton("add new");
		addbut.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				cont.addWork();
			}
		});
		addbut.setLocation(40, 20);
		addbut.setSize(100, 25);
		this.add(addbut);
	}

	public static void main(String[] args) {
		Pro.tick("swing");
		SwingView view = new SwingView();
		WorkModel model = new WorkModel(new PlainSqlImp());
		Controller cont = new Controller(view, model);
		view.setCont(cont);
		cont.start();

		Util.launchOneTab(view, 1200);
		Pro.tick("swing");
		// System.exit(0);
	}

	@Override
	public String getNewWork() {
		return addWork.getWname().getText();
	}

	private AddWork addWork;

	@Override
	public void showAddWork() {
		fxcomps.FxLauncher launcher = new fxcomps.FxLauncher(null);

		launcher.launchFx(new Supplier<Scene>() {
			@Override
			public Scene get() {
				addWork = new AddWork(cont);
			//	addWork.getStage().showAndWait();

				return addWork.getScene();
			}
		}, "add work");
	}

	@Override
	public void setCont(Controller cont) {
		this.cont = cont;
	}

	@Override
	public void setModel(WorkModel model) {
		this.model = model;
	}

	@Override
	public void refresh() {
		model.fetch();
		List<Work> activeWorks = model.getActiveWorks();
		int k = 0;
		for (Work work : activeWorks) {

			SwingWorkField swf = new SwingWorkField(work);

			swf.setLocation(20, (swf.getHeight() + 7) * k++ + 100);
			this.add(swf);
		}
	}

}
