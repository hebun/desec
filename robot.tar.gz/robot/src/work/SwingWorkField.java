package work;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class SwingWorkField extends JPanel {
	private Work work;

	public SwingWorkField(Work work) {

		this.work = work;
		setLayout(null);
		this.setSize(500, 40);

		JLabel namelab = new JLabel(work.getName());
		namelab.setLocation(10, 2);
		namelab.setSize(400, 35);
		this.add(namelab);
		this.setBorder(new LineBorder(Color.black));
		//this.add(new JButton("done"), 1, 2);
		

	}
}
