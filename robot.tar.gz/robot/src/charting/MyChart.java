package charting;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.Dialog.ModalityType;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.IntSummaryStatistics;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

@SuppressWarnings("serial")
public class MyChart extends JPanel implements MouseMotionListener {
	// delete from bincex where (ethb/ethc) <0.9 or (ethb/ethc) >1.1 or
	// (btgb/btgc) <0.9 or (btgb/btgc)>1.1 or (zecb/zecc)<0.9 or (zecb/zecc)>1.1
	// or (xrpb/xrpc)<0.9 or (xrpb/xrpc)>1.1
	private float distance = 20;
	final int minSpace = 15;
	double space = 10;
	int yspace = 30;
	boolean drawLine = true;
	private int dayspace = 1;
	Map<String, List<Map<String, String>>> dataset = new HashMap<>();
	int sx = 50;
	int sy = 480;
	int startdeger = 0;
	private List<Map<String, String>> table;
	private String field;
	private boolean isFixed = false;
private final int yaxisdots=20;
	public MyChart() {
		super();

		// load();

	}

	public static String getFormattedTime(Date time) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("Y-M-d H:m:s");

		String formattedTime = dateFormat.format(time);
		return formattedTime;
	}

	public static void main(String[] args) {

		List<Map<String, String>> data = getRandomData();// saveBotProfit.getAll();
		showGraphOf(data);
	}

	public static void showGraphOf(List<Map<String, String>> data) {
		MyChart chart = new MyChart();
		// chart.isFixed = true;
		// chart.setFixed(true);

		chart.load(data, "value");
		// Util.launchOneTab(chart);

		JDialog frame = new JDialog();
		// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(chart);
		frame.setSize(1200, 900);
		frame.setModalityType(ModalityType.APPLICATION_MODAL);
		frame.setVisible(true);
		frame.getContentPane().add(chart);
		frame.setLocationRelativeTo(null);
		//System.exit(0);
	}

	private static List<Map<String, String>> getRandomData() {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		Calendar cal = Calendar.getInstance();
		long tarih = 10000l;
		int value = 0;
		Random r = new Random();

		for (int i = 0; i < 100; i++) {
			int nextInt = r.nextInt(10);
			boolean isPositive = r.nextBoolean();
			if (!isPositive)
				nextInt *= -1;

			value += nextInt;
			System.out.println(value + ":" + nextInt);
			Map<String, String> map = new HashMap<>();
			map.put("tarih", "asdfaasdfadsfadfadf" + ++tarih);
			map.put("text", "");

			map.put("value", value + "");

			list.add(map);

		}
		return list;
	}

	public void load(List<Map<String, String>> table, String coin) {

		this.table = table;
		this.field = coin;
		this.setName("my chart");
		this.dataset.clear();
		// rowSize = table.size();
		addCoin(field);
		// addCoin("ethu");
		// addCoin("zec");
		// addCoin("dash");
		// addCoin("btgto");
		// addCoin("btgfrom");
		// addCoin("xrp");

		// ArrayList<Integer> binPa = new ArrayList<Integer>();
		//
		// for (Map<String, String> map : table) {
		// binPa.add(Integer.parseInt(map.get("binPa")));
		// }
		//
		// this.dataset.add(binPa);

		this.paint(this.getGraphics());

		this.doLayout();

		this.addMouseMotionListener(this);
	}

	List<Map<String, String>> coinState = new ArrayList<>();
	private int rowSize;

	private void addCoin(String coin) {

		ArrayList<Map<String, String>> arr = new ArrayList<>();
		int tot = 0, say = 0;
		Map<String, String> state = new LinkedHashMap<>();
		for (Map<String, String> map : table) {
			if (map.get(coin).equals("NULL")) {
				continue;
			}

			HashMap<String, String> hashMap = new HashMap<>();
			try {
				int deger = (int) (Float.parseFloat(map.get(coin)) );

				// if (deger > 1300 || deger < 800)
				// continue;

				hashMap.put("tarih", map.get("tarih"));
				hashMap.put("text", map.get("text"));
				hashMap.put("value", deger + "");

				arr.add(hashMap);
				tot += deger;
				say++;
			} catch (NumberFormatException e) {

			}

		}

		 //this.distance = standartSapma;
		// this.startdeger = (int) (avg - 2 * distance);
		// this.startdeger = this.startdeger - this.startdeger % 10;

		coinState.add(state);
		this.dataset.put(coin, arr);

	}

	public void paintComponent(Graphics gr) {
		// JOptionPane.showMessageDialog(this, "here");

		super.paintComponent(gr);
		// rowSize = 16;
		Graphics2D g = (Graphics2D) gr;
		g.drawLine(sx, sy, sx + 1000, sy);

		g.drawLine(sx, sy, sx, 0);
		Graphics2D g2d = (Graphics2D) g.create();

		Stroke dashed = new BasicStroke(2, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] { 3 }, 0);

		float deger = startdeger;

		for (int i = 0; i <= rowSize; i++) {

			g.drawString(deger + "", sx - 50, sy - i * yspace + 5);
		//	System.out.println(deger);
			deger += distance;
			if (i == 0)
				continue;

			if (i == 2 || i == 8) {
				g2d.setColor(Color.DARK_GRAY);
				dashed = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] { 9 }, 0);
			} else {
				g2d.setColor(Color.black);
				dashed = new BasicStroke(2, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] { 3 }, 0);
			}

			g2d.setStroke(dashed);
			// System.out.println(sx + "-" + (sy - i * yspace + 5) + "-" + (sx + 1000) + "-"
			// + (sy - i * yspace + 5));
			g2d.drawLine(sx, sy - i * yspace + 5, sx + 1050, sy - i * yspace + 5);
			// g.setStroke(null);

		}

		int k = 0;

		for (Map.Entry<String, List<Map<String, String>>> list : dataset.entrySet()) {

			Color color = null;
			switch (k) {
			case 0:
				color = Color.red;
				break;
			case 1:
				color = Color.green;
				break;
			case 2:
				color = Color.yellow;
				break;
			case 3:
				color = Color.cyan;
				break;
			case 4:
				color = Color.BLACK;
				break;
			case 5:
				color = Color.ORANGE;
				break;
			}

			g.setColor(color);
			g.drawString(list.getKey(), 20 + k * 100, 20);
			// System.out.println(list.getValue());
			List<Map<String, String>> arr = list.getValue();
			List<Map<String, String>> mavg = getMovingAvg(arr);
			drawLineChart(g, arr);
			// drawLineChart(g, mavg);
			k++;

		}
		Point location = MouseInfo.getPointerInfo().getLocation();
		SwingUtilities.convertPointFromScreen(location, this);

		g2d.setColor(Color.CYAN);
		g2d.drawLine(50, location.y, 1200, location.y);
		g2d.drawLine(location.x, 50, location.x, 800);

	}

	private List<Map<String, String>> getMovingAvg(List<Map<String, String>> arr) {
		int k = 0;
		int tot = 0;
		List<Map<String, String>> avgarr = new ArrayList<Map<String, String>>();
		int distanceforAvg = 30;
		List<Integer> last10 = new ArrayList<Integer>(distanceforAvg);
		for (Map<String, String> map : arr) {
			int value = Integer.parseInt(map.get("value"));

			last10.add(value);
			if (last10.size() > distanceforAvg) {
				last10.remove(0);
			}

			tot += value;
			k++;
			IntSummaryStatistics iss = last10.stream().mapToInt(e -> e.hashCode()).summaryStatistics();
			HashMap<String, String> nm = new HashMap<>();
			int avg = (int) iss.getAverage();
			nm.put("value", avg + "");
			nm.put("tarih", map.get("tarih"));
			nm.put("text", "");
			avgarr.add(nm);
		}
		return avgarr;
	}

	private void drawLineChart(Graphics2D g, List<Map<String, String>> arr) {
		// MyPrint.println(arr);
		int k = 0;
		rowSize = 20;
		double lastx = sx + 5;
		double lasty = sy;
		int xk = 0;
		int xspace = arr.size() / 50 + 1;

		int min = 1000000000, max = -100000000;
		for (Map<String, String> map : arr) {
			int key = Integer.parseInt(map.get("value"));

			if (key < min) {
				min = key;
			}
			if (key > max) {
				max = key;
			}
		}

		// System.out.println(min+" "+max);
		if (!isFixed()) {
			startdeger = min;
			distance =(float) (max - min) / yaxisdots  + 2;

		}

		space = (double) 1000 / arr.size();
		for (Map<String, String> itemx : arr) {
			Entry<String, String> first = itemx.entrySet().iterator().next();

			int item = Integer.parseInt(itemx.get("value"));
			// System.out.println(item);
			double x = lastx + space;
			double i = (double) yspace / distance;
			double y = sy - ((item - startdeger) * i);
			// System.out.println(item +" "+startdeger+" "+sy+" "+i);
			if (k++ != 0) {
				// System.out.println(lastx + " " + lasty + " " + x + " " + y);
				Color col = g.getColor();
				g.drawLine((int) lastx, (int) lasty, (int) x, (int) y);
				g.setColor(Color.black);
				if (itemx.get("text").equals("start")) {
					g.fillOval((int) x - 4, (int) y - 4, 8, 8);
				} else {
					g.fillOval((int) x - 2, (int) y - 2, 4, 4);
				}
				g.setColor(col);
			}

			lastx = x;
			lasty = y;

			if (k == arr.size()) {

			}

		}
		g.setColor(Color.BLACK);
		int sayac = 0;
		AffineTransform orig = g.getTransform();
		AffineTransform at = new AffineTransform();
		at.rotate(-Math.PI / 2);
		g.setTransform(at);
		for (Map<String, String> itemx : arr) {

			if (sayac++ % xspace == 0) {
				String tarih = itemx.get("tarih");

				g.drawString(tarih.substring(8, 16), -sy - 60, (sx + 20 * xk++ + 20));
			}
		}
		g.setTransform(orig);
	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {

		this.repaint();

	}

	public boolean isFixed() {
		return isFixed;
	}

	public void setFixed(boolean isFixed) {
		this.isFixed = isFixed;
	}

}
