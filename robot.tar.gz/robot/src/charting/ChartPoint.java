package charting;

public class ChartPoint {

}
