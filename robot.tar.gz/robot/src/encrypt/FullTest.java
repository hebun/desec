package encrypt;

import java.io.IOException;

import util.ReadFile;

public class FullTest {
	public static void main(String[] args) throws IOException {


	}
}
