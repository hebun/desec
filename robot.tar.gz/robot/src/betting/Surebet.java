package betting;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bettingutil.DualMac;
import util.MyLogger;
import util.Pro;

public class Surebet {

	private String surebets = "";
	private List<DualMac> surebetsSt = new ArrayList<DualMac>();
	private List<DualMac> pros;

	public Surebet(ArrayList<Map<String, String>> pros) {

	}

//	map.get("tarih") + " | " + map.get("Mac") + " | "
//	+ map.get("odd") + " | " + map.get("deodd") + " | "
//	+ deodd+" | " + map.get("buro");

	public Surebet(List<DualMac> pros) {
		this.pros = pros;

	}

	private HashMap<String, String> dualMacToMap(DualMac mac) {
		HashMap<String, String> map = new HashMap<>();

		Date tarih = mac.getTarih();
		if (tarih == null) {
			map.put("tarih", "null");
		} else {
			map.put("tarih", tarih.toString());
		}

		map.put("Mac", mac.getName());
		map.put("odd", mac.getOdds());
		map.put("deodd", mac.getOdds());
		map.put("buro", mac.getBuroname());
		map.put("profit", mac.getProfit() + "");
		map.put("limitprofit", mac.getLimitprofit() + "");
		return map;
	}

	private int minSb;

	private boolean checkMatch(String match) {
		// Pro.tick("cm");
		String fileName = "sentMatches.txt";

		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {

			String line = br.readLine();

			while (line != null) {

				if (line.equals(match)) {

					return true;

				}

				line = br.readLine();
			}
			return false;

		} catch (IOException e) {

			e.printStackTrace();

		}
		// Pro.tick("cm");
		return false;

	}

	public void findSurebets() {
		for (DualMac mac : pros) {

			HashMap<String, String> map = dualMacToMap(mac);

			double profit = Double.parseDouble(map.get("profit"));
			minSb = map.get("buro").equals("wink") ? -5 : 18;

			if (profit > minSb) {
				String matchRecord = new PrettyPrintingMap(map).matchRecord("de" + map.get("pcol"));
				if (!checkMatch(matchRecord)) {
					try {
						Files.write(Paths.get("sentMatches.txt"), (matchRecord + "\n").getBytes(),
								StandardOpenOption.APPEND);
						surebets = surebets + matchRecord + "\n";
						surebetsSt.add(mac);
					} catch (IOException e) {

					}
				}
			}
		}
	}

	public void sendMail(String to) {

	}

	public String getSurebets() {
		return surebets;
	}

	public void setSurebets(String surebets) {
		this.surebets = surebets;
	}

	public int getMinSb() {
		return minSb;
	}

	public void setMinSb(int minSb) {
		this.minSb = minSb;
	}

	public List<DualMac> getSurebetsSt() {
		return surebetsSt;
	}

	public void setSurebetsSt(List<DualMac> surebetsSt) {
		this.surebetsSt = surebetsSt;
	}
}
