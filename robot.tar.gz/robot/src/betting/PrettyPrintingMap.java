package betting;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class PrettyPrintingMap {
	private Map<String, String> map;

	public PrettyPrintingMap(Map<String, String> map) {
		this.map = map;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		Iterator<Entry<String, String>> iter = map.entrySet().iterator();
		while (iter.hasNext()) {
			Entry<String, String> entry = iter.next();
		//	sb.append(entry.getKey());
			//sb.append('=').append('"');
			sb.append(entry.getValue());
			sb.append(" | ");
			if (iter.hasNext()) {
			//	sb.append(',').append(' ');
			}
		}
		return sb.toString();

	}

	public String matchRecord(String deodd) {
		return map.get("Mac") + " | "
				+ map.get("odd") + " | " + map.get("deodd") + " | "
				+ deodd+" | " +map.get("limitprofit")+" | "+ map.get("buro");
	}
}
