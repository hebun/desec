package betting;

public class Grandbetting {
public static void main(String[] args) {
	try {
		String string = MyRequest.get("https://www.grandbetting75.com/#/livecalendar/");
		
		System.out.println(string);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
