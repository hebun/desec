package betting;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sound.sampled.LineUnavailableException;

import util.LevenshteinDistance;
import util.MyLogger;


public class Compare {
	private MyLogger log = MyLogger.getInstance();
	private double BURO_AMOUNT;
	private double COMISSION;
	private double EURO;
	private double MIN_ODD;
	private double MAX_ODD;
	private List<Map<String, String>> dualMatchs;

	public List<Map<String, String>> getDualMatchs() {
		return dualMatchs;
	}

	public void setDualMatchs(List<Map<String, String>> dualMatchs) {
		this.dualMatchs = dualMatchs;
	}

	public Compare(double BURO_AMOUNT, double COMISSION, double EURO, double MIN_ODD, double MAX_ODD) {

		this.BURO_AMOUNT = BURO_AMOUNT;
		this.COMISSION = COMISSION;
		this.EURO = EURO;
		this.MIN_ODD = MIN_ODD;
		this.MAX_ODD = MAX_ODD;
	}

	private void divideBy100(Map<String, String> map, String col) {
		String value = map.get(col);
		if (value == null)
			return;
		float fv = Float.parseFloat(value) / 100;
		map.put(col, fv + "");
	}

	public double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}

	@SuppressWarnings("unused")
	private Map<String, String> checkPro(Map<String, String> dual, String deodd, String odd) {

		if (dual.get(odd) == null)
			return null;
		if (dual.get(deodd) == null)
			return null;
		double oldHt = (double) Integer.parseInt(dual.get(odd));
		double ht = oldHt / 100;

		double mIN_ODD2 =  MIN_ODD;

		if (ht < mIN_ODD2 || ht > MAX_ODD || dual.get(deodd).equals("000") || ht > 3)
			return null;
		// System.out.println(dual);
		double deht = 0;
		try {
			deht = (double) Integer.parseInt(dual.get(deodd)) / 100;
		} catch (NumberFormatException e1) {
			return null;
		}

		if (ht > deht || (deht - ht) < 10) {
			// System.out.println(ht);

			double fark = (double) (ht - deht);
			double pro = fark / (ht * deht - fark);
			double round = round(pro * 100, 2);
			if (round > 20.0)
				return null;
			Map<String, String> hm = new LinkedHashMap<String, String>();
			hm.put("Mac", dual.get("bfMatch"));

			String min = dual.get("min");
			if (min != null)
				hm.put("min", min);
			hm.put("Buro Mac", dual.get("buroMatch"));
			// hm.put("buroTable", dual.get("buroTable"));
			hm.put("tarih", dual.get("tarih"));
			hm.put("btarih", dual.get("btarih"));
			// hm.put("odd", odd);
			hm.put("Oran", dual.get(odd) + " / " + dual.get(deodd) + " (" + dual.get(deodd + "depth") + ")");

			hm.put("odd", dual.get(odd));
			hm.put("deodd", dual.get(deodd));
			// hm.put("depth", dual.get(deodd + "depth"));

			double cOMISSION2 = dual.get("ex").equals("BF") ? COMISSION : 0.02;
			double C7 = (BURO_AMOUNT * ht * (deht - 1)) / (deht - cOMISSION2);

			double C8 = C7 / EURO;

			double lay = C8 / (deht - 1);

			double netProfit = ht * BURO_AMOUNT - BURO_AMOUNT - C7;

			hm.put("profit", round(netProfit, 2) + "");
			hm.put("pcol", odd);
			hm.put("buro", dual.get("buro") + "->" + dual.get("ex"));
			hm.put("lay", round(lay, 2) + "");
			if (dual.get("score") != null) {
				hm.put("score", dual.get("score"));
			}
			hm.put("buro", dual.get("buro"));

			// if()
			// hm.put("liability", round(C8,2)+"");
			return hm;

		}
		return null;
	}

	public static void main(String[] args) {

		for (int k = 2; k < 8; k++) {
			double last = 0, last2 = 0, last3 = 0;
			for (int i = 10; i < 110; i++) {
				Compare compare = new Compare(1000, 0.035, 4.1, 0.1, 2);

				double ht = 1.0 + (double) i / 100;
				Map<String, String> checkProfit = compare.checkProfit(ht, ht - (double)k/100, last, last2, last3);
				last = Double.parseDouble(checkProfit.get("profit"));
				// last2=Double.parseDouble(checkProfit.get("fark"));
				// last3=Double.parseDouble(checkProfit.get("fark2"));
				System.out.println(checkProfit);
			}
			System.out.println();
			System.out.println();
			
		}
	}

	private Map<String, String> checkProfit(double ht, double deht, double last, double last2, double last3) {

		double mIN_ODD2 = MIN_ODD;

		if (ht > deht || (deht - ht) < 0.1) {
			// System.out.println(ht);

			double fark = (double) (ht - deht);
			double pro = fark / (ht * deht - fark);
			double round = round(pro * 100, 2);
			if (round > 20.0)
				return null;
			Map<String, String> hm = new LinkedHashMap<String, String>();

			hm.put("Oran", ht + " / " + round(deht, 2));

			double cOMISSION2 = COMISSION;
			double C7 = (BURO_AMOUNT * ht * (deht - 1)) / (deht - cOMISSION2);

			double C8 = C7 / EURO;

			double lay = C8 / (deht - 1);

			double netProfit = ht * BURO_AMOUNT - BURO_AMOUNT - C7;

			double rprofit = round(netProfit, 2);
			hm.put("profit", rprofit + "");
			double rfark = round((rprofit - last), 2);
		//	hm.put("fark", rfark + "");

			double rfark2 = round((fark - last2), 2);
			// hm.put("fark2", rfark2 + "");

			double rfark3 = round((rfark2 - last3), 2);
			// hm.put("fark3", rfark3 + "");

			return hm;

		}
		return null;
	}

	public ArrayList<Map<String, String>> findProfitibleMatches(List<Map<String, String>> tempoTable,
			List<Map<String, String>> betfairTable) {
		log.info("started find findProfitibleMatches ");

		dualMatchs = populateDualMatchs(tempoTable, betfairTable);
		log.info("-- fetched " + dualMatchs.size() + " matchs from dualView");

		ArrayList<Map<String, String>> profitibles = new ArrayList<Map<String, String>>();

		for (final Map<String, String> dual : dualMatchs) {

			Map<String, String> checkPro = checkPro(dual, "deht", "ht");
			if (checkPro != null)
				profitibles.add(checkPro);

			checkPro = checkPro(dual, "deat", "at");

			if (checkPro != null)
				profitibles.add(checkPro);

			checkPro = checkPro(dual, "dedraw", "draw");

			if (checkPro != null)
				profitibles.add(checkPro);
			checkPro = checkPro(dual, "deunder", "under");

			if (checkPro != null)
				profitibles.add(checkPro);
			checkPro = checkPro(dual, "deover", "over");

			if (checkPro != null)
				profitibles.add(checkPro);
		}

		profitibles.sort(new Comparator<Map<String, String>>() {

			@Override
			public int compare(Map<String, String> o1, Map<String, String> o2) {
				Double ap = Double.parseDouble(o1.get("profit"));
				Double bp = Double.parseDouble(o2.get("profit"));

				return ap > bp ? -1 : ap == bp ? 0 : 1;

			}
		});
		for (Map<String, String> map : profitibles) {
			String col = "deht";

			divideBy100(map, col);
			divideBy100(map, "ht");
			divideBy100(map, "at");
			divideBy100(map, "deat");
			divideBy100(map, "draw");
			divideBy100(map, "dedraw");

		}
		log.info("-- found " + profitibles.size() + " profitible matchs ");

		return profitibles;
	}

	public List<Map<String, String>> populateDualMatchs(List<Map<String, String>> tempoTable,
			List<Map<String, String>> betfairTable) {

		log.info("started to populate dual matchs");

		log.info("-- got " + tempoTable.size() + " rows for buroTable");

		log.info("-- got " + betfairTable.size() + " rows for betfair");

		List<Map<String, String>> dualList = new ArrayList<Map<String, String>>();
		int foundDualCount = 0;
		for (Map<String, String> rowBetFair : betfairTable) {

			for (Map<String, String> rowTempo : tempoTable) {

				if (rowBetFair.get("homeTeam").equals("Fenerbahce") && rowTempo.get("homeTeam").startsWith("Fener")) {
					System.out.println();
				}
				double similarityAway = LevenshteinDistance
						.similarity(rowBetFair.get("awayTeam").replaceAll("Live!", ""), rowTempo.get("awayTeam"));

				double similarityHome = LevenshteinDistance.similarity(rowBetFair.get("homeTeam"),
						rowTempo.get("homeTeam"));

				if (similarityAway > 0.5 && similarityHome > 0.5) {

					String btarih = rowTempo.get("tarih");
					String bftarih = rowBetFair.get("tarih");
				//	System.out.println(bftarih);
//					if (!btarih.equals("mynull") && !bftarih.equals("mynull")) {
//
//						if (rowBetFair.get("ex").equals("BF") || rowBetFair.get("ex").equals("MB")) {
//							int bsaat = Integer.parseInt(btarih.substring(btarih.length() - 5, btarih.length() - 3));
//
//							int bfsaat = Integer
//									.parseInt(bftarih.substring(bftarih.length() - 5, bftarih.length() - 3));
//
//							int i = (bfsaat + 3) % 24;
//							if (i != bsaat && i != bsaat + 1) {
//								// log.info("wrong matching detected:"
//								// + rowBetFair.get("homeTeam"));
//								continue;
//
//							}
//						}
//						// if (rowBetFair.get("ex").equals("MB")) {
//						// int bsaat = Integer.parseInt(btarih.substring(
//						// btarih.length() - 5, btarih.length() - 3));
//						// int mbsaat = Integer
//						// .parseInt(bftarih.substring(
//						// bftarih.length() - 5,
//						// bftarih.length() - 3));
//						// }
//					}

					foundDualCount++;
					Map<String, String> dualMap = new HashMap<String, String>();

					dualMap.put("bfMatch", rowBetFair.get("homeTeam") + " - " + rowBetFair.get("awayTeam"));
					dualMap.put("buroMatch", rowTempo.get("homeTeam") + " - " + rowTempo.get("awayTeam"));
					dualMap.put("ht", rowTempo.get("ht"));
					dualMap.put("at", rowTempo.get("at"));
					dualMap.put("draw", rowTempo.get("draw"));
					dualMap.put("deht", rowBetFair.get("deht"));
					dualMap.put("deat", rowBetFair.get("deat"));
					dualMap.put("dedraw", rowBetFair.get("dedraw"));
					dualMap.put("under", rowTempo.get("under"));
					dualMap.put("deunder", rowBetFair.get("deunder"));
					dualMap.put("deover", rowBetFair.get("deover"));
					dualMap.put("over", rowTempo.get("over"));

					dualMap.put("dehtdepth", rowBetFair.get("dehtdepth"));
					dualMap.put("deatdepth", rowBetFair.get("deatdepth"));
					dualMap.put("dedrawdepth", rowBetFair.get("dedrawdepth"));
					dualMap.put("deunderdepth", rowBetFair.get("deunderdepth"));
					dualMap.put("deoverdepth", rowBetFair.get("deoverdepth"));
					dualMap.put("min", rowTempo.get("min"));

					dualMap.put("tarih", rowBetFair.get("tarih"));
					dualMap.put("btarih", btarih);
					dualMap.put("buro", rowTempo.get("buro"));
					dualMap.put("ex", rowBetFair.get("ex"));
					if (rowTempo.get("score") != null) {
						dualMap.put("score", rowTempo.get("score"));
					}
					dualList.add(dualMap);
				}
			}
		}
		log.info("-- found " + foundDualCount + " matchs ");

		return dualList;

	}

	public ArrayList<Map<String, String>> findDoubleProfits(ArrayList<Map<String, String>> findProfitibleMatches) {
		ArrayList<Map<String, String>> doubles = new ArrayList<Map<String, String>>();
		int k = 0, i = 0;
		// List<>
		for (Map<String, String> map : findProfitibleMatches) {
			String mac = map.get("Mac");
			i = 0;
			for (Map<String, String> map2 : findProfitibleMatches) {

				if (k == i++) {
					continue;
				}

				if (map2.get("Mac").equals(mac)) {
					doubles.add(map);
				}

			}
			k++;
		}
		Collections.sort(doubles, new Comparator<Map<String, String>>() {

			@Override
			public int compare(Map<String, String> o1, Map<String, String> o2) {

				return o1.get("Mac").compareTo(o2.get("Mac"));
			}
		});
		return doubles;
	}

}
