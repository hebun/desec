package betting;

import javax.swing.JCheckBox;

@SuppressWarnings("serial")
public class MyCheckBox extends JCheckBox {

	BuroBase buro;

	public MyCheckBox(String string) {
		super(string);
	}

	public BuroBase getBuro() {
		return buro;
	}

	public void setBuro(BuroBase buro) {
		this.buro = buro;
	}

}
