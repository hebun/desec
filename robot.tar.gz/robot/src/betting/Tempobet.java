package betting;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.MathContext;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Observer;
import java.util.regex.Pattern;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.cef.OS;
import org.cef.callback.CefStringVisitor;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import bettingutil.Mac;
import util.MyLogger;
import util.Util;


public class Tempobet extends BuroBase {

	private String currurl;

	public Tempobet(String currurl) {
		this.currurl = currurl;
		this.setName("Tempobet");

	}

	protected static final MyLogger log = MyLogger.getInstance();

	public static void main(String[] args) {
		// List<Map<String, String>> matchs = new Tempobet().getMatchs(null);
		// ASCIITable.printTableS(matchs);

		// BotBrowser cefTempo = BotBrowser.getInstance();

		// Util.sleep(10);

		Tempobet tempo = new Tempobet("");
		String fromFile = tempo.getFromFileTempo();
		List<Mac> parse = tempo.parse(fromFile);

		for (Mac mac : parse) {
		//	System.out.println(mac);		
		}
	
		// List<Map<String, String>> bf = new Betfair(false,
		// false).getOddsfairMatches(true);

		// Compare compare = new Compare(1000, 0.03, 7.1, 1, 4);

		// ArrayList<Map<String, String>> findProfitibleMatches =
		// compare.findProfitibleMatches(matchs, bf);
		//
		// Util.printTable(compareForDisplay(findProfitibleMatches));

	}

	protected String getFromFileTempo() {
		try (BufferedReader br = new BufferedReader(new FileReader("C:/Users/lazyCoding/Desktop/tempo.htm"))) {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			return sb.toString();
		} catch (IOException e) {

			e.printStackTrace();
			return "";
		}
	}

	boolean skip = false;

	public List<Map<String, String>> getMatchs(Observer ob, BotBrowser cefTempo, util.Callback call) {
		log.info(this.getName() + " started");
		List<Map<String, String>> datatable = new ArrayList<Map<String, String>>();
		Calendar c = Calendar.getInstance();

		int hour = c.get(Calendar.HOUR_OF_DAY);
	//	System.out.println("our:" + hour);
	//	System.out.println(c);
		String url = "https://www." + currurl + ".com/todays_football.html";
		if (hour > 22) {
		//	System.out.println("tomorr");
			url = "https://www." + currurl + ".com/tomorrows_football.html";
		}

		cefTempo.loadUrl(url);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e1) { //
		}

		cefTempo.getBrowser_().getSource(new CefStringVisitor() {

			public void visit(String string) {
				saveToFile("tempoxx.html", string);
				parsePage(string, datatable);
				call.run(datatable);
				Util.printTable(datatable);
			}
		});

		// String fromFileTempo = getFromFileTempo();
		//
		// parsePage(fromFileTempo, datatable);
		return datatable;
	}

	public boolean isMajorLeague(String text) {

		if (text.contains("SÃ¼per Lig") || text.contains("ngiltere > Premier Lig") || text.contains("spanya > Liga BBVA")
				|| text.contains("spanya > La Liga") || text.contains("talya > Serie A")
				|| text.contains("Almanya > Bundesliga") || text.contains("Fransa > Ligue 1")
				|| text.contains("Å�ampiyonlar Ligi") || text.contains("UEFA Avrupa Ligi")
				|| text.contains("UEFA Uluslar Ligi") || text.contains("tekiz > Primeira Ligi")
				|| text.contains("landa > Eredivisie") || text.contains("Rusya > Premier Lig")
				|| text.contains("Brezilya Serie A")) {
			return true;
		}
		return false;
	}

	private static StringBuffer getFromNetTempo(String url) {
		log.info("getting " + "tempo from net");
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet("https://www.75tempobet.com/todays_football.html?_=1537978514884");
		StringBuffer result = null;

		request.addHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36");
		request.addHeader(":authority", "www.75tempobet.com");
		request.addHeader(":path", "/todays_football.html");
		request.addHeader(":scheme", "https");
		request.addHeader("Host", "www.75tempobet.com");
		request.addHeader("referer", "www.75tempobet.com");
		request.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		request.addHeader("Accept-Language", "en-US,en;q=0.5");
		request.addHeader("Accept-Encoding", "gzip, deflate");
		request.addHeader("Connection", "keep-alive");

		HttpResponse response;
		try {
			response = client.execute(request);

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

			result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line + "\n");

			}
		} catch (IOException e) {

			e.printStackTrace();
		}
		return result;
	}

	@Override
	public List<Map<String, String>> getMatchs(Observer ob) {

		return null;
	}

	public List<Mac> parse(String content) {
		List<Map<String, String>> matches = parsePage(content, new ArrayList<>());
		return convertMapToMac(matches);
	}

	public List<Map<String, String>> parsePage(String string, List<Map<String, String>> datatable) {

		Document doc = Jsoup.parse(string);

		Elements collepsibles = doc.getElementsByClass("collapsible");
		if (collepsibles.size() == 0)
			return datatable;
		Element tablea = collepsibles.get(0);

		Elements trs = tablea.getElementsByTag("tr");

		int k = 0;
		for (Element element : trs) {
			// System.out.println(element.text());

			String ligname = element.parent().parent().parent().previousElementSibling().text();

			if (!isMajorLeague(ligname)) {
				// continue;
			}

			Elements tds = element.getElementsByTag("td");
			String homeTeam = null, awayTeam = null, ht = null, draw = null, at = null, tarih = null;

			if (skip)
				continue;
			if (tds.size() > 4) {

				try {
					int odvalcount = 0;

					for (Element td : tds) {
						if (td.attr("class").equals("team")) {

							String substring = td.text().substring(5, td.text().length());
							homeTeam = substring.split(" - ")[0];
							String att = substring.split(" - ")[1];
							if (att.contains("Canl")) {
								att = att.substring(0, att.length() - 5);
							}
							awayTeam = att;

							String hour = td.text().substring(0, 5);
							tarih = getDate() + hour;

						} else if (td.attr("class").equals("odds")) {

							String dataodval = td.text().replaceAll(Pattern.quote("."), "");
							if (odvalcount == 0) {
								ht = dataodval;
							} else if (odvalcount == 1) {
								draw = dataodval;
							} else if (odvalcount == 2) {
								at = dataodval;
							}
							odvalcount++;

						} else if (td.attr("class").equals("grey")) {
							String text = td.text();

						}
					}

					HashMap<String, String> map = new LinkedHashMap<String, String>();
					map.put("homeTeam", homeTeam);

					map.put("awayTeam", awayTeam);
					map.put("ht", ht);
					map.put("at", at);
					map.put("draw", draw);
					map.put("tarih", tarih);
					map.put("buro", "tempo");

					datatable.add(map);
				} catch (Exception e) {

					e.printStackTrace();
					continue;
				}

			} else {
				// log.info("invalid:" + element.text());
			}
		}
		return datatable;
	}

	private static List<Map<String, String>> compareForDisplay(List<Map<String, String>> findProfitibleMatches) {

		ArrayList<Map<String, String>> ret = new ArrayList<Map<String, String>>();

		for (Map<String, String> map : findProfitibleMatches) {

			LinkedHashMap<String, String> newmap = new LinkedHashMap<>();

			for (Map.Entry<String, String> entry : map.entrySet()) {

				if (!entry.getKey().equals("odd") && !entry.getKey().equals("deodd") && !entry.getKey().equals("lay")
						&& !entry.getKey().equals("tarih") && !entry.getKey().equals("Buro Mac")) {
					newmap.put(entry.getKey(), entry.getValue());
				}
			}

			ret.add(newmap);
		}

		return ret;
	}

	public String getCurrurl() {
		return currurl;
	}

	public void setCurrurl(String currurl) {
		this.currurl = currurl;
	}

	public String getPreLiveUrl() {
		return "https://www." + currurl + ".com/todays_football.html";
	}

}
