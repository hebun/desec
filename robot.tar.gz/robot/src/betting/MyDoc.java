package betting;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MyDoc {
	Document doc;

	public MyDoc(Document base) {
		doc = base;

		// TODO Auto-generated constructor stub
	}

	public Elements getClass(String cl) {
		return doc.getElementsByClass(cl);
	}

	public Element getId(String string) {
		// TODO Auto-generated method stub
		return doc.getElementById(string);
	}
}
