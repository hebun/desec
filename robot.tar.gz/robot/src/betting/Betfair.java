package betting;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Observer;
import java.util.TimeZone;
import java.util.regex.Pattern;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import bettingutil.Mac;
import util.MyLogger;
import util.Sql;
import util.Util;

public class Betfair extends BuroBase {

	/**
	 * current: different lists from imajbet, tarih
	 */

	private final static String USER_AGENT = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:28.0) Gecko/20100101 Firefox/28.0";
	private static final MyLogger log = MyLogger.getInstance();
	private static int callCount = 0;
	private List<Observer> observers = new ArrayList<Observer>();
	private boolean fetchLive;
	private boolean getId;
	private boolean isOnlineOddsfair;

	public Betfair(boolean fetchLive, boolean getId) {
		this.fetchLive = fetchLive;
		this.getId = getId;
		leagues.add("FR, French Ligue 1");
		leagues.add("ES, Spanish La Liga");
		leagues.add("DE, German Bundesliga 1");
		leagues.add("GB, English Premier League");
		leagues.add("IT, Italian Serie A");
		leagues.add("TR, Turkish Super League");
		leagues.add("UEFA Nations League");
		leagues.add("UEFA Champions League");
		leagues.add("Eredivisie");
		leagues.add("PT, Portuguese Primeira");
	}

	public static void main(String[] args) {

		// Calendar c = Calendar.getInstance();
		//
		// int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		//
		// System.out.println(dayOfWeek);
		//

//		Betfair betfair = new Betfair(true, true);
//		List<Map<String, String>> byDay = betfair.getByDay(1, true, null);
//
//		ASCIITable.printTableS(byDay);

		Betfair betfair = new Betfair(false, false);

		List<Mac> oddsfairMatches = betfair.getOddsfairMatches();

		for (Mac mac : oddsfairMatches) {
		System.out.println(mac);
		}

		// StringBuffer fromNet = getFromNet(1);

	}

	public List<Map<String, String>> getLiveFromDb() {

		List<Map<String, String>> table = new Sql.Select().from("bflive").getTable();

		return table;

	}

	public List<Map<String, String>> getLiveFromBf() {

		List<Map<String, String>> matchsStatic = null;

		matchsStatic = getOddsfairMatches(++callCount % 5 == 1);
		String marketIds = "";
		Map<String, Map<String, String>> idName = new HashMap<>();
		for (Map<String, String> map : matchsStatic) {
			idName.put(map.get("externId"), map);
			marketIds += map.get("externId") + ",";
		}
		marketIds.substring(0, marketIds.length() - 1);

		String url = "https://www.betfair.com/www/sports/exchange/readonly/v1/bymarket?currencyCode=EUR&locale=en&alt=json&"
				+ "marketIds=" + marketIds + "&types=RUNNER_EXCHANGE_PRICES_BEST";

		String str = null;

		boolean bfOnline = true;
		if (bfOnline) {
			try {
				log.info("getting bf from net");
				str = MyRequest.get(url);
				// System.out.println(str);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			try {
				str = BuroBase.getFromFile("bfodds.json");
				// System.out.println(str);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		JsonReader jsonReader = Json.createReader(new StringReader(str));
		JsonObject rootObj = jsonReader.readObject();

		JsonObject eventType = rootObj.getJsonArray("eventTypes").getJsonObject(0);

		JsonArray eventNodes = eventType.getJsonArray("eventNodes");
		List<Map<String, String>> matchs = new ArrayList<Map<String, String>>();

		for (int i = 0; i < eventNodes.size(); i++) {

			JsonObject event = eventNodes.getJsonObject(i);

			JsonObject marketNode = event.getJsonArray("marketNodes").getJsonObject(0);

			JsonString marketId = marketNode.getJsonString("marketId");
			// 1.133583998
			String string2 = marketId.getString();
			Map<String, String> teams = idName.get(string2);
			if (teams == null)
				continue;
			String string = teams.toString();
			final Map<String, String> match = new HashMap<String, String>();
			match.put("ex", "BF");
			match.put("tarih", teams.get("tarih"));
			match.put("homeTeam", teams.get("homeTeam"));
			match.put("awayTeam", teams.get("awayTeam"));
			JsonArray runners = marketNode.getJsonArray("runners");

			try {
				Runner runner = getOdd(runners, 0);

				match.put("deht", runner.price + "");
				match.put("dehtdepth", runner.size + "");

				runner = getOdd(runners, 2);

				match.put("dedraw", runner.price + "");
				match.put("dedrawdepth", runner.size + "");

				runner = getOdd(runners, 1);
				match.put("deat", runner.price + "");
				match.put("deatdepth", runner.size + "");

				matchs.add(match);
			} catch (Exception e) {
				log.warning(match.get("homeTeam"));
				continue;
			}

		}

		return matchs;

	}

	private Runner getOdd(JsonArray runners, int pos) throws Exception {

		JsonObject ht = runners.getJsonObject(pos);
		JsonObject exchange = ht.getJsonObject("exchange");
		JsonArray availabletoLay = exchange.getJsonArray("availableToLay");
		JsonObject firstLay = availabletoLay.getJsonObject(0);
		JsonNumber price = firstLay.getJsonNumber("price");
		JsonNumber size = firstLay.getJsonNumber("size");
		return new Runner(price.doubleValue(), size.doubleValue());

	}

	class Runner {
		public int price, size;

		public Runner(double d, double e) {

			price = (int) (d * 100);
			size = (int) (e);
		}

		public String toString() {
			return price + "(" + size + ")";
		}
	}

	class Teams {
		public String ht, at;

		public Teams(String d, String e) {

			ht = d;
			at = e;
		}

		public String toString() {
			return ht + " v " + at + "";
		}
	}

	public void attach(Observer obs) {
		observers.add(obs);
	}

	public List<Map<String, String>> getWeekendOddsfairMatches() {

		List<Map<String, String>> matchs = new ArrayList<Map<String, String>>();

		matchs.addAll(getByDay(0, false, "oddsfaircuma.html"));
		matchs.addAll(getByDay(0, false, "ctesi1.html"));
		matchs.addAll(getByDay(0, false, "pazar1.html"));
		matchs.addAll(getByDay(0, false, "ctesi2.html"));
		matchs.addAll(getByDay(0, false, "pazar2.html"));
		matchs.addAll(getByDay(0, false, "ctesi3.html"));
		matchs.addAll(getByDay(0, false, "pazar3.html"));

		return matchs;
	}

	public List<Mac> getOddsfairMatches() {
		return convertMapToMac(getOddsfairMatches(true));
	}

	public List<Mac> convertMapToMac(List<Map<String, String>> oddsfair) {

		List<Mac> list = new ArrayList<Mac>();

		for (Map<String, String> map : oddsfair) {
			Mac mac = new Mac();
			try {
				if (map.get("buro") != null)
					mac.setBuro(map.get("buro").toLowerCase());
				mac.setHometeam(map.get("homeTeam"));
				mac.setAwayteam(map.get("awayTeam"));
				mac.setHt(Integer.parseInt(map.get("deht")));
				mac.setAt(Integer.parseInt(map.get("deat")));
				mac.setDraw(Integer.parseInt(map.get("dedraw")));
				mac.setTarih(Util.getTimeFromString(map.get("tarih")));
				mac.setDepth(Util.getIntSafe(map.get("depth")));
			} catch (Exception e) {

			}
			mac.setLive(false);
			list.add(mac);
		}
		return list;
	}

	public List<Map<String, String>> getOddsfairMatches(boolean isOnline) {
		log.info("oddsfair  started");

		TimeZone london = TimeZone.getTimeZone("GMT+8");
		long now = System.currentTimeMillis();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");

		long l = now + london.getOffset(now);

		Calendar instance = Calendar.getInstance();

		String time = sdf.format(instance.getTime());

		List<Map<String, String>> matchs = new ArrayList<Map<String, String>>();

		matchs.addAll(getByDay(1, isOnline, null));

//		if (isOnline) {
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			matchs.addAll(getByDay(2, isOnline, null));
//
//			Calendar c = Calendar.getInstance();
//
//			int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
//			if (dayOfWeek == 1 || dayOfWeek == 7) {
//				try {
//					Thread.sleep(1000);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				matchs.addAll(getByDay(3, isOnline, null));
//			}
//		}

		return matchs;

	}

	ArrayList<String> leagues = new ArrayList<String>();

	public boolean isMajorLeague(String league) {

		for (String string : leagues) {
			if (string.contains(league))
				return true;
		}

		return false;

	}

	private List<Map<String, String>> getByDay(int page, boolean isOnline, String file) {

		String sub;

		if (isOnline) {

			StringBuffer result = getFromNet(page);
//System.out.println(result.toString());
			sub = result.toString();
			saveToFile("oddsfair.html", sub);

		} else {

			sub = getFromFile("C:\\Users\\ismet\\Desktop\\folder\\oddsfair.html");

		}
		Document doc = Jsoup.parse(sub);
		List<Map<String, String>> matchs = new ArrayList<Map<String, String>>();
		Elements trs = doc.getElementsByClass("table_line1");
		for (Element element : trs) {
			Elements tds = element.getElementsByTag("td");
			int tdCount = 0;
			int tdSay = 0;
			final Map<String, String> match = new HashMap<String, String>();
			match.put("ex", "BF");
			boolean depthSet = false;
			for (Element td : tds) {
				if (td.parent() == element) {

					// System.out.println(tdSay+":"+td.text());

					if (td.hasAttr("class")) {
						String tdtext = td.text();
						if (tdtext.contains("PSV")) {
							System.out.println(".");
						}
						String[] split = tdtext.trim().split(" v ");
						String homet = split[0];
						String httrim = homet.replace('\u00A0', ' ').trim();
						for (Character ch : httrim.toCharArray()) {
							// System.out.println((int)ch);
						}
						match.put("homeTeam", httrim);
						String awayt = split[1];
						match.put("awayTeam", awayt.replace('\u00A0', ' ').trim());
						String query = td.getElementsByTag("a").attr("href").split(Pattern.quote("?"))[1];
						try {
							Map<String, String> splitQuery = splitQuery(query);
							String id = splitQuery.get("id");
							match.put("externId", id);

							// System.out.println(id+"="+split[0]);
						} catch (UnsupportedEncodingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
					if (tdSay == 1) {
						java.text.SimpleDateFormat sdft = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm");
						try {
							java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");

							Calendar instance = Calendar.getInstance();
							String tdtext = td.text();
							String time = sdf.format(instance.getTime());
							String timeText = time + " " + tdtext;
							match.put("tarih", timeText);

							sdft.parse(timeText);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

					if (tdSay == 0) {
					//	if (td.attr("height").equals("60")) {
							Element img = td.getElementsByTag("img").first();
							String alt = img.attr("title");
							if (!isMajorLeague(alt)) {
								// break;
							}
						//}
					}
					Elements tables = td.getElementsByTag("table");
					if (tables.size() > 0) {
						String text = tables.get(0).getElementsByClass("layblock").text();
						String odd = text.replaceAll(Pattern.quote("."), "");
						Elements intr = tables.get(0).getElementsByTag("tr");
						String laydepth = "";

						Element depthTd = intr.get(1).getElementById("lay");
						if (depthTd == null) {
							depthTd = intr.get(1).getElementById("lay2");
						}
						if (depthTd == null) {
							depthTd = intr.get(1).getElementById("lay3");
						}
						if (depthTd != null)
							laydepth = depthTd.text();

						if (tdCount == 0) {
							match.put("dehtdepth", laydepth);
							match.put("deht", odd);
						}
						if (tdCount == 1) {
							match.put("dedrawdepth", laydepth);
							match.put("dedraw", odd);
						}
						if (tdCount == 2) {
							match.put("deatdepth", laydepth);
							match.put("deat", odd);
						}
						if (tdCount == 3) {
							match.put("deunderdepth", laydepth);
							match.put("deunder", odd);
						}
						if (tdCount == 4) {
							match.put("deoverdepth", laydepth);
							match.put("deover", odd);
						}

						tdCount++;
					}
					Elements strongs = td.getElementsByTag("strong");
					if (strongs.size() > 0 && !depthSet) {

						Element stro = strongs.get(0);
						if (stro.getElementsByTag("a").size() == 0) {
							match.put("depth", stro.text().substring(1));
						//	System.out.println(stro.text());
							depthSet = true;
						}
					}
					tdSay++;
				}

			}

			if (match.get("awayTeam") != null) {
				if (match.get("awayTeam").indexOf("Live!") < 0)
					matchs.add(match);
			}

			// break;
		}
		return matchs;

	}

	public static Map<String, String> splitQuery(String query) throws UnsupportedEncodingException {
		Map<String, String> query_pairs = new LinkedHashMap<String, String>();

		String[] pairs = query.split("&");
		for (String pair : pairs) {
			int idx = pair.indexOf("=");
			query_pairs.put(URLDecoder.decode(pair.substring(0, idx), "UTF-8"),
					URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
		}
		return query_pairs;
	}

	private static StringBuffer getFromNet(int page) {

		String url = "https://www.oddsfair.net/index.php?tmpl=ajaxmoduleloader&moduleposition=soccerfresh";

		log.info("getting oddsfair from net");
		HttpClient client = HttpClientBuilder.create().build();
		HttpPost request = new HttpPost(url);
		StringBuffer result = null;
		// add request header
		request.addHeader("User-Agent", USER_AGENT);
		// request.addHeader("X-Requested-With", "XMLHttpRequest");
		request.addHeader("Referer", "http://www.oddsfair.net/");
		for (Header head : request.getAllHeaders()) {
			// System.out.println(head.getName() + ":" + head.getValue());
		}
		List<NameValuePair> params = new ArrayList<NameValuePair>(2);
		if (page < 2)
			params.add(new BasicNameValuePair("order", "1x2desc"));
		else {
			params.add(new BasicNameValuePair("order", "1x2desc"));
			params.add(new BasicNameValuePair("pagipage-football", page + ""));
		}

		Calendar c = Calendar.getInstance();

		int hour = c.get(Calendar.HOUR_OF_DAY);

		if (hour >= 23) {
			params.add(new BasicNameValuePair("backlaydate-football", Util.getFormattedDateTomorrow() + ""));

		} else if (hour < 4) {
			params.add(new BasicNameValuePair("backlaydate-football", Util.getFormattedDateToday() + ""));
		}

		try {
			request.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
		} catch (UnsupportedEncodingException e1) {

			e1.printStackTrace();
		}

		HttpResponse response;
		try {
			response = client.execute(request);

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

			result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line + "\n");

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println(result);
		// System.out.println(result);
		return result;
	}

	public List<Map<String, String>> getMatchs() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, String>> getMatchs(Observer ob) {
		// TODO Auto-generated method stub
		return null;
	}

}
