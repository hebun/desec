package betting;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Observer;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;

import bettingutil.Mac;
import util.MyLogger;
import util.Util;


public abstract class BuroBase {
	public final static String USER_AGENT = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:28.0) Gecko/20100101 Firefox/28.0";
	protected static final MyLogger log =MyLogger.getInstance();
	protected String name;
	protected String originalName;

	public String getOriginalName() {
		return originalName;
	}

	public void setOriginalName(String originalName) {
		this.originalName = originalName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
		setOriginalName(name.replaceAll("\\d", ""));
	}

	public List<Mac> convertMapToMac(List<Map<String, String>> oddsfair) {

		List<Mac> list = new ArrayList<Mac>();

		for (Map<String, String> map : oddsfair) {
			Mac mac = new Mac();
			try {
				if (map.get("buro") != null)
					mac.setBuro(map.get("buro").toLowerCase());
				mac.setHometeam(map.get("homeTeam"));
				mac.setAwayteam(map.get("awayTeam"));
				mac.setHt(Integer.parseInt(map.get("ht")));
				mac.setAt(Integer.parseInt(map.get("at")));
				mac.setDraw(Integer.parseInt(map.get("draw")));

				mac.setTarih(Util.getTimeFromString(map.get("tarih")));
			} catch (Exception e) {

			}
			mac.setLive(false);
			//System.out.println(mac);
			list.add(mac);
		}
		return list;
	}

	protected static void updateOb(Observer ob) {
		if (ob == null)
			return;
		ob.update(null, 10);
	}

	public static Map<String, String> splitQuery(String query) throws UnsupportedEncodingException {
		Map<String, String> query_pairs = new LinkedHashMap<String, String>();

		String[] pairs = query.split("&");
		for (String pair : pairs) {
			int idx = pair.indexOf("=");
			query_pairs.put(URLDecoder.decode(pair.substring(0, idx), "UTF-8"),
					URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
		}
		return query_pairs;
	}

	public String getDate() {
		return Calendar.getInstance().get(Calendar.YEAR) + "-" + (Calendar.getInstance().get(Calendar.MONTH) + 1) + "-"
				+ Calendar.getInstance().get(Calendar.DAY_OF_MONTH) + " ";
	}

	public static void saveToFile(String filename, String stringBuffer) {
		try {

			Files.write(Paths.get("./" + filename + ""), stringBuffer.getBytes());
		} catch (IOException e1) {

			e1.printStackTrace();
		}
	}

	public static String getFromFile(String name) {
		log.info("getting " + name + " from file");
		FileReader fileReader = null;
		try {
			fileReader = new FileReader(name);
			// System.out.println(Paths.get("./").toAbsolutePath().toString());
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		}
		try (BufferedReader br = new BufferedReader(fileReader)) {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			return sb.toString();
		} catch (IOException e) {

			e.printStackTrace();
			return "";
		}
	}

	static String getFromFileHeader() {
		FileReader fileReader = null;
		try {
			fileReader = new FileReader("header.ini");
			// System.out.println(Paths.get("./").toAbsolutePath().toString());
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		}
		try (BufferedReader br = new BufferedReader(fileReader)) {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);

				line = br.readLine();
			}
			return sb.toString();
		} catch (IOException e) {

			e.printStackTrace();
			return "";
		}
	}

	public static void main(String[] args) {
		java.util.logging.Logger.getLogger("org.apache.http.wire").setLevel(java.util.logging.Level.FINEST);
		java.util.logging.Logger.getLogger("org.apache.http.headers").setLevel(java.util.logging.Level.FINEST);

		System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.SimpleLog");
		System.setProperty("org.apache.commons.logging.simplelog.showdatetime", "true");
		System.setProperty("org.apache.commons.logging.simplelog.log.httpclient.wire", "debug");
		System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http", "debug");
		System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.headers", "debug");

		String str = new PronetLive("pera").getFromNetPera("http://perabet18.com/today/1/").toString();
		//System.out.println(str);
	}

	protected StringBuffer getFromNetPera(String url) {

		log.info("getting " + this.getClass().getName() + " from net");
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);
		StringBuffer result = null;

		addHeader("header", request);

		//System.out.println(request);
		// if (true)
		// return null;
		HttpResponse response;
		try {
			response = client.execute(request);

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

			result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line + "\n");

			}
		} catch (IOException e) {

			e.printStackTrace();
		}
		return result;
	}

	private void addHeader(String filename, HttpGet request) {
		FileReader fileReader = null;
		try {
			fileReader = new FileReader("header.ini");
			// System.out.println(Paths.get("./").toAbsolutePath().toString());
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		}
		try (BufferedReader br = new BufferedReader(fileReader)) {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				String bla[] = line.split(": ");
				if (bla.length > 1)
					request.addHeader(bla[0], bla[1]);

				line = br.readLine();
			}

		} catch (IOException e) {

			e.printStackTrace();

		}
	}

	public boolean isMajorLeague(String text) {

		if (text.contains("S�per Lig") || text.contains("Premier Lig") || text.contains("spanya > Liga BBVA")
				|| text.contains("LaLiga") || text.contains("Serie A") || text.contains("Bundesliga")
				|| text.contains("Ligue 1") || text.contains("�ampiyonlar Ligi") || text.contains("UEFA Avrupa Ligi")
				|| text.contains("UEFA Uluslar Ligi") || text.contains("Eredivisie")) {
			return true;
		}
		return false;
	}

	protected StringBuffer getFromNet(String url) {
		log.info("getting " + this.getClass().getName() + " from net");
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);
		StringBuffer result = null;

		request.addHeader("User-Agent", USER_AGENT);

		request.addHeader("Referer", "http://" + this.getName() + ".com");
		// request.addHeader("Cookie", "Comm100_CC_Identity_100001513=259356;
		// JSESSIONID=832cf9e0537010b1319d2b9e96af; trd=jasminbet;
		// websocket-url=socket-g1.pronetstatic.com; lang=2;
		// token=77ac307f9bbd9134ebefd4d092294da4;
		// token2=77ac307f9bbd9134ebefd4d092294da4; user_timezone=-180;
		// comm100_session_100001513=-460287;
		// comm100_guid2_100001513=70d4b820374d43ac84fbdd775fd748a1;
		// __nxquid=9euaFQAAAADy2UfvTrkOvQ==94420005; __nxqsid=15057918000005");

		HttpResponse response;
		try {
			response = client.execute(request);

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

			result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line + "\n");

			}
		} catch (IOException e) {

			e.printStackTrace();
		}
		return result;
	}

	public abstract List<Map<String, String>> getMatchs(Observer ob);
}
