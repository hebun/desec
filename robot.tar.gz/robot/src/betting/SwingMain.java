package betting;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import util.MyLogger;


public class SwingMain {
	/**
	 * match table update * - dont send under 100euro,- save current.txt to
	 * public_html/php,- include depth to mail,- better formating for android
	 * view last machts, remove hapoels, - add name allies system and get them
	 * from- file, - -matchbook timezone ,- config file
	 */
	private static final MyLogger log =MyLogger.getInstance();
	public static final double BURO_AMOUNT = 1000;

	private static double MIN_ODD = 2;
	private static final double COMISSION = 0.065;
	private static final double EURO = 3.30;
	private static final double MAX_ODD = 4;
	public static boolean auto = true;
	public static boolean debug = true;
	public static Properties prob = new Properties();

	public static ArrayList<Map<String, String>> getProfits() {
		List<Map<String, String>> imaj = new ArrayList<Map<String, String>>();
	
		imaj.addAll(new Pronet("imajbet").getMatchs(null));

		Compare compare = new Compare(BURO_AMOUNT, COMISSION, EURO, MIN_ODD, MAX_ODD);
	
		return null;

	}

	public static void main(String[] args) throws InterruptedException {
		// a aretmis
		// w wonclub
		// i imajbet
		// s safirbet
		// t tempobet
		// b betvole

		launch();
		
		
		
		//extracted();

	}

	public static void launch() {
		Compare compare=new Compare(1000, 0.035, 4.68, 1.01, 3);
		
		List<Map<String,String>> matchs = new Tempobet("").getMatchs(null);
		
		List<Map<String,String>> oddsfairMatches = new Betfair(false,true).getOddsfairMatches(true);
		
		ArrayList<Map<String,String>> findProfitibleMatches = compare.findProfitibleMatches(matchs, oddsfairMatches);
		
	//	ASCIITable.printTableS(compare.getDualMatchs());
		ASCIITable.printTableS(findProfitibleMatches);
	}

	private static void extracted() throws InterruptedException {
		try {
			prob.load(new FileInputStream("config.properties"));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		System.out.println(prob.toString());
		while (true) {
			log.info("Application Started");
			try {
				auto = prob.getProperty("auto").equals("true");

				List<Map<String, String>> imaj = new ArrayList<Map<String, String>>();

				String buros = prob.getProperty("buros");
				if (buros.contains("w")) {
				
				}
				if (buros.contains("s")) {
					imaj.addAll(new Pronet("safirbet2").getMatchs(null));
				}
				if (buros.contains("i")) {
					imaj.addAll(new Pronet("imajbet4").getMatchs(null));
				}
				if (buros.contains("b")) {
					imaj.addAll(new Pronet("betvole50").getMatchs(null));
				}
				if (buros.contains("g")) {
					imaj.addAll(new Pronet("belugabetting44").getMatchs(null));
				}
				if (buros.contains("r")) {
					imaj.addAll(new Pronet("restbet8").getMatchs(null));
				}
				if (buros.contains("t")) {
					imaj.addAll(new Tempobet("").getMatchs(null));
				}
				if (buros.contains("m")) {
					imaj.addAll(new Marathon().getMatchs(null));
				}
				if (buros.contains("o")) {
					imaj.addAll(new Pronet("stonebet1").getMatchs(null));
				}
				if (buros.contains("a")) {
			
				}
				// imaj.addAll(WonClub.live());
				MIN_ODD = Double.parseDouble(prob.getProperty("minodd"));

				Compare compare = new Compare(BURO_AMOUNT, COMISSION, EURO, MIN_ODD, MAX_ODD);
				List<Map<String, String>> bf;
				final ArrayList<Map<String, String>> findProfitibleMatches = new ArrayList<Map<String, String>>();

				if (prob.getProperty("domb").equals("true")) {
				
				}
				if (prob.getProperty("dobf").equals("true")) {

					try {
						findProfitibleMatches
								.addAll(compare.findProfitibleMatches(imaj, null));
					} catch (Exception e) {
						log.warning("matchbook threw exception");
						e.printStackTrace();
					}
				}

				findProfitibleMatches.sort(new Comparator<Map<String, String>>() {

					@Override
					public int compare(Map<String, String> o1, Map<String, String> o2) {
						Double ap = Double.parseDouble(o1.get("profit"));
						Double bp = Double.parseDouble(o2.get("profit"));

						return ap > bp ? -1 : ap == bp ? 0 : 1;

					}
				});

				if (prob.getProperty("sendmail").equals("true")) {
					try {
						Surebet surebet = new Surebet(findProfitibleMatches);

						surebet.findSurebets();
						System.out.println(surebet.getSurebets());
						if (surebet.getSurebets().length() > 1) {
							java.awt.Toolkit.getDefaultToolkit().beep();
							ASCIITable.printTableS(findProfitibleMatches);
						}
						// surebet.sendMail(prob.getProperty("mailto"));
					} catch (Exception e) {

						log.severe("error sending email");

						e.printStackTrace();
					}
				}
				/**
				 * trim long team names
				 */
				for (Map<String, String> map : findProfitibleMatches) {

					String mac = map.get("Mac");
					if (mac.length() > 28) {
						int diff = mac.length() - 28;

						map.put("Mac", ".." + mac.substring(diff / 2, diff / 2 + 24) + "..");
					}
				}
				if (!auto)
					ASCIITable.printTableS(findProfitibleMatches);
				else {
					ASCIITable.toFile = true;
					ASCIITable.currentsFile = prob.getProperty("currentsfile");
					ASCIITable.printTableS(findProfitibleMatches);
				}
			} catch (Exception e) {
				log.severe("application stopped:");
				e.printStackTrace();

			}
			Thread.sleep(5*60*1000);
			// Measure.dump();
		}
	}

	private static final long serialVersionUID = 4741507128571219377L;

}
