package creditcardanalyze;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import util.ReadFile;

public class FromCSV {
	public static void main(String[] args) throws IOException {
		ReadFile readFile = new ReadFile("aralik.csv", "|", ",");

		List<Map<String, String>> table = readFile.getTable(new ArrayList<>());
		int yemeicme = 0;
		for (Map<String, String> map : table) {
			if (map.get("2.col")!=null&& map.get("2.col").startsWith("Market")) {
				int mas = Integer.parseInt(map.get("5.col"));
				yemeicme += mas;
			}
			
		}
		System.out.println(yemeicme);
	}
}
