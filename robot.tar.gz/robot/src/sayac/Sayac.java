package sayac;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Observer;
import java.util.Timer;
import java.util.TimerTask;

import fxcomps.BaseWindow;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.util.Duration;
import robot.ProcessInt;

public class Sayac extends BaseWindow<FlowPane> implements ProcessInt {
	private Label label;

	private boolean running = true;
	private boolean started = false;

	private Observer ob;

	public Sayac() {
		rootNode = new FlowPane();
		label = new Label("lkajsdfj");
		Button button = new Button("refresh");
		button.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				refresh();
			}
		});

		rootNode.getChildren().add(label);
		rootNode.getChildren().add(button);

	}

	private String getDiff(long diff) {
		long diffSeconds = diff / 1000 % 60;
		long diffMinutes = diff / (60 * 1000) % 60;
		long l = diff / (60 * 60 * 1000);
		long diffHours = l % 24;
		long diffDays = diff / (24 * 60 * 60 * 1000);
		String ret = "";
		ret += diffDays > 0 ? diffDays + " day(s) " : "";
		ret += diffHours > 0 ? diffHours + " hour(s) " : "";
		ret += diffMinutes > 0 ? diffMinutes + " minute(s) " : "";

		ret += diffSeconds > 0 ? diffSeconds + " second(s) " : "";

		ret += l > 0 ? ". " + l + " hours in total" : "";
		return ret;
	}

	public void refresh() {
		System.out.println("refresing sayac");
		// Calendar calendar = new GregorianCalendar(2019, 4, 17, 9, 0, 0);
		Calendar calendar = new GregorianCalendar(2020, 2, 15, 2, 0, 0);

		long diff = Calendar.getInstance().getTimeInMillis() - calendar.getTimeInMillis();

		label.setText(getDiff(diff));

	}

	@Override
	public String getTitle() {
		return "Sayac";
	}

	@Override
	public void start() {
		Timeline fiveSecondsWonder = new Timeline(new KeyFrame(Duration.seconds(10), e -> {
			if (running) {
				Platform.runLater(new Runnable() {

					@Override
					public void run() {
						refresh();
					}
				});
			}else {
				ob.update(null, "");
			}
		}));
		fiveSecondsWonder.setCycleCount(Timeline.INDEFINITE);
		fiveSecondsWonder.play();
		started = true;
	}

	@Override
	public void resume() {running = true;
		if (!started) {
			start();
		}
		
	}

	@Override
	public void sendMessage(ProcessInt source, Date time, String msg) {
		
	}
	@Override
	public void setObserver(Observer ob) {
		this.ob = ob;
	
	}
	@Override
	public void stop() {
		running = false;
	}
}
