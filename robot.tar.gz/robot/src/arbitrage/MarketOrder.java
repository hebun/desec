package arbitrage;

public class MarketOrder {
	String side;
	double price;
	@Override
	public String toString() {
		return "MarketOrder [side=" + side + ", price=" + price + ", quantity=" + quantity + "]";
	}
	double quantity;
	public MarketOrder() {
	
	}
	public String getSide() {
		return side;
	}
	public void setSide(String side) {
		this.side = side;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
}
