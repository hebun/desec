package arbitrage;

public class SymbolPrice {
	String symbol;
	double price;
	private double volume;
	private String exchange;
	private String address;

	@Override
	public String toString() {
		return "SymbolPrice [symbol=" + symbol + ", price=" + price + ", volume=" + volume + ", address="+address+"]";
	}

	public SymbolPrice(String symbol, double price) {
		super();
		this.symbol = symbol;
		this.price = price;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getExchange() {
		return exchange;
	}

	public void setExchange(String exchange) {
		this.exchange = exchange;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
