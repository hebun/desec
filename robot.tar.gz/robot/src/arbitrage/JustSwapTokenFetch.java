package arbitrage;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;

import util.Util;

public class JustSwapTokenFetch {
	private List<String> tokens;
	private List<SymbolPrice> prices;

	public JustSwapTokenFetch(List<String> tokens) {
		this.tokens = tokens;

	}

	public List<SymbolPrice> fetchPrices() {

		WebRequest r = new WebRequest();

		setPrices(new ArrayList<SymbolPrice>());
		for (String token : tokens) {

			long unix = System.currentTimeMillis() / 1000;
			String jsurl = "https://apilist.tronscan.org/api/justswap/kline?" + "token_address=" + token
					+ "&granularity=5min&" + "time_start=" + (unix - 5 * 60 * 1000) + "&" + "time_end=" + unix
					+ "&type=1";
			System.out.println(jsurl);
			StringBuffer fromNet = r.getFromNet(jsurl);

			JsonReader jsonReader = Json.createReader(new StringReader(fromNet.toString()));

			JsonObject jo = jsonReader.readObject();
			JsonArray arr = jo.getJsonArray("data");

			JsonString jsonString = arr.getJsonObject(arr.size() - 1).getJsonString("c");

			double price = Util.getDoubleSafe(jsonString.toString().substring(1, jsonString.toString().length() - 1));

			SymbolPrice sp = new SymbolPrice(token, price);

			prices.add(sp);
			Util.sleep(2);
		}
		return prices;

	}

	public List<SymbolPrice> getPrices() {
		return prices;
	}

	public void setPrices(List<SymbolPrice> prices) {
		this.prices = prices;
	}

	public static void main(String[] args) {
		JustSwapTokenFetch jss = new JustSwapTokenFetch(Arrays.asList( "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"));
		for (int i = 0; i < 100; i++) {
			jss.fetchPrices();
			List<SymbolPrice> pr = jss.getPrices();
			for (SymbolPrice symbolPrice : pr) {
				System.out.println(symbolPrice.price);
			}

			Util.sleep(10);
		}
	}
}
