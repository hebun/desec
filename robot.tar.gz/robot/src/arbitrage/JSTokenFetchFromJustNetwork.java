package arbitrage;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;

import util.Util;

public class JSTokenFetchFromJustNetwork {
	private List<String> tokens;
	private List<SymbolPrice> prices;

	public JSTokenFetchFromJustNetwork(List<String> tokens) {
		this.tokens = tokens;

	}

	public List<SymbolPrice> fetchPrices() {

		WebRequest r = new WebRequest();

		setPrices(new ArrayList<SymbolPrice>());
		for (String token : tokens) {

		
			String jsurl = "https://api.just.network/swap/scan/statusinfo?exchangeAddress="+token;
			System.out.println(jsurl);
			StringBuffer fromNet = r.getFromNet(jsurl);

			JsonReader jsonReader = Json.createReader(new StringReader(fromNet.toString()));

			JsonObject jo = jsonReader.readObject();
			System.out.println(jo);
			JsonObject arr = jo.getJsonObject("data");

			JsonNumber jsonNo = arr.getJsonNumber("trxPrice");

			double price =jsonNo.doubleValue();

			SymbolPrice sp = new SymbolPrice(token, price);

			prices.add(sp);
			Util.sleep(2);
		}
		return prices;

	}

	public List<SymbolPrice> getPrices() {
		return prices;
	}

	public void setPrices(List<SymbolPrice> prices) {
		this.prices = prices;
	}

	public static void main(String[] args) {
		JSTokenFetchFromJustNetwork jss = new JSTokenFetchFromJustNetwork(
				Arrays.asList("TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE"));
		for (int i = 0; i < 100; i++) {
			jss.fetchPrices();
			List<SymbolPrice> pr = jss.getPrices();
			for (SymbolPrice symbolPrice : pr) {
				System.out.println(symbolPrice.price);
			}

			Util.sleep(10);
		}
	}
}
