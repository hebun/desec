package arbitrage;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import util.ReadFile;
import util.Util;

public class JustSwapCompare extends JPanel {
	private JTextArea area;

	public JustSwapCompare() {
		this.setName("Just Swap Compare");
		this.setLayout(null);
		area = new JTextArea();
		area.setLocation(10, 10);
		area.setSize(600, 800);
		this.add(area);

		JButton button = new JButton("close");

		button.setSize(100, 20);
		button.setLocation(600, 10);
		button.addActionListener(k -> {
			// System.exit(0);
		});
		this.add(button);

		JButton minmax = new JButton("minMax");

		minmax.setSize(100, 20);
		minmax.setLocation(600, 200);
		minmax.addActionListener(k -> {
			// area.append(minMax());
			JSCompareGraph g = new JSCompareGraph("3.col");
			g.showGraph();
		});
		this.add(minmax);

	}

	public static void main(String[] args) {

		observerThread();
		fetchOdds();
		// minMax();

	}

	private static long lastUpdated = System.currentTimeMillis();

	private static void observerThread() {

		new Thread(() -> {
			while (true) {
				if (System.currentTimeMillis() - lastUpdated > 1000 * 120) {

					Util.tone(700, 1000, 0.05);

				}
				Util.sleep(15);
			}
		}).start();

	}

	private static String minMax() {
		ReadFile readFile = new ReadFile("C:/folder/jsbtcturketh.txt", null, ":");
		List<Map<String, String>> table = readFile.getTable(null);
		List<Double> orans = new ArrayList<Double>();

		double max = -100000, min = 10000;
		for (Map<String, String> map : table) {
			String ethp = map.get("3.col").split("  ")[0].trim();
			Double oran = Util.getDoubleSafe(ethp);
			if (oran > max)
				max = oran;
			if (oran < min)
				min = oran;
			orans.add(oran);
		}

		String x = "max:" + max + " " + min;
		System.out.println(x);
		return x;
	}

	public static void fetchOdds() {
		JustSwapCompare view = new JustSwapCompare();
		Util.launchOneTab(view, 800);
		JustSwapTokenFetch jss = new JustSwapTokenFetch(Arrays.asList("THb4CqiFdwNHsWsQCs4JhzwjMWys4aqCbF",
				"TN3W4H6rK2ce4vX9YnFQHwKENnHjoxb3m9", "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"));
		Map<String, String> doviz = null;
		double dollar = 0;
		for (int i = 0; i < 100000; i++) {

			try {
				BtcTurk btcTurk = new BtcTurk(0);
				btcTurk.fetch();
				double btcturkethtry = Util.getDoubleSafe(btcTurk.getMap().get("eths"));
				double btcturkbtctry = Util.getDoubleSafe(btcTurk.getMap().get("btcs"));
				double btcturktrxtry = (Util.getDoubleSafe(btcTurk.getMap().get("trxs"))
						+ Util.getDoubleSafe(btcTurk.getMap().get("trxa"))) / 2;

				jss.fetchPrices();
				double jsethtrx = jss.getPrices().get(0).getPrice();
				double jsethprice = jsethtrx * btcturktrxtry;

				double jsbtcprice = jss.getPrices().get(1).getPrice() * btcturktrxtry;
				if (i % 100 == 0) {
					doviz = Util.fetchDoviz();
					dollar = Util.getDouble(doviz.get("usd"));
				}
				double jstrxprice = 0;
				if (jss.getPrices().size() > 2)
					jstrxprice = (1 / jss.getPrices().get(2).getPrice()) * dollar;
				System.out.println(jsethtrx + "  "+jstrxprice+":" + btcturktrxtry);
				double x = jsethprice / btcturkethtry;
				double y = jsbtcprice / btcturkbtctry;
				String formatedOraneth = Util.formatDouble(x, 3);
				String formatedOranbtc = Util.formatDouble(jsbtcprice / btcturkbtctry, 3);
				System.out.println(formatedOraneth + "  " + formatedOranbtc);
				String toFile = formatLine(btcturkethtry, jsethprice, btcturkbtctry, jsbtcprice, btcturktrxtry,
						jstrxprice);
				Util.appendToFile("jsbtcturketh.txt", toFile);
				view.update(jsethprice, btcturkethtry, jsbtcprice, btcturkbtctry, btcturktrxtry, jstrxprice);
				if (x > 1.02 || x < 0.98 || y > 1.02 || y < 0.98) {
					Util.tone(700, 100, 0.05);
					Util.tone(700, 100, 0.05);
				}
				lastUpdated = System.currentTimeMillis();
			} catch (Exception e) {
				view.log("exp:" + e.getMessage());
				Util.appendToFile("jsbtcturklog.txt", e.getMessage());
				e.printStackTrace();
			}
			Util.sleep(30);
		}
	}

	private void log(String string) {
		area.append(string);

	}

	public static String formatLine(double btcturkethtry, double jsethprice, double btcturkbtctry, double jsbtcprice,
			double btcturktrxtry, double jstrxprice) {
		String formatedOranBtc = Util.formatDouble(jsbtcprice / btcturkbtctry, 3);
		String formatedOran = Util.formatDouble(jsethprice / btcturkethtry, 3);
		return Util.getFormattedTime().substring(8) + " " + Util.formatDouble(jsethprice, 3) + " -> "
				+ Util.formatDouble(btcturkethtry) + " : " + formatedOran + "      " + Util.formatDouble(jsbtcprice, 3)
				+ " -> " + Util.formatDouble(btcturkbtctry) + " : " + formatedOranBtc + "      " + "  "
				+ Util.formatDouble(jstrxprice, 3) + " -> " + Util.formatDouble(btcturktrxtry, 3) + " : "
				+ Util.formatDouble(jstrxprice / btcturktrxtry, 3);
	}

	private void update(double x, double btcturkethtry, double jsbtcprice, double btcturkbtctry, double btcturktrxtry,
			double jstrxprice) {

		area.append(formatLine(btcturkethtry, x, btcturkbtctry, jsbtcprice, btcturktrxtry, jstrxprice) + "\n");
	}
}
