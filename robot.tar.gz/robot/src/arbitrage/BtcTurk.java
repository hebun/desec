package arbitrage;

import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import util.Util;



public class BtcTurk {
	private Map<String, String> map;
	private int id;
	private float dollar;

	public BtcTurk(float dollar) {
		this.dollar = 1;
		// TODO Auto-generated constructor stub
		setMap(new LinkedHashMap<>());
	}

	public static void main(String[] args) {
		BtcTurk btcturk = new BtcTurk(6.12f);
		btcturk.fetch();
		System.out.println(btcturk.map);
	//	btcturk.insert();
	}

	public void fetch() {

		try {

			String response = Util.getHttp("https://api.btcturk.com/api/v2/ticker", null);
			String http = response.substring(8,response.length()-40);
//System.out.println(http);
		
			BtcturkPair fromJson[] = new Gson().fromJson(http, BtcturkPair[].class);

			this.getMap().put("btca", fromJson[0].bid);
			this.getMap().put("btcs", fromJson[0].ask);

			this.getMap().put("etha", fromJson[2].bid);
			this.getMap().put("eths", fromJson[2].ask);

//			this.getMap().put("ltca", fromJson[3].bid);
//			this.getMap().put("ltcs", fromJson[3].ask);

			this.getMap().put("trxa", fromJson[33].bid);
			this.getMap().put("trxs", fromJson[33].ask);

//			this.getMap().put("btcua", fromJson[5].bid);
//			this.getMap().put("btcus", fromJson[5].ask);

			this.getMap().put("xrpa", fromJson[9].bid);
			this.getMap().put("xrps", fromJson[9].ask);

		} catch (IOException e) {
			System.out.println("warrning: fecth btcturk exce:" + e.getMessage());

		}
	}

	public Map<String, String> getMap() {
		return map;
	}

	public void setMap(Map<String, String> map) {
		this.map = map;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float get(String coin) {
		return Float.parseFloat(map.get(coin)) / dollar;
	}

}
