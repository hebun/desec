package arbitrage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;
import javax.json.JsonValue;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;

import com.google.gson.Gson;
import com.google.gson.stream.JsonToken;

import util.MyLogger;
import util.Util;

public class JsonParser {
	static MyLogger log = MyLogger.getInstance();
	public static double TRXUSDT = 0.036;

	public static void main(String[] args) {

//		WebRequest wr = new WebRequest();
//		StringBuffer fromNet = wr.getFromNet("https://poloniex.org/");
//		System.out.println(fromNet);

//		List<SymbolPrice> pp = getPoloniexPrices();
//		for (SymbolPrice symbolPrice : pp) {
//			System.out.println(symbolPrice);
//		}

//		List<SymbolPrice> jsp = getJustSwapPrices();
//		jsp.sort((arg0, arg1) -> Double.compare(arg0.getVolume(), arg1.getVolume()) * -1);
//		for (SymbolPrice symbolPrice : jsp) {
//			System.out.println(symbolPrice);
//		}
//	
//			uniswap();
//			
//
//		
//		for (int i = 0; i < 100; i++) {
//			List<SymbolPrice> justswap = getJustSwapPrices();
//
//			justswap.sort((a, b) -> Double.compare(a.getVolume(), b.getVolume()));
//			for (SymbolPrice sp : justswap) {
//				System.out.println(sp);
//			}
//			// poloJustswap(justswap);
//
//			Util.sleep(120);
//		}
		// DynaInsertDb.insertJustSwap(justswap);

		//

		// getCNSfromProbit();
		compareCNS();
	}

	private static void uniswap() {

		WebRequest r = new WebRequest();
		StringBuffer fromNet = r.getFromNet(
				"https://api.ethplorer.io/getTokenInfo/0x25e1474170c4c0aa64fa98123bdc8db49d7802fa?apiKey=freekey");

		// System.out.println(fromNet);
		JsonReader jsonReader = Json.createReader(new StringReader(fromNet.toString()));
		JsonObject mainobj = jsonReader.readObject();
		JsonValue object = mainobj.get("price");
		if (object.getValueType() != JsonValue.ValueType.FALSE) {
			surebetTone();
			surebetTone();
			System.out.println(object);
		}
	}

	public static void poloJustswap(List<SymbolPrice> justswap) {

		List<SymbolPrice> poloniex = getPoloniexPrices();
		int i = 0, j = 0;
		for (SymbolPrice sp : justswap) {
			i++;
			j = 0;
			if (sp.symbol.contains("CNS")) {

				compareminmax(sp.price * TRXUSDT);
			}
			if (sp.getVolume() < 1000000)
				continue;

			for (SymbolPrice spp : poloniex) {

				j++;
				// System.out.println(spp.symbol+":"+sp.symbol);
				if (spp.symbol.equals(sp.symbol)) {
					double oran = sp.price / spp.price;
					if (oran > 1.5 || oran < 0.5)
						continue;

					long sb = Math.round(Math.abs(oran - 1) * 100);
					if (sb > 2) {

						surebetTone();
					}
					System.out.println(sb + " " + oran + " " + sp + "     " + spp);

				}
			}
		}
	}

	private static List<SymbolPrice> getPoloniexPrices() {
		List<SymbolPrice> poloniex = new ArrayList<>();

		WebRequest r = new WebRequest();
		StringBuffer fromNet = r.getFromNet("https://api.poloniex.org/api/exchange/marketPair/list");

		// System.out.println(fromNet);
		JsonReader jsonReader = Json.createReader(new StringReader(fromNet.toString()));

		JsonObject readObject = jsonReader.readObject();
		// System.out.println(readObject);
		JsonObject jo = null;
		try {
			jo = readObject.getJsonObject("data");
			if (jo == null)
				return poloniex;
		} catch (Exception e) {
			return poloniex;
		}

		JsonArray rows = jo.getJsonArray("rows");

		for (int i = 0; i < rows.size(); i++) {

			JsonObject obj = rows.getJsonObject(i);

			double volume = obj.getJsonNumber("volume24h").doubleValue() / 1000000;
			// System.out.println(volume);

			String sym = obj.getJsonString("fShortName").toString().replace("\"", "");
			JsonNumber price = obj.getJsonNumber("price");
			if (sym.equals("TRX")) {
				TRXUSDT = price.doubleValue() / 1000000;
			}
			if (volume < 560000)
				continue;

			String pricestr = price.toString().replace("\"", "");
			double priced = price.doubleValue() / 1000000;
			// System.out.println(key + ":" + pricestr);

			SymbolPrice symbolPrice = new SymbolPrice(sym, priced);
			poloniex.add(symbolPrice);

		}
		return poloniex;
	}

	public static List<SymbolPrice> getJustSwapPrices() {
		List<SymbolPrice> justswap = new ArrayList<>();

		WebRequest r = new WebRequest();
		StringBuffer fromNet = r.getFromNet("https://api.justswap.io/v1/tradepairlist");

		// System.out.println(fromNet);
		JsonReader jsonReader = Json.createReader(new StringReader(fromNet.toString()));

		JsonObject jo = jsonReader.readObject();
		System.out.println(jo.getValueType());
		Set<String> keySet = jo.keySet();

		for (String key : keySet) {

			JsonObject obj = jo.getJsonObject(key);
			JsonString symbol = obj.getJsonString("base_symbol");
			// if(symbol.equals("BTC"))
			JsonString price = obj.getJsonString("price");
			if (!obj.getJsonString("quote_symbol").toString().contains("TRX"))
				continue;
			double priced = Util.getDoubleSafe(price.toString().replace("\"", ""));
			if (priced == 0)
				continue;
			String sym = symbol.toString().substring(1, symbol.toString().length() - 1);

			SymbolPrice symbolPrice = new SymbolPrice(sym, priced);

			JsonString vol = obj.getJsonString("quote_volume");

			double vold = Util.getDoubleSafe(vol.toString().replace("\"", "")) / 1000000;

			symbolPrice.setVolume(vold);
			if (vold < 1000)
				continue;
			String base_id = obj.getString("base_id");
			symbolPrice.setAddress(base_id);

			justswap.add(symbolPrice);
		}
		return justswap;
	}

	public static void compareCNS() {
		WebRequest r = new WebRequest();
		StringBuffer fromNet = r.getFromNet("https://api.justswap.io/v1/tradepairlist");

		// System.out.println(fromNet);
		JsonReader jsonReader = Json.createReader(new StringReader(fromNet.toString()));

		JsonObject jo = jsonReader.readObject();
		// System.out.println(jo.getValueType());
		Set<String> keySet = jo.keySet();

		for (String key : keySet) {

			JsonObject obj = jo.getJsonObject(key);
			JsonString symbol = obj.getJsonString("base_symbol");
			JsonString price = obj.getJsonString("price");

			double priced = Util.getDoubleSafe(price.toString().replace("\"", "")) * TRXUSDT;

			// String coin = symbol + " -> " + price;
			String sym = symbol.toString();
			// System.out.println(sym);
			if (sym.substring(1, sym.length() - 1).equals("CNS")) {
				// System.out.println(priced);
				compareminmax(priced);

			}
			// System.out.println(coin);
		}
	}

	public static void compareminmax(double priced) {
		OrderMinMax omm = getCNSfromProbit();

		double d = omm.minSell / priced;

		double e = priced / omm.getMaxBuy();
		System.out.println(priced + " -> " + e + ":" + d);

		if (d < 0.97 || e < 0.97) {
			surebetTone(); 
		}
	}

	public static void surebetTone() {
		Util.tone(1000, 100, 0.5);
		Util.tone(500, 100, 0.5);
		Util.tone(1000, 100, 0.5);
	}

	public static OrderMinMax getCNSfromProbit() {
		WebRequest r = new WebRequest();
		StringBuffer fromNet = r.getFromNet("https://api.probit.com/api/exchange/v1/order_book?market_id=CNS-USDT");

		// System.out.println(fromNet);

		String json = fromNet.toString(); // "{\"side\":\"sell\",\"price\":\"0.05\",\"quantity\":\"398791.358\"}";
		JsonData o = new Gson().fromJson(json, JsonData.class);
		MarketOrder[] data = o.getData();

		double minSell = 1000000000, maxBuy = 0;

		for (MarketOrder mo : data) {
			if (mo.getSide().equals("sell")) {
				if (mo.price < minSell)
					minSell = mo.price;
			} else if (mo.getSide().equals("buy")) {
				if (mo.price > maxBuy)
					maxBuy = mo.price;
			}
		}

		OrderMinMax ret = new OrderMinMax(minSell, maxBuy);
		System.out.println(ret);
		return ret;

	}
}
