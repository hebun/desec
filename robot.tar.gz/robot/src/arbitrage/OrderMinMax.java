package arbitrage;

public class OrderMinMax {
	double minSell, maxBuy;

	public OrderMinMax() {
		// TODO Auto-generated constructor stub
	}

	public OrderMinMax(double minSell, double maxBuy) {
	
		this.minSell = minSell;
		this.maxBuy = maxBuy;
	}

	@Override
	public String toString() {
		return "OrderMinMax [minSell=" + minSell + ", maxBuy=" + maxBuy + "]";
	}

	public double getMinSell() {
		return minSell;
	}

	public void setMinSell(double minSell) {
		this.minSell = minSell;
	}

	public double getMaxBuy() {
		return maxBuy;
	}

	public void setMaxBuy(double maxBuy) {
		this.maxBuy = maxBuy;
	}
}
