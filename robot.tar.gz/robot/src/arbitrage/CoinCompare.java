package arbitrage;

import java.util.Calendar;
import java.util.Date;

import util.Util;

public class CoinCompare {

	String symbol;
	double price1, price2;

	Date time;

	String site1, site2;
	String oran;

	public CoinCompare(double price1, double price2) {
		this.price1 = price1;
		this.price2 = price2;

		time = Calendar.getInstance().getTime();
		oran=Util.formatDouble(this.price1/this.price2,3);
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public double getPrice1() {
		return price1;
	}

	public void setPrice1(double price1) {
		this.price1 = price1;
	}

	public double getPrice2() {
		return price2;
	}

	public void setPrice2(double price2) {
		this.price2 = price2;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public String getSite1() {
		return site1;
	}

	public void setSite1(String site1) {
		this.site1 = site1;
	}

	public String getSite2() {
		return site2;
	}

	public void setSite2(String site2) {
		this.site2 = site2;
	}

	public String getOran() {
		return oran;
	}

}
