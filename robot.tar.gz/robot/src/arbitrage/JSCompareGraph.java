package arbitrage;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import charting.MyChart;
import util.ReadFile;
import util.Util;

public class JSCompareGraph {
	private String col;

	public JSCompareGraph(String col) {
		this.col = col;

	}

	public static void main(String[] args) {
		JSCompareGraph g = new JSCompareGraph("5.col");
		g.showGraph();
	}

	public void showGraph() {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();

		ReadFile readFile = new ReadFile("C:/folder/jsbtcturketh.txt", null, ":");
		List<Map<String, String>> table = readFile.getTable(null);
		List<Double> orans = new ArrayList<Double>();

		double max = -100000, min = 10000;
		int k = 0;
		for (Map<String, String> map : table) {
			if (k++ % 2 != 0)
				continue;
			String ethp = map.get(col).split("  ")[0].trim();
			Double oran = Util.getDoubleSafe(ethp) * 1000;
			int value = oran.intValue();
			// System.out.println(oran);
			Map<String, String> mapx = new HashMap<>();
			mapx.put("tarih", "axcvcvcvvasdfsdfsdff");
			mapx.put("text", "");

			if (Math.abs(value - 1000) < 10) {
			//	value = 1000;

			} else {
				
			}
			mapx.put("value", value + "");
				list.add(mapx);
			/**
			 * compare eth to btc on js
			 */

			String btcp = map.get("4.col").split("  ")[0].trim();
			double btc = Util.getDoubleSafe(btcp);

			String ethpt = map.get("3.col").split("  ")[0].trim();
			Double orant = Util.getDoubleSafe(ethpt);
			double x = btc / (orant);
			if (x > 1.02 || x < 0.98) {
				System.out.println(map.get("0.col") + map.get("1.col") + "=======================" + x);

			}

		}

		MyChart.showGraphOf(list);
	}
}
