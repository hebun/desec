package arbitrage;

import java.util.Arrays;

public class JsonData {
	MarketOrder[] data;
	public MarketOrder[] getData() {
		return data;
	}
	@Override
	public String toString() {
		return "JsonData [data=" + Arrays.toString(data) + "]";
	}
	public void setData(MarketOrder[] data) {
		this.data = data;
	}
	public JsonData() {
	
	}
}
