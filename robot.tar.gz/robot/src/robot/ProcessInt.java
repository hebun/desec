package robot;

import java.util.Date;
import java.util.Observer;

import javafx.scene.Node;

public interface ProcessInt {

	String getTitle();

	Node getRootNode();

	void start();

	void resume();

	void stop();

	default void sendMessage(ProcessInt source, Date time, String msg) {
	}

	default void setObserver(Observer ob) {

	}
}
