package robot;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;

public class TabContent extends BorderPane {
	private boolean procRunning = false;
	private ProcessInt proc;

	public TabContent(ProcessInt proc) {

		this.proc = proc;
		Button toggle = new Button("Resume");

		toggle.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {

				procRunning = !procRunning;

				toggle.setText(procRunning ? "Stop" : "Resume");

				if (procRunning) {
					proc.resume();
				} else {
					proc.stop();
				}

			}
		});

		HBox top = new HBox();
		top.getChildren().add(toggle);
		top.setPadding(new Insets(10));
		top.setAlignment(Pos.BASELINE_LEFT);
		top.setSpacing(10);
		
		this.setTop(top);
		this.setCenter(proc.getRootNode());
	}

	public Tab getTab() {
		Tab tab = new Tab(proc.getTitle());
		tab.setContent(this);
		return tab;
		
	}
}
