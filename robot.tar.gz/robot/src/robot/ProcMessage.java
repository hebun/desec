package robot;

import java.util.Date;

import util.Util;

public class ProcMessage {
	ProcessInt source;
	Date time;
	String msg;

	public ProcMessage() {

	}

	public ProcMessage(ProcessInt source, Date time, String msg) {
		super();
		this.source = source;
		this.time = time;
		this.msg = msg;
	}

	public String format() {

		String ret = "\n";

		if (source == null) {
			ret += "[NA]";
		} else {
			ret += "[" + source.getTitle() + "]";
		}
		ret += Util.getFormattedTime(time);

		ret += "\n";

		ret +="	"+ msg;

		return ret;
	}
}
