package robot;

import java.util.Calendar;

import fxcomps.BaseWindow;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;

public class Panel extends BaseWindow<BorderPane> {
	private TextArea msgs;

	public Panel() {
		rootNode = new BorderPane();
		msgs = new TextArea();
		rootNode.setRight(msgs);
		msgs.appendText("balblaba ahaha");
		
		ProcMessage pm = new ProcMessage(null, Calendar.getInstance().getTime(), "just testing blabal");
		
		msgs.appendText(pm.format());
		msgs.appendText(pm.format());
		
	}
	public void addMessage(ProcMessage pm) {
		msgs.appendText(pm.format());
	}
}
