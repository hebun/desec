package robot;

import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Times {

	private double rovi;

	Map<String, Double> times;

	public Times() {
		rovi = Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + Calendar.getInstance().get(Calendar.MINUTE) / 100;
		setTimes();
	}

	public Times(double lt) {
		rovi = lt;
		setTimes();
	}

	private void setTimes() {

		times = new LinkedHashMap<>();
		times.put("rovi", rovi );
		times.put("tosti", rovi + 1.5);
		times.put("firovi", rovi + 5.5);
		times.put("sev", rovi + 12);
		times.put("nivisti", rovi + 16);
	}

	public String getTimes() {

		String ret="";
		
		Set<Entry<String,Double>> entrySet = times.entrySet();
		
		for (Entry<String, Double> entry : entrySet) {
			ret+=entry.getKey()+":"+entry.getValue()+"\n";
		}
		
		return ret;
	}

	public static void main(String[] args) {

		Times t = new Times(9.5);
		System.out.println(t.getTimes());
		
	}
}
