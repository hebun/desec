package robot;

import java.util.Calendar;
import java.util.Observable;
import java.util.Observer;

import betmanager.Betview;
import fullbot.Bot;
import fullbot.BotView;

import fxcomps.BaseWindow;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import sayac.Sayac;
import work.AddWork;

public class MainView extends BaseWindow<BorderPane> {

	private TabPane tabs;
	private Panel panel;

	public MainView() {
		this.width = 1200;
		this.height = 800;

		rootNode = new BorderPane();

		tabs = new TabPane();

		rootNode.setCenter(tabs);

		// addProc(new Betview());

		// BookView fxbook = new BookView();
		// addProc(fxbook);
		// fxbook.start();

		// addProc(new Sayac());
		BotView betbot = new BotView();
		// addProc(betbot);

		Bot bot = new Bot(betbot);
		bot.start();

		FlowPane top = new FlowPane();
		top.getChildren().add(new Label("balba\nlbala"));
		Button addbut = new Button("add new");
		addbut.setOnAction(event -> {

		
			
		});

		rootNode.setTop(top);
		panel = new Panel();
		tabs.getTabs().add(new Tab("Panel", panel.getRootNode()));
	}

	private void addProc(ProcessInt bm) {
		TabContent tabContent = new TabContent(bm);
		tabs.getTabs().add(tabContent.getTab());
		
	}


}
