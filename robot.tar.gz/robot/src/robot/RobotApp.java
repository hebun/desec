package robot;


import javafx.stage.Stage;
import util.Pro;
import work.Controller;
import work.SqlBuilderImp;
import work.WorkModel;
import work.WorkView;

public class RobotApp extends javafx.application.Application {

	@Override
	public void start(Stage stage) throws Exception {
		Pro pro = new Pro("allfx");
		WorkView view = new WorkView();
		WorkModel model=new WorkModel(new SqlBuilderImp());
		Controller cont=new Controller(view,model);
		view.setCont(cont);
		cont.start();

		stage.setScene(view.getScene());
		stage.setTitle("The Robot");

		stage.show();
		stage.setOnCloseRequest(e -> {
			System.out.println("stage on close called");
			System.exit(0);
		});
		pro.print();
		
	}

	@Override
	public void init() throws Exception {

		super.init();

	}

	public static void main(String[] args) {

		launch(args);
	}
}
