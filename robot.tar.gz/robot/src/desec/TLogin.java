package desec;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TLogin {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@Test
	void test() {
		Login login = new Login();
		login.setView(new MockView());

		boolean auth = login.checkAuth("123");
		assert !auth;
		assert login.checkAuth("2882");

	}

}
