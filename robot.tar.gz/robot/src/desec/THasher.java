package desec;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class THasher {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@Test
	void test() {
		Hasher hasher = new Hasher();
		String hash = hasher.generateHash("1234");
		
		String rehash = hasher.generateHash("1234");
		String otherhash = hasher.generateHash("12345");

		assert hash.equals(rehash);
		assert !hash.equals(otherhash);
		
		
		
		

	}

}
