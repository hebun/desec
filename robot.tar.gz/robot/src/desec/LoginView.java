package desec;

public interface LoginView {

	void showInvalidLogin();

	void close();

}