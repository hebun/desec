package desec;

public class DesecFake implements DesecState {
	private DesecView v;
	private static final String TEXT = "Kredi Karti sifres: 1453";
	private DesecMain m;

	public DesecFake(DesecMain m) {
		this.m = m;
		this.v = m.getView();

	}

	@Override
	public void setView(DesecView v) {
		this.v = v;
	}

	@Override
	public void save() {
		if (v.getText().endsWith("8096")) {
			DesecOpen open = new DesecOpen(m);

			m.setState(open);
			return;
		}
		v.showSaved();
	}

	@Override
	public void load() {
		v.load(TEXT);
	}

}
