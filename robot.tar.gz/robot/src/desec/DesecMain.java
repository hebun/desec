package desec;

import util.Util;
/**
 * curent: 3th security change name of wallets
 * @author lazyCoding
 *
 */
public class DesecMain {
	private DesecState state;
	private DesecView v;

	public DesecMain() {
		

	}

	public static void main(String[] args) {

		launch();
	}

	public static void launch() {
		DesecMain dm = new DesecMain();
		
		DesecOpenView v = new DesecOpenView(dm);
		dm.setView(v);
		dm.setState(new DesecFake(dm));
		Util.launchOneTab(v, 1200);
		dm.load();
	}

	public void load() {
		this.state.load();
	}

	public void save() {
		this.state.save();
	}

	public void setView(DesecView v) {
		this.v = v;

	}

	public DesecView getView() {
		return this.v;
	}

	public DesecState getState() {
		return state;
	}

	public void setState(DesecState state) {
		this.state = state;
		state.setView(v);
		this.load();
	}
}
