package desec;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import encrypt.MyEncripter;
import util.ReadFile;

public class DesecOpen implements DesecState {

	private DesecView v;
	private DesecMain m;
	private Global g;

	public DesecOpen(DesecMain m) {
		this.m = m;
		g = Global.getInstance();
	}

	@Override
	public void setView(DesecView v) {
		this.v = v;
	}

	@Override
	public void save() {

		if (checkFakeState()) {
			return;
		}

		String text = v.getText();
		String enc = MyEncripter.encrypt(text, g.getPass());

		try {
			Files.write(Paths.get("data.ext"), enc.getBytes());

			v.showSaved();
		} catch (IOException e) {
			v.showSaveFailed();
			e.printStackTrace();
		}
	}

	public boolean checkFakeState() {

		if (v.getText().endsWith("8096")) {
			DesecState fake = new DesecFake(m);

			m.setState(fake);
			return true;
		}
		return false;
	}

	@Override
	public void load() {
		ReadFile readFile = new ReadFile("data.ext");
		StringBuilder sb = readFile.getStringBuilder();
		String str = sb.toString();
		String dec = MyEncripter.decrypt(str, g.getPass());
		if (dec == null) {
			v.showSaveFailed();

			this.m.setState(new DesecFake(m));
			
		} else {
			v.load(dec);
		}
	}
}
