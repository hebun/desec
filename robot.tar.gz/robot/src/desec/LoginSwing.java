package desec;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.util.List;
import java.util.Map;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import util.orm.Fetch;

public class LoginSwing extends JPanel implements LoginView {

	private final JLabel jlblUsername = new JLabel("username");
	private final JLabel jlblPassword = new JLabel("password");

	private final JTextField jtfUsername = new JTextField(15);
	private final JPasswordField jpfPassword = new JPasswordField();

	private final JButton jbtOk = new JButton("ok");
	private final JButton jbtCancel = new JButton("cancel");

	private final JLabel jlblStatus = new JLabel(" ");

	public boolean auth = false;
	private Login cont;

	public LoginSwing(Login cont) {

		this.cont = cont;
		this.setSize(new Dimension(300, 150));
		JPanel p3 = new JPanel(new GridLayout(2, 1));
		p3.add(jlblUsername);
		p3.add(jlblPassword);

		JPanel p4 = new JPanel(new GridLayout(2, 1));
		p4.add(jtfUsername);
		p4.add(jpfPassword);

		JPanel p1 = new JPanel();
		p1.add(p3);
		p1.add(p4);

		JPanel p2 = new JPanel();
		p2.add(jbtOk);
		p2.add(jbtCancel);

		JPanel p5 = new JPanel(new BorderLayout());
		p5.add(p2, BorderLayout.CENTER);
		p5.add(jlblStatus, BorderLayout.NORTH);
		jlblStatus.setForeground(Color.RED);
		jlblStatus.setHorizontalAlignment(SwingConstants.CENTER);

		setLayout(new BorderLayout());
		add(p1, BorderLayout.CENTER);
		add(p5, BorderLayout.SOUTH);
		LoginView this_ = this;
		Action enterAction = new AbstractAction() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (!jbtOk.isEnabled()) {
					jlblStatus.setText("please_try_again");
					return;
				}
				String passStr = String.copyValueOf(jpfPassword.getPassword());
				cont.passwordEntered(passStr);

			}
		};

		jbtOk.addActionListener(enterAction);
	
		jbtCancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				auth = false;
				System.exit(0);
			}
		});
		String actionName = "keyenter";
		this.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT)
				.put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), actionName);

		this.getActionMap().put(actionName, enterAction);

	}

	@Override
	public void showInvalidLogin() {
		jlblStatus.setText("invalidusernameorpassword");
	}

	@Override
	public void close() {

		JFrame parentFrame;
		Window win = SwingUtilities.windowForComponent(this);

		if (win != null) {

			if (win instanceof JDialog) {
				win.dispatchEvent(new WindowEvent(win, WindowEvent.WINDOW_CLOSING));
				win.dispose();
			} else if (win instanceof JFrame) {

				parentFrame = (JFrame) win;

				// parentFrame.dispatchEvent(new WindowEvent(parentFrame,
				// WindowEvent.WINDOW_CLOSING));
				parentFrame.dispose();
			}
		}
	}

}