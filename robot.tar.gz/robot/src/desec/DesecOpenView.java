package desec;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import util.AutoDismiss;
import util.Util;

public class DesecOpenView extends JPanel implements DesecView   {
	private DesecMain cont;
	private JTextArea area;
	private JScrollPane pane;

	public DesecOpenView(DesecMain dm) {
		this.cont = dm;
		this.setLayout(null);

		area = new JTextArea();
		pane = new JScrollPane(area);
		pane.setSize(1000, 800);

		this.add(pane);
		pane.setLocation(20, 50);
		
		JButton but
		= new JButton("save");
		
		but.setSize(80, 30);
		this.add(but);
		but.setLocation(1050, 50);
		but.addActionListener(e -> {
			
			dm.save();
		});
	}

	public static void main(String[] args) {

	}

	@Override
	public void load(String dec) {
		
		area.setText(dec);
	}

	@Override
	public String getText() {
		return area.getText();
		
	}

	@Override
	public void showSaved() {
		AutoDismiss.showMessageDialog(this, "Saved", "ok", 500);
	}

	@Override
	public void showSaveFailed() {
		JOptionPane.showMessageDialog(this, "Error!");
	}
}
