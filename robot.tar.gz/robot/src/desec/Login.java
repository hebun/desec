package desec;

import util.Util;

public class Login {
	private LoginView view;

	public Login() {

	}

	public boolean checkAuth(String pass) {

		Hasher hasher = new Hasher();
		String hash = hasher.generateHash(pass);
		if (hash.equals("38c8b0ee2229d4c1f9c69c49db7911f803d5691f")) {
			Global.getInstance().setPass(pass);
			
			return true;
		}
		return false;
	}

	public boolean passwordEntered(String pass) {

		boolean auth = checkAuth(pass);

		if (!auth) {
			view.showInvalidLogin();
			return false;
		}
		view.close();

		DesecMain.launch();

		return true;
	}

	public static void main(String[] args) {
		Login login = new Login();
		LoginSwing loginSwing = new LoginSwing(login);
		login.setView(loginSwing);
		loginSwing.setSize(350, 150);
		Util.launchOneTab(loginSwing, 350);

	}

	public LoginView getView() {
		return view;
	}

	public void setView(LoginView view) {
		this.view = view;
	}
}
