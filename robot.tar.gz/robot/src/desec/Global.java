package desec;

public class Global {
	private static Global g;
	private String pass;

	private Global() {

	}

	public static Global getInstance() {
		if (g == null) {
			g = new Global();

		}
		return g;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
}
