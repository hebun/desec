package desec;

public interface DesecState {

	void setView(DesecView v);

	void save();

	void load();

}