package desec;

public class MockView implements LoginView {

	@Override
	public void showInvalidLogin() {
	}

	@Override
	public void close() {
	}

}
