package desec;

public interface DesecView {

	void load(String dec);

	String getText();

	void showSaved();

	void showSaveFailed();

}