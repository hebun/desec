package betmanager;

import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;
import util.Util;

public class BetManager {

	private Betview view;
	private Model model;

	public BetManager(Betview view) {
		this.view = view;
		model = new Model();

	}

	public void loadKupons() {
		view.load(model);
	}

	public void startCheckUnsetteled() {

		Timeline fiveSecondsWonder = new Timeline(new KeyFrame(Duration.seconds(120), e -> {
			if (model.isRunning())
				checkUnsettled();
		}));
		fiveSecondsWonder.setCycleCount(Timeline.INDEFINITE);
		fiveSecondsWonder.play();
		checkUnsettled();
	}

	public Model getModel() {
		return model;
	}

	public void setModel(Model model) {
		this.model = model;
	}

	private void checkUnsettled() {
		System.out.println("bm running checking unsettled");
		TBet bet = model.getClosestBet();
		if (bet == null)
			return;
		long diff = bet.getTarih().getTime() - Calendar.getInstance().getTime().getTime();
		long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);

		if (minutes < 30) {
			List<TBet> betsByMacname = model.getBetsByMacname(bet.getMacname());
			for (TBet tbet : betsByMacname) {
				if (model.getKuponBalance(tbet.getKuponid()) == 0)
					continue;
				if (tbet.getSettled() == 0 && tbet.getResult() == 0) {
					System.out.println(tbet.toString());
					Util.tone(600, 100, 2);
					if (minutes < 10) {
						Util.tone(600, 100, 2);
					}

				}
			}
		}

	}
}
