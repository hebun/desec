package betmanager;

import java.sql.SQLClientInfoException;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import fxcomps.BaseWindow;
import fxcomps.Grid;
import javafx.collections.FXCollections;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.util.Callback;
import util.Row;
import util.Sql;

public class KuponView extends BaseWindow<GridPane> {
	private Grid<TBet> grid;
	private boolean isOK = false;
	private MenuItem mi3;
	private MenuItem mi4;
	private List<TBet> list;

	public MenuItem getMi3() {
		return mi3;
	}

	public void setMi3(MenuItem mi3) {
		this.mi3 = mi3;
	}

	public MenuItem getMi4() {
		return mi4;
	}

	public void setMi4(MenuItem mi4) {
		this.mi4 = mi4;
	}

	public KuponView() {
		this(false);

	}

	public TBet getSelected() {
		return getGrid().getSelectionModel().getSelectedItem();
	}

	public KuponView(boolean forList) {
		// width = 750;
		// height = 300;
		rootNode = new GridPane();
		rootNode.setHgap(10);
		rootNode.setVgap(10);
		rootNode.setPadding(new Insets(5, 5, 5, 5));
		Row dmcols = new Row();

		dmcols.put("tarih", "tarih");
		dmcols.put("macname", "macname");
		dmcols.put("ht", "oran");

		dmcols.put("amount", "amount");
		dmcols.put("text", "text");

		setGrid(new Grid<TBet>(dmcols));
		getGrid().setPrefWidth(480);
		ContextMenu cm = new ContextMenu();

		MenuItem mi0 = new MenuItem("not settled");
		mi0.setOnAction(e -> {
			TBet bet = getGrid().getSelectionModel().getSelectedItem();
			bet.setSettled(0);
			new Sql.Update("tbet").add("settled", "0").where("id", bet.getId()).run();
		});

		cm.getItems().add(mi0);
		MenuItem mi1 = new MenuItem("settled");
		mi1.setOnAction(e -> {
			TBet bet = getGrid().getSelectionModel().getSelectedItem();
			bet.setSettled(2);
			new Sql.Update("tbet").add("settled", "2").where("id", bet.getId()).run();
		});
		cm.getItems().add(mi1);
		MenuItem mi2 = new MenuItem("waiting");
		mi2.setOnAction(e -> {
			TBet bet = getGrid().getSelectionModel().getSelectedItem();
			bet.setSettled(1);
			new Sql.Update("tbet").add("settled", "1").where("id", bet.getId()).run();
		});

		cm.getItems().add(mi2);

		mi3 = new MenuItem("won");
		mi3.setOnAction(e -> {
			TBet bet = getGrid().getSelectionModel().getSelectedItem();
			bet.setResult(1);
			new Sql.Update("tbet").add("result", "1").where("id", bet.getId()).run();
		});
		cm.getItems().add(mi3);

		mi4 = new MenuItem("lost");
		mi4.setOnAction(e -> {
			TBet bet = getGrid().getSelectionModel().getSelectedItem();
			bet.setResult(2);
			new Sql.Update("tbet").add("result", "2").where("id", bet.getId()).run();
		});
		cm.getItems().add(mi4);

		MenuItem mi5 = new MenuItem("old");
		mi5.setOnAction(e -> {

			double kuponBalance = Model.getKuponBalance(list);

			TBet bet = getGrid().getSelectionModel().getSelectedItem();
			new Sql.Update("kupon").noQuote().add("old", "1").where("id", bet.getKuponid()).run();
			String accid = Sql.getById("kupon", bet.getKuponid() + "").get("accid");
			new Sql.Update("acc").noQuote().add("available", "available+" + kuponBalance).where("id", accid).run();

		});
		cm.getItems().add(mi5);

		getGrid().addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent t) {
				if (t.getButton() == MouseButton.SECONDARY) {
					cm.show(getGrid(), t.getScreenX(), t.getScreenY());
				}
			}
		});

		getGrid().setRowFactory(new Callback<TableView<TBet>, TableRow<TBet>>() {

			@Override
			public TableRow<TBet> call(TableView<TBet> param) {
				return new TableRow<TBet>() {
					@Override
					protected void updateItem(TBet item, boolean empty) {
						super.updateItem(item, empty);
						if (item == null) {
							setStyle("");
							return;
						} else if (item.getSettled() == 1) {
							setStyle("-fx-background-color: lightyellow;");
						} else if (item.getSettled() == 2) {
							setStyle("-fx-background-color: lightgreen;");

						}
						if (item.getResult() == 1) {

							setStyle("-fx-background-color: green;");
						} else if (item.getResult() == 2) {

							setStyle("-fx-background-color: red;");

						} else {

						}

					}
				};

			}

		});

		rootNode.add(getGrid(), 0, 0);
		if (!forList)

		{
			Button button = new Button("good");
			button.setOnAction(event -> {
				isOK = true;
				this.getStage().close();
			});

			rootNode.add(button, 0, 1);
		}
	}

	public List<TBet> getList() {
		return list;
	}

	public void setList(List<TBet> list) {
		this.list = list;
		getGrid().setData(FXCollections.observableArrayList(list));
		getGrid().setPrefHeight(list.size() * 30 + 20);
	}

	public boolean isOK() {
		return isOK;
	}

	public void setOK(boolean isOK) {
		this.isOK = isOK;
	}

	public Grid<TBet> getGrid() {
		return grid;
	}

	public void setGrid(Grid<TBet> grid) {
		this.grid = grid;
	}
}
