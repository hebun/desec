package betmanager;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.regex.PatternSyntaxException;

import com.sun.org.apache.xalan.internal.xsltc.compiler.Pattern;

import fxcomps.BaseWindow;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import util.Db;
import util.Sql;
import util.Util;

public class AddKupon extends BaseWindow<GridPane> {
	private TextArea kupon;
	private TextField field;
	String[] ays = { "Oca", "�ub", "Mar", "Nis", "May", "Haz", "Tem", "Agu", "Eyl", "Eki", "Kas", "Ara" };

	public AddKupon() {

		width = 800;
		height = 600;
		rootNode = new GridPane();
		rootNode.setHgap(10);
		rootNode.setVgap(10);
		rootNode.setPadding(new Insets(40, 40, 40, 40));
		Button add = new Button("add");
		add.setOnAction(event -> saveKupon());
		field = new TextField("");

		rootNode.add(field, 0, 0);
		rootNode.add(add, 1, 0);

		kupon = new TextArea();
		kupon.setText("");
		kupon.setPrefHeight(400);
		kupon.setPrefWidth(700);
		rootNode.add(kupon, 0, 1, 2, 2);

	}

	private void saveKupon() {
		String text = kupon.getText();

		String[] lines = text.split("\n");

		if (field.getText().length() < 1) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("enter acc");
			alert.showAndWait();
			return;
		}

		List<TBet> list = new ArrayList<>();
		for (String line : lines) {
			if (line.length() == 0 || !Character.isDigit(line.charAt(0))) {
				continue;
			}

			String[] tabs = line.split("\t");

			String tarih = tabs[1];

			String saatstr = tarih.substring(tarih.length() - 5, tarih.length());
			String aystr = tarih.substring(tarih.length() - 14, tarih.length() - 11);
			String[] split = saatstr.split(":");
			int saat = Integer.parseInt(split[0]);
			int dakka = Integer.parseInt(split[1]);
			LocalDateTime date = LocalDateTime.of(LocalDate.now().getYear(), getAy(aystr),
					Integer.parseInt(tarih.substring(0, 2)), saat, dakka, 0);

			TBet bet = new TBet();
			bet.setMacname(tabs[2]);
			Date datex = Date.from(date.atZone(ZoneId.systemDefault()).toInstant());
			bet.setTarih(datex);
			bet.setBuro("tempo");
			bet.setHt((int) ((Util.getDoubleSafe(tabs[6])) * 100));
			list.add(bet);
//				for (String tab : tabs) {
//					
//					//System.out.print(tab+" _ ");
//				}
//				System.out.println();

		}

		list.sort((o1, o2) -> o1.getTarih().compareTo(o2.getTarih()));

		int kombinemiktar = text.indexOf("KOMB�NEM�KTAR");
		int kuponAmount = 0;
		if (kombinemiktar < 0) {
			kombinemiktar = text.indexOf("KombineMiktar");
			if (kombinemiktar < 0) {
				kuponAmount = askKuponAmount();
			} else {
				String km = text.substring(kombinemiktar + 15, kombinemiktar + 19);
				System.out.println("km:" + km);
				kuponAmount = Integer.parseInt(km);
			}
		} else {

			String km = text.substring(kombinemiktar + 15, kombinemiktar + 19);
			System.out.println("km:" + km);
			double doubleSafe = Util.getDoubleSafe(km);
			kuponAmount = (int) doubleSafe;

		}
		if (kuponAmount == 0) {
			kuponAmount = askKuponAmount();
		}
		int amount = kuponAmount;
		double prevOran = 100;
		for (TBet bet : list) {
			amount = (int) (amount * prevOran / 100);
			bet.setAmount(amount);
			prevOran = bet.getHt();
		}

		KuponView kview = new KuponView();
		kview.getStage().initModality(Modality.APPLICATION_MODAL);
		kview.setList(list);
		kview.getStage().showAndWait();
		if (kview.isOK()) {

			Sql.Insert insert = new Sql.Insert("kupon");
			insert.add("accid", field.getText());
			insert.add("buro", "tempo");
			int run = insert.run();

			for (TBet bet : list) {

				Sql.Insert ins = new Sql.Insert("tbet");
				ins.add("macname", bet.getMacname().replaceAll("'", ""));
				ins.add("amount", bet.getAmount());
				ins.add("tarih", Util.getFormattedTime(bet.getTarih()));
				ins.add("kuponid", run + "");
				ins.add("ht", bet.getHt());

				Optional<TBet> findAny = list.stream().filter(e -> {
					if (e == bet)
						return false;
					long diff = Math.abs(e.getTarih().getTime() - bet.getTarih().getTime());
					long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);
					boolean cakisma = minutes < 115;
					return cakisma;
				}).findAny();

				if (findAny.isPresent()) {

					ins.add("text", "<===");

				}
				ins.run();
			}

			
		}

	}

	private int getAy(String aystr) {
		int index = 0;
		for (String ay : ays) {

			if (aystr.equals(ay)) {

				return index + 1;
			}
			index++;

		}
		return 0;
	}

	public static void main(String[] args) {
		new AddKupon();
	}

	private int askKuponAmount() {
		int kuponAmount;
		TextInputDialog tid = new TextInputDialog();
		tid.setHeaderText("kupon amount");
		tid.showAndWait();
		String txt = tid.getResult();

		kuponAmount = Integer.parseInt(txt);
		return kuponAmount;
	}
}
