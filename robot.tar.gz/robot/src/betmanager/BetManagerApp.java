package betmanager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.TimeLimitExceededException;

import com.sun.javafx.stage.StageHelper;
import com.sun.org.apache.xml.internal.security.keys.content.KeyValue;

import javafx.animation.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ObservableValueBase;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import util.Db;
import util.MyLogger;
import util.Pro;
import javafx.scene.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;

public class BetManagerApp extends Application {

	private Model model;

	@Override
	public void start(Stage stage) throws Exception {

		Db.DB_URL="jdbc:mysql://localhost:3306/betting?useUnicode=true&characterEncoding=utf8";
		Betview view = new Betview();
		stage.setScene(view.getScene());
		stage.setTitle("Bet Manager");
		stage.setMaximized(true);
		stage.show();
		BetManager cont = new BetManager(view);
		model = cont.getModel();
		cont.loadKupons();
		cont.startCheckUnsetteled();

	}


	@Override
	public void init() throws Exception {
		// Springc
		super.init();

	}

	public static void main(String[] args) {
		Pro.tick("onshown");
		launch(args);
	}
}
