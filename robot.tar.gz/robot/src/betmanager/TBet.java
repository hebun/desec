package betmanager;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import util.Util;


public class TBet {

	private int id;
	private int amount;
	String hometeam;
	private String macname;
	String awayteam;
	int ht;
	int at;
	int draw;
	Date tarih;
	String buro;

	Date createTime;
	Date updateTime;
	private int kuponid;
	private boolean isLive = false;
	private Map<String, String> map;
	int result;
	int settled;
	private List<Integer> relatedBets;
	private String text;

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	public int getSettled() {
		return settled;
	}

	public void setSettled(int settled) {
		this.settled = settled;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public TBet(Map<String, String> map) {
		this.map = map;
		id = Integer.parseInt(map.get("id"));
		hometeam = map.get("hometeam");
		awayteam = map.get("awayteam");
		ht = 0;
		try {
			ht = Integer.parseInt(map.get("ht"));
		} catch (NumberFormatException e) {
			System.out.println("ht parse");
		}
		// at = Integer.parseInt(map.get("at"));
		// draw = Integer.parseInt(map.get("draw"));

		tarih = Util.getTimeFromString(map.get("tarih"));
		buro = map.get("buro");
		createTime = Util.getTimeFromString(map.get("createTime"));
		updateTime = Util.getTimeFromString(map.get("updateTime"));
		setKuponid(Integer.parseInt(map.get("kuponid")));
		amount = Integer.parseInt(map.get("amount"));
		result = Integer.parseInt(map.get("result"));
		settled = Integer.parseInt(map.get("settled"));
		macname = map.get("macname");
		text= map.get("text");
		setRelatedBets(new ArrayList<Integer>());
	}

	public TBet() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "TBet [id=" + id + ", amount=" + amount + ", macname=" + macname + ", ht=" + ht + ", tarih=" + tarih
				+ ", buro=" + buro + ", kuponid=" + kuponid + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHometeam() {
		return hometeam;
	}

	public void setHometeam(String hometeam) {
		this.hometeam = hometeam;
	}

	public String getAwayteam() {
		return awayteam;
	}

	public void setAwayteam(String awayteam) {
		this.awayteam = awayteam;
	}

	public int getHt() {
		return ht;
	}

	public void setHt(int ht) {
		this.ht = ht;
	}

	public int getAt() {
		return at;
	}

	public void setAt(int at) {
		this.at = at;
	}

	public int getDraw() {
		return draw;
	}

	public void setDraw(int draw) {
		this.draw = draw;
	}

	public Date getTarih() {
		return tarih;
	}

	public void setTarih(Date tarih) {
		this.tarih = tarih;
	}

	public String getBuro() {
		return buro;
	}

	public void setBuro(String buro) {
		this.buro = buro;
	}

	public boolean isLive() {
		return isLive;
	}

	public void setLive(boolean isLive) {
		this.isLive = isLive;
	}

	public String getMacname() {
		return macname;
	}

	public void setMacname(String macname) {
		this.macname = macname;
	}

	public int getKuponid() {
		return kuponid;
	}

	public void setKuponid(int kuponid) {
		this.kuponid = kuponid;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public Map<String, String> getMap() {
		return map;
	}

	public void setMap(Map<String, String> map) {
		this.map = map;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<Integer> getRelatedBets() {
		return relatedBets;
	}

	public void setRelatedBets(List<Integer> relatedBets) {
		this.relatedBets = relatedBets;
	}

}
