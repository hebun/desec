package betmanager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.regex.PatternSyntaxException;

import com.sun.org.apache.xalan.internal.xsltc.compiler.Pattern;

import fxcomps.BaseWindow;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import util.Db;
import util.Sql;
import util.Util;

public class AddImajKupon extends BaseWindow<GridPane> {
	private TextArea kupon;
	private TextField field;
	String[] ays = { "Oca", "�ub", "Mar", "Nis", "May", "Haz", "Tem", "Agu", "Eyl", "Eki", "Kas", "Ara" };

	public AddImajKupon() {

		width = 800;
		height = 600;
		rootNode = new GridPane();
		rootNode.setHgap(10);
		rootNode.setVgap(10);
		rootNode.setPadding(new Insets(40, 40, 40, 40));
		Button add = new Button("add");
		add.setOnAction(event -> saveKupon());
		field = new TextField("");

		rootNode.add(field, 0, 0);
		rootNode.add(add, 1, 0);

		kupon = new TextArea();
		kupon.setText("");
		kupon.setPrefHeight(400);
		kupon.setPrefWidth(700);
		rootNode.add(kupon, 0, 1, 2, 2);

	}

	private void saveKupon() {
//		FC Barcelona - Granada CF
//		Soccer
//		LaLiga
//		19-01-2020 23:00	3 �htimalli	FC Barcelona	1.19
		if (field.getText().length() < 1) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("enter acc");
			alert.showAndWait();
			return;
		}
		String text = kupon.getText();

		String[] lines = text.split("\n");

		if (field.getText().length() < 1) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("enter acc");
			alert.showAndWait();
			return;
		}

		List<TBet> list = new ArrayList<>();

		TBet be = new TBet();
		be.setMacname(lines[0]);
		int askedamount = askKuponAmount();
		be.setAmount(askedamount);
		String tarih = lines[3].substring(0, 16);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy H:mm");

		Date dfs = null;
		try {
			dfs = dateFormat.parse(tarih);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		be.setTarih(dfs);

		String odd = lines[3].substring(lines[3].length() - 4);
		int oddi = (int) ((Util.getDoubleSafe(odd)) * 100);
		be.setHt(oddi);
		list.add(be);

		KuponView kview = new KuponView();
		kview.getStage().initModality(Modality.APPLICATION_MODAL);
		kview.setList(list);
		kview.getStage().showAndWait();
		if (kview.isOK()) {

			Sql.Insert insert = new Sql.Insert("kupon");
			insert.add("accid", field.getText());
			insert.add("buro", "imaj");
			int run = insert.run();

			for (TBet bet : list) {

				Sql.Insert ins = new Sql.Insert("tbet");
				ins.add("macname", bet.getMacname().replaceAll("'", ""));
				ins.add("amount", bet.getAmount());
				ins.add("tarih", Util.getFormattedTime(bet.getTarih()));
				ins.add("kuponid", run + "");
				ins.add("ht", bet.getHt());

				Optional<TBet> findAny = list.stream().filter(e -> {
					if (e == bet)
						return false;
					long diff = Math.abs(e.getTarih().getTime() - bet.getTarih().getTime());
					long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);
					boolean cakisma = minutes < 115;
					return cakisma;
				}).findAny();

				if (findAny.isPresent()) {

					ins.add("text", "<===");

				}
				 ins.run();
				System.out.println(ins.get());
			}

		}

	}

	private int getAy(String aystr) {
		int index = 0;
		for (String ay : ays) {

			if (aystr.equals(ay)) {

				return index + 1;
			}
			index++;

		}
		return 0;
	}

	public static void main(String[] args) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy H:mm");

		Date dfs = null;
		try {
			dfs = dateFormat.parse("20-01-2020 22:45");
		} catch (ParseException e1) {
			// 
			e1.printStackTrace();
		}
		System.out.println(dfs);
	}

	private int askKuponAmount() {
		int kuponAmount;
		TextInputDialog tid = new TextInputDialog();
		tid.setHeaderText("kupon amount");
		tid.showAndWait();
		String txt = tid.getResult();

		kuponAmount = Integer.parseInt(txt);
		return kuponAmount;
	}
}
