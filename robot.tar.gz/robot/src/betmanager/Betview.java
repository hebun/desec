package betmanager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import fxcomps.BaseWindow;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import robot.ProcessInt;
import util.Db;
import util.Sql;

public class Betview extends BaseWindow<BorderPane> implements ProcessInt {
	public static String borderStyle = "-fx-padding: 5;-fx-border-style: solid inside;-fx-border-width: 1;-fx-border-insets: 5;-fx-border-radius: 5;-fx-border-color: darkcyan;";
	private FlowPane catpane;
	private VBox option;
	private Model model;
	private List<KuponView> kuponviews;
	private BetManager cont;

	public Betview() {
		// TODO Auto-generated constructor stub
		this.width = 1800;
		this.height = 800;

		rootNode = new BorderPane();

		rootNode.setStyle(borderStyle);
		HBox top = new HBox();
		top.setPadding(new Insets(10));
		top.setAlignment(Pos.BASELINE_LEFT);
		top.setSpacing(10);

		Button addKupon = new Button("add kupon");

		addKupon.setOnAction(a -> {
			AddKupon addkupon = new AddKupon();
			addkupon.getStage().initModality(Modality.APPLICATION_MODAL);
			addkupon.getStage().showAndWait();

		});
		Button addImajKupon = new Button("add Imaj kupon");

		addImajKupon.setOnAction(a -> {
			AddImajKupon addkupon = new AddImajKupon();
			addkupon.getStage().initModality(Modality.APPLICATION_MODAL);
			addkupon.getStage().showAndWait();

		});
		Button now = new Button("Now");

		now.setOnAction(a -> {
			model.load();
			this.load(model);
		});

		catpane = new FlowPane();
		catpane.setOrientation(Orientation.VERTICAL);
		catpane.setHgap(10);
		catpane.setVgap(10);
		// catpane.setStyle(borderStyle);
		rootNode.setCenter(catpane);
		// grid.setonr

		top.getChildren().add(addKupon);
		top.getChildren().add(addImajKupon);
		top.getChildren().add(now);

		Button connect = new Button("connect");

		connect.setOnAction(a -> {

		});
		top.getChildren().add(connect);

		rootNode.setTop(top);

		option = new VBox(50);
		option.setStyle(borderStyle);
		rootNode.setLeft(option);
	}

	public void load(Model model) {
		this.model = model;
		catpane.getChildren().clear();
		kuponviews = new ArrayList<KuponView>();
		allBets(model);
		List<Map<String, String>> accs = model.getAccs();
		for (Map<String, String> acc : accs) {
			List<Map<String, String>> kupons = model.getKuponsByAcc(acc.get("id"));
			if (kupons.size() == 0)
				continue;
			TitledPane pane = new TitledPane();
			GridPane gp = new GridPane();

			gp.setHgap(1);
			gp.setVgap(5);
			gp.setBorder(new Border(
					new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));

			pane.setContent(gp);
			pane.setText(acc.get("name"));

			Label ballab = new Label();
			String avail = acc.get("available");
			String baltext = "avail:" + avail;

			gp.add(ballab, 0, 0);

			int k = 0;
			double exposure = 0;
			int col = 0;
			for (Map<String, String> kup : kupons) {
				Label lab = new Label(kup.get("id"));

				KuponView kv = new KuponView(true);

				List<TBet> betsByKuponId = model.getBetsByKuponId(Integer.parseInt(kup.get("id")));
				if (betsByKuponId.size() > 0) {
					kv.setList(betsByKuponId);
					if (kupons.size() > 4)
						gp.add(kv.getRootNode(), col++ % 2, (k++ / 2) + 1);
					else {
						gp.add(kv.getRootNode(), 0, k++ + 1);
					}
					kuponviews.add(kv);
				}
				double kupbal = model.getKuponBalance(betsByKuponId);
				exposure += kupbal;

			}
			baltext += " total:" + ((int) exposure + Integer.parseInt(avail));
			catpane.getChildren().add(pane);
			ballab.setText(baltext);

		}

	}

	public void allBets(Model model) {
		TitledPane panebets = new TitledPane();
		GridPane gridPane = new GridPane();

		gridPane.setHgap(1);
		gridPane.setVgap(5);
		gridPane.setBorder(new Border(
				new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));

		panebets.setContent(gridPane);
		panebets.setText("all bets");
		panebets.setPrefHeight(700);
		KuponView kv = new KuponView(true);
		kv.getGrid().getSelectionModel().selectedItemProperty().addListener(new ChangeListener<TBet>() {

			@Override
			public void changed(ObservableValue<? extends TBet> observable, TBet oldValue, TBet newValue) {
				List<Integer> relatedBets = newValue.getRelatedBets();
				for (KuponView kv : kuponviews) {
					kv.getGrid().getSelectionModel().clearSelection();
				}

				System.out.println(relatedBets);
				for (Integer id : relatedBets) {

					for (KuponView kv : kuponviews) {

						List<TBet> list = kv.getList();
						for (TBet bet : list) {
							if (bet.getId() == id) {
								kv.getGrid().getSelectionModel().select(bet);
							}
						}

					}
				}
			}
		});
		List<TBet> betsAgg = model.getBetsAgg();

		if (betsAgg.size() > 0) {
			kv.setList(betsAgg);

			gridPane.add(kv.getRootNode(), 0, 0);
		}
		kv.getMi3().setOnAction(e -> {
			List<TBet> macs = model.getBets().stream().filter(p -> p.getMacname().equals(kv.getSelected().getMacname()))
					.collect(Collectors.toList());
			for (TBet mac : macs) {
				System.out.println(mac);
				new Sql.Update("tbet").add("result", "1").where("id", mac.getId()).run();
			}
			// .forEach(c -> {
//
//						new Sql.Update("tbet").add("result", "1").where("id", c.getId()).run();
//
//					});

		});
		kv.getMi4().setOnAction(e -> {
			model.getBets().stream().filter(p -> p.getMacname().equals(kv.getSelected().getMacname())).forEach(c -> {

				new Sql.Update("tbet").add("result", "2").where("id", c.getId()).run();

			});
			;
		});

		catpane.getChildren().add(panebets);
	}

	@Override
	public String getTitle() {
		return "Bet Manager";
	}

	@Override
	public void start() {
		cont = new BetManager(this);
		model = cont.getModel();
		cont.loadKupons();
		cont.startCheckUnsetteled();
	}

	@Override
	public void resume() {
		if (cont == null) {
			start();
		}

		model.setRunning(true);
	}

	@Override
	public void stop() {
		model.setRunning(false);
	}

}
