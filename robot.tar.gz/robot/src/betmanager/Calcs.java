package betmanager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import util.Db;
import util.orm.Fetch;

public class Calcs {
	public static void main(String[] args) {
		Model model = new Model();
		String sql = "select * from tbet as t join kupon as k on k.id=t.kuponid where k.accid=10";
		List<Map<String, String>> tbets = Db.selectTable(sql);
		ArrayList<TBet> bets = new ArrayList<TBet>();
		for (Map<String, String> map : tbets) {
			TBet bet = new TBet(map);

			bets.add(bet);
		}
		model.setBets(bets);

		List<Map<String, String>> kupons = new Fetch().from("kupon").where("accid", "10").getTable();
		int totplayed = 0;

		for (Map<String, String> kup : kupons) {
			// System.out.println(kup.get("id"));
			List<TBet> betskup = model.getBetsByKuponId(Integer.parseInt(kup.get("id")));
			int kupoamount = 0;
			for (TBet bet : betskup) {

				totplayed += bet.getAmount();
				kupoamount += bet.getAmount();
				if (bet.getResult() == 2) {
					System.out.print(" break ");
					break;
				}
			}
			System.out.println(kup.get("accid")+":"+kupoamount);
		}

	}
}
