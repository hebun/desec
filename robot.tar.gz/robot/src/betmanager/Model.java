package betmanager;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import util.Db;
import util.orm.Fetch;

public class Model {
	private List<Map<String, String>> accs;

	private List<Map<String, String>> kupons;
	private List<TBet> bets;

	private List<TBet> agg;
	private boolean running = false;

	public Model() {
		load();

	}

	public void load() {
		accs = new Fetch().from("acc").getTable();
		kupons = new Fetch().from("kupon").where("old", "0").getTable();
		bets = new ArrayList<TBet>();
		if (kupons.size() == 0)
			return;
		String kids = "";
		for (Map<String, String> map : kupons) {
			kids += map.get("id") + ",";
		}
		kids = kids.substring(0, kids.length() - 1);

		String sql = "select * from tbet where kuponid in(" + kids + ")";
		List<Map<String, String>> tbets = Db.selectTable(sql);

		for (Map<String, String> map : tbets) {
			TBet bet = new TBet(map);

			bets.add(bet);
		}
	}

	public List<Map<String, String>> getAccs() {
		return accs;
	}

	public void setAccs(List<Map<String, String>> accs) {
		this.accs = accs;
	}

	public List<Map<String, String>> getKupons() {
		return kupons;
	}

	public void setKupons(List<Map<String, String>> kupons) {
		this.kupons = kupons;
	}

	public List<TBet> getBets() {
		return bets;
	}

	public void setBets(List<TBet> bets) {
		this.bets = bets;
	}

	public List<Map<String, String>> getKuponsByAcc(String accid) {

		return kupons.stream().filter(m -> m.get("accid").equals(accid)).collect(Collectors.toList());

	}

	public List<TBet> getBetsByKuponId(int kuponid) {
		List<TBet> list = bets.stream().filter(b -> b.getKuponid() == kuponid).collect(Collectors.toList());
		if (list.size() > 0) {
			TBet lastbet = list.get(list.size() - 1);
			int tot = lastbet.getAmount() * lastbet.getHt() / 100;
			lastbet.setText(tot + "");
		}
		return list;

	}

	public List<TBet> getBetsAgg() {

		agg = new ArrayList<TBet>();

		for (TBet bet : bets) {

			Optional<TBet> findAny = agg.stream().filter(e -> e.getMacname().equals(bet.getMacname())).findAny();
			List<TBet> betsByKuponId = getBetsByKuponId(bet.getKuponid());
			if (findAny.isPresent()) {
				TBet tBet = findAny.get();

				boolean isLost = betsByKuponId.stream().filter(e -> e.getResult() == 2).findAny().isPresent();
				if (!isLost) {
					tBet.setAmount(tBet.getAmount() + bet.getAmount());
					tBet.getRelatedBets().add(bet.getId());
				}
			} else {

				boolean isLost = betsByKuponId.stream().filter(e -> e.getResult() == 2).findAny().isPresent();

				if (!isLost) {
					TBet newbet = new TBet(bet.getMap());
					newbet.setResult(0);
					newbet.setSettled(0);
					newbet.setId(0);
					newbet.setText("");
					newbet.setId(bet.getId());
					agg.add(newbet);
					newbet.getRelatedBets().add(newbet.getId());
				}

			}

		}
		agg.sort((o1, o2) -> o1.getTarih().compareTo(o2.getTarih()));
		TBet closestBet = getClosestBet();
		if (closestBet != null) {
			closestBet.setText("<------");
		}
		return agg;
	}

	public TBet getClosestBet() {
		for (TBet bet : agg) {
			// System.out.print(Util.getFormattedTime(bet.getTarih()) + "---");
			Date now = Calendar.getInstance().getTime();

			if (bet.getTarih().after(now)) {
				return bet;

			}
		}
		return null;
	}

	public List<TBet> getBetsByMacname(String macname) {
		List<TBet> macs = bets.stream().filter(p -> p.getMacname().equals(macname)).collect(Collectors.toList());
		return macs;
	}

	public Map<String, String> getKuponById(int kuponid) {
		for (Map<String, String> map : kupons) {
			if (map.get("id").equals(kuponid + ""))
				return map;
		}
		return null;

	}

	public List<TBet> getAgg() {
		if (agg == null)
			agg = getBetsAgg();
		return agg;
	}

	public void setAgg(List<TBet> agg) {
		this.agg = agg;
	}

	public double getKuponBalance(int kuponid) {
		return getKuponBalance(this.getBetsByKuponId(kuponid));
	}

	public static double getKuponBalance(List<TBet> betsByKuponId) {
		double res = 0;
		for (TBet bet : betsByKuponId) {

			if (bet.getResult() == 2)
				return 0;

			if (bet.getResult() == 0) {
				res = bet.getAmount();
				return res;
			}
		}
		if(betsByKuponId.size()==0)return res;
		TBet last = betsByKuponId.get(betsByKuponId.size() - 1);
		res = last.getAmount() * last.getHt() / 100;
		return res;
	}

	public boolean isRunning() {
		return running;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}
}
