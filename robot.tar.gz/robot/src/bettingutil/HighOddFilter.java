package bettingutil;

public class HighOddFilter implements MacFilter {

	private int maxOran;
public HighOddFilter(int maxOran) {
	this.maxOran = maxOran;
	// TODO Auto-generated constructor stub
}
	@Override
	public boolean apply(DualMac mac) {
		
		
		
		int profitedOdd = mac.getProfitedOdd();
		
		//maxOran = 2500;
		return profitedOdd<maxOran;

	}

}
