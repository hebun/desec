package bettingutil;

import java.util.Date;

public class DualMac {

	private static final double EURO = 8.82;
	private Mac bf;
	private Mac buro;
	String proOdd;
	String odds;
	double ratio;
	String name;
	private String buroname;
	private Date tarih;
	private double profit;
	private double maxlimit = 0;
	private double limitprofit = 0;
	private int profitedOdd;
	private int profitedOddBf;
	private Date buroTarih;

	private String allOdds;
	private String ligname;
	private String score;
	private boolean underdogGol = false;

	public double getMaxlimit() {
		return maxlimit;
	}

	public void setMaxlimit(double maxlimit) {
		this.maxlimit = maxlimit;
	}

	public double getLimitprofit() {
		return limitprofit;
	}

	public void setLimitprofit(double limitprofit) {
		this.limitprofit = limitprofit;
	}

	public DualMac(Mac buro, Mac bf) {

		profitedOdd = 0;
		this.buro = buro;
		this.bf = bf;

		name = bf.hometeam + " V " + bf.awayteam;

		double max = -10000;

		double htoran = (double) buro.ht / bf.ht;

		proOdd = "ht";
		odds = buro.ht + "/" + bf.ht;
		ratio = htoran;
		max = htoran;
		profit = getProfit(buro.ht, bf.ht);
		profitedOdd = buro.ht;
		profitedOddBf = bf.ht;
		double atoran = (double) buro.at / bf.at;

		if (atoran > max) {
			proOdd = "at";
			odds = buro.at + "/" + bf.at;
			ratio = atoran;
			max = atoran;
			profit = getProfit(buro.at, bf.at);
			profitedOdd = buro.at;
			profitedOddBf = bf.at;
		}

		double draworan = (double) buro.draw / bf.draw;

		if (draworan > max) {
			proOdd = "draw";
			odds = buro.draw + "/" + bf.draw;
			ratio = draworan;
			max = draworan;
			profit = getProfit(buro.draw, bf.draw);
			profitedOdd = buro.draw;
			profitedOddBf = bf.draw;
		}

		buroname = buro.getBuro();
		tarih = bf.getTarih();
		buroTarih = buro.getTarih();
		if (buroname.contains("tempo")) {
			double orgodd = (double) (profitedOdd - 100) / 100;
			maxlimit = (double) (EURO * 25) / orgodd;
			maxlimit = Math.round(maxlimit);
			limitprofit = (maxlimit / 1000) * profit;
			limitprofit = Math.round(limitprofit);
		}

		allOdds = buro.ht + "/" + bf.ht + "   " + buro.draw + "/" + bf.draw + "     " + buro.at + "/" + bf.at;

	}

	public double getProfit(double odd, double deodd) {
		odd = odd / 100;
		deodd = deodd / 100;
		double cOMISSION2 = 0.03;
		double C7 = (1000 * odd * (deodd - 1)) / (deodd - cOMISSION2);

		double C8 = C7 / EURO;

		double lay = C8 / (deodd - 1);

		double netProfit = odd * 1000 - 1000 - C7;

		return Math.round(netProfit);
	}

	public Mac getBf() {
		return bf;
	}

	public void setBf(Mac bf) {
		this.bf = bf;
	}

	public Mac getBuro() {
		return buro;
	}

	public void setBuro(Mac buro) {
		this.buro = buro;
	}

	public String getProOdd() {
		return proOdd;
	}

	public void setProOdd(String proOdd) {
		this.proOdd = proOdd;
	}

	public String getOdds() {
		return odds;
	}

	public void setOdds(String odds) {
		this.odds = odds;
	}

	@Override
	public String toString() {
		return "DualMac [proOdd=" + proOdd + ", odds=" + odds + ", ratio=" + ratio + ", name=" + name + ", buroname="
				+ buroname + ", tarih=" + tarih + ", profit=" + profit + ", maxLimit=" + maxlimit + ", limitProfit="
				+ limitprofit + "]";
	}

	public double getRatio() {
		return ratio;
	}

	public void setRatio(double ratio) {
		this.ratio = ratio;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBuroname() {
		return buroname;
	}

	public void setBuroname(String buroname) {
		this.buroname = buroname;
	}

	public Date getTarih() {
		return tarih;
	}

	public void setTarih(Date tarih) {
		this.tarih = tarih;
	}

	public double getProfit() {
		return profit;
	}

	public void setProfit(double profit) {
		this.profit = profit;
	}

	public int getProfitedOdd() {
		return profitedOdd;
	}

	public void setProfitedOdd(int profitedOdd) {
		this.profitedOdd = profitedOdd;
	}

	public Date getBuroTarih() {
		return buroTarih;
	}

	public void setBuroTarih(Date buroTarih) {
		this.buroTarih = buroTarih;
	}

	public String getAllOdds() {
		return allOdds;
	}

	public void setAllOdds(String allOdds) {
		this.allOdds = allOdds;
	}

	public String getLigname() {
		return buro.getLig();
	}

	public void setLigname(String ligname) {
		this.ligname = ligname;
	}

	public String getScore() {
		String underdog = buro.isUnderdogGol() ? " * " : "";
		return buro.getHomeScore() + ":" + buro.getAwayScore() + underdog;
	}

	public void setUnderdogGol(boolean underdogGol) {
		this.underdogGol = underdogGol;
	}

	public int getProfitedOddBf() {
		return profitedOddBf;
	}

	public void setProfitedOddBf(int profitedOddBf) {
		this.profitedOddBf = profitedOddBf;
	}
}
