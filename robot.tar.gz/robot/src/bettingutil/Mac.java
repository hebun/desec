package bettingutil;

import java.util.Date;
import java.util.Map;

import util.Util;

public class Mac {

	private int homeScore = 0;
	private int awayScore = 0;
	private String lig;
	private int id;
	String hometeam;
	String awayteam;
	int ht;
	int at;
	int draw;
	Date tarih;
	String buro;
	private int depth;
	Date createTime;
	Date updateTime;
	private boolean underdogGol = false;
	private int min=0;
	private boolean isLive = false;

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Mac(Map<String, String> map) {
		id = Integer.parseInt(map.get("id"));
		hometeam = map.get("hometeam");
		awayteam = map.get("awayteam");
		ht = Integer.parseInt(map.get("ht"));
		at = Integer.parseInt(map.get("at"));
		draw = Integer.parseInt(map.get("draw"));

		tarih = Util.getTimeFromString(map.get("tarih"));
		buro = map.get("buro");
		createTime = Util.getTimeFromString(map.get("createTime"));
		updateTime = Util.getTimeFromString(map.get("updateTime"));
		depth = Util.getIntSafe(map.get("depth"));

	}

	public Mac() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Mac [id=" + id + ", hometeam=" + hometeam + ", awayteam=" + awayteam + ", ht=" + ht + ", at=" + at
				+ ", draw=" + draw + ", tarih=" + tarih + ", buro=" + buro + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHometeam() {
		return hometeam;
	}

	public void setHometeam(String hometeam) {
		this.hometeam = hometeam;
	}

	public String getAwayteam() {
		return awayteam;
	}

	public void setAwayteam(String awayteam) {
		this.awayteam = awayteam;
	}

	public int getHt() {
		return ht;
	}

	public void setHt(int ht) {
		this.ht = ht;
	}

	public int getAt() {
		return at;
	}

	public void setAt(int at) {
		this.at = at;
	}

	public int getDraw() {
		return draw;
	}

	public void setDraw(int draw) {
		this.draw = draw;
	}

	public Date getTarih() {
		return tarih;
	}

	public void setTarih(Date tarih) {
		this.tarih = tarih;
	}

	public String getBuro() {
		return buro;
	}

	public void setBuro(String buro) {
		this.buro = buro;
	}

	public boolean isLive() {
		return isLive;
	}

	public void setLive(boolean isLive) {
		this.isLive = isLive;
	}

	public int getDepth() {
		return depth;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}

	public String getLig() {
		return lig;
	}

	public void setLig(String lig) {
		this.lig = lig;
	}

	public int getHomeScore() {
		return homeScore;
	}

	public void setHomeScore(int homeScore) {
		this.homeScore = homeScore;
	}

	public int getAwayScore() {
		return awayScore;
	}

	public void setAwayScore(int awayScore) {
		this.awayScore = awayScore;
	}

	public boolean isUnderdogGol() {
		return underdogGol;
	}

	public void setUnderdogGol(boolean underdogGol) {
		this.underdogGol = underdogGol;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

}
