package bettingutil;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LigFilter implements MacFilter {

	static List<String> ligs = new ArrayList<>();

	static Map<String, String> dualList = new HashMap<String, String>();
	static {
		String fileName = "excludedligs";

		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {

			String line = br.readLine();

			while (line != null && !line.equals(" ") && !line.equals("")) {

				ligs.add(line);
				line = br.readLine();
			}

		} catch (IOException e) {

			e.printStackTrace();

		}

	}

	@Override
	public boolean apply(DualMac mac) {

		return !getLigs().stream().anyMatch(l -> l.equals(mac.getLigname()));

	}

	public List<String> getLigs() {
		return ligs;
	}

	public void addLig(String lig) {
		ligs.add(lig);
		try {
			Files.write(Paths.get("excludedligs"), (lig + "\n").getBytes(), StandardOpenOption.CREATE,
					StandardOpenOption.APPEND);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}