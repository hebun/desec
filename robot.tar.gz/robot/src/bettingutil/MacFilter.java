package bettingutil;

public interface MacFilter {
	
	boolean apply(DualMac mac);

}
