package bettingutil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import betting.Surebet;
import livebetting.SaveSurebet;
import livebetting.Underdog;
import util.LevenshteinDistance;
import util.Util;

public class DualMacs {
	private List<MacFilter> filters;
	private MacFilter ligFilter;
	private Underdog ud;
	private SaveSurebet saveSurebet;

	public DualMacs(int maxOran, MacFilter ligFilter) {

		this.ligFilter = ligFilter;
		filters = new ArrayList<MacFilter>();
		filters.add(new HighOddFilter(maxOran));
		filters.add(mac -> mac.getProfit() < 150);

		filters.add(ligFilter);
		ud = new Underdog();
		saveSurebet = new SaveSurebet();
	}

	public void warn(List<DualMac> dualmacs) {

		Surebet surebet = new Surebet(dualmacs);

		saveSurebet.updateSbAmount(dualmacs);
		surebet.findSurebets();

		String surebets = surebet.getSurebets();

		List<DualMac> sbmacs = surebet.getSurebetsSt();

		saveSurebet.saveSurebet(sbmacs);

		// System.out.println(surebets);

		if (surebets.length() > 0)
			Util.tone();

	}

	public List<DualMac> findDualMacs(List<Mac> bf, List<Mac> buro) {
		List<DualMac> dualmacs = new ArrayList<DualMac>();
		for (Mac buromac : buro) {
			for (Mac bfmac : bf) {

				try {

					if (bfmac.awayteam.contains("Uraw")) {
						System.out.println();
					}

					double similarityAway = LevenshteinDistance.similarity(bfmac.getAwayteam().replaceAll("Live!", ""),
							buromac.getAwayteam());

					double similarityHome = LevenshteinDistance.similarity(bfmac.getHometeam(), buromac.getHometeam());
					if (similarityAway > 0.5 && similarityHome > 0.5) {
						if (buromac.getBuro().equals("tempo")) {
							tempoTime(buromac, bfmac);
						}
						DualMac dm = new DualMac(buromac, bfmac);

						if (!applyFilters(dm))
							continue;

						/**
						 * only add low odds
						 */
						// if (dm.getOdds().startsWith("1") || dm.getOdds().startsWith("2") ||
						// dm.getOdds().startsWith("3"))
						dualmacs.add(dm);
					}
				} catch (Exception e) {
					e.printStackTrace();
					// System.err.println(buromac);
				}

			}
		}
		dualmacs.sort((o1, o2) -> Double.compare(o2.getRatio(), o1.getRatio()));

		return dualmacs;
	}

	private boolean applyFilters(DualMac dm) {

		for (MacFilter f : filters) {
			if (!f.apply(dm))
				return false;
		}

		return true;
	}

	private void tempoTime(Mac buromac, Mac bfmac) {
		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(buromac.getTarih());
			int hours = calendar.get(Calendar.HOUR_OF_DAY);
			int minutes = calendar.get(Calendar.MINUTE);

			Calendar calendarbf = Calendar.getInstance();
			calendarbf.setTime(bfmac.getTarih());
			int hoursbf = calendarbf.get(Calendar.HOUR_OF_DAY);
			int minutesbf = calendarbf.get(Calendar.MINUTE);

			if (minutes != minutesbf || Math.abs(hoursbf - hours) > 1) {
				// System.out.println("wrong times");
				// System.out.println(buromac);
				// System.out.println(bfmac);
				// continue;
			}
		} catch (Exception e) {
			System.out.println(bfmac.getHometeam() + ":" + e.getMessage());
		}
	}

}
