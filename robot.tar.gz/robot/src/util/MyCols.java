package util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyCols {
	public static void main(String[] args) {

//		lists();
		long nanoTime = System.nanoTime();
		Map<String, String> map = new MyMap<>();

		for (int i = 0; i < 1000_000; i++) {
			map.put(i + "", i + ".va");
		}

		for (int i = 0; i < 1000_000; i++) {
			map.get(i + "");
		}
		System.out.println((System.nanoTime() - nanoTime) / 1000_000);

	}

	private static void lists() {

		MyList<Integer> list = new MyList<>();

		for (int i = 0; i < 100_000; i++) {
			list.add(2 * i);
		}

		long top = 0;
		for (int i = 0; i < 100_000; i++) {
			top += list.get(i);
		}

	}
}
