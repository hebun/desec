package util;

import java.util.List;
import java.util.Map;

public interface Callback {
	public void run(List<Map<String, String>> datatable);
}
