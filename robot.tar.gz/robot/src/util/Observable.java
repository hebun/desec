package util;

public interface Observable {
	default void addObserver(Observer obs) {
	}

	default void notifyObservers() {
	}

}
