package util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class LevenshteinDistance {
	static Map<String, String> dualList = new HashMap<String, String>();
	static {
		String fileName = "alias.ini";

		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {

			String line = br.readLine();

			while (line != null) {
				String[] split = line.split("=");

				dualList.put(split[0], split[1]);
				line = br.readLine();
			}

		} catch (IOException e) {

			e.printStackTrace();

		}

	}

	public static String getAlly(String str) {

		Set<Entry<String, String>> duals = dualList.entrySet();
		for (Entry<String, String> entry : duals) {
			if (entry.getKey().equals(str.trim())) {
				return entry.getValue();
			}
		}

		return str;

	}

	public static double similarity(String s1, String s2) {

		s1 = s1.replace('\u00A0', ' ');
		s2 = s2.replace('\u00A0', ' ');
		// System.out.println(s1);
		s1=s1.trim();
		s2 = s2.trim();
		s1 = getAlly(s1);
		s2 = getAlly(s2);
		if (s1.endsWith("spor")) {
			s1 = s1.substring(0, s1.length() - 4);
		}
		if (s2.endsWith("spor")) {
			s2 = s2.substring(0, s2.length() - 4);
		}

		s1 = s1.replaceAll("Hapoel", "");
		s2 = s2.replaceAll("Hapoel", "");

		if (s1.length() < s2.length()) { // s1 should always be bigger
			String swap = s1;
			s1 = s2;
			s2 = swap;
		}
		int bigLen = s1.length();
		if (bigLen == 0) {
			return 1.0; /* both strings are zero length */
		}
		int i = bigLen - computeEditDistance(s1, s2);

		double d = i / (double) bigLen;

		if (s1 != getAlly(s1)) {

			s1 = getAlly(s1);
			double allyd = similarity(s1, s2);
			if (allyd > d)
				return allyd;
		}

		return d;
	}

	public static int computeEditDistance(String s1, String s2) {
		s1 = s1.toLowerCase();
		s2 = s2.toLowerCase();

		int[] costs = new int[s2.length() + 1];
		for (int i = 0; i <= s1.length(); i++) {
			int lastValue = i;
			for (int j = 0; j <= s2.length(); j++) {
				if (i == 0)
					costs[j] = j;
				else {
					if (j > 0) {
						int newValue = costs[j - 1];
						if (s1.charAt(i - 1) != s2.charAt(j - 1))
							newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
						costs[j - 1] = lastValue;
						lastValue = newValue;
					}
				}
			}
			if (i > 0)
				costs[s2.length()] = lastValue;
		}
		return costs[s2.length()];
	}

	public static void printDistance(String s1, String s2) {
		System.out.println(s1 + "-->" + s2 + ": " + computeEditDistance(s1, s2) + " (" + similarity(s1, s2) + ")");
	}

}
