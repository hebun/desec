package util.hiber;

import java.util.List;
import java.util.Observable;
import java.util.function.Consumer;

import org.hibernate.Session;

import javafx.collections.ObservableList;

public interface Hiber {
	public boolean execute(Consumer<Session> con);

	public <T> List<T> getAll(Class<T> cl);

	public <T> ObservableList<T> getAllObservable(Class<T> cl);

	public <T> List<T> query(String hql, Class<T> cl);

	public <T> void delete(T u);
	
	public <T> int save(T u);

}
