package util.hiber;

import java.util.Optional;
import java.util.logging.Level;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import util.MyLogger;
import util.Pro;

public class HiberFactory {
	private static Session hiber = null;
	protected static Hiber hib = null;
	private static SessionFactory factory;
	static MyLogger log = MyLogger.getInstance();

	private HiberFactory() {

	}

	public static void loadHiber() {
		if (hiber == null || hiber.isOpen() == false) {
			Pro.tick();
			java.util.logging.Logger.getLogger("org.hibernate").setLevel(Level.WARNING);

	log.info("getting hib");
			if (factory == null) {
				StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml")
						.build();
				Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();

				factory = meta.getSessionFactoryBuilder().build();
			}
			hiber = factory.openSession();
			hiber.setHibernateFlushMode(FlushMode.AUTO);

			hib = new HiberImpl(hiber);
			Pro.tick("loadhiber");
		}
	}

	public static void loadHiberTest() {
		java.util.logging.Logger.getLogger("org.hibernate").setLevel(Level.WARNING);
		if (hiber == null || hiber.isOpen() == false) {

			log.info("getting hiber test");
			if (factory == null) {
				log.info("getting factory test");
				StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibfortest.cfg.xml")
						.build();
				Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();

				factory = meta.getSessionFactoryBuilder().build();
			}
			hiber = factory.openSession();
			hiber.setHibernateFlushMode(FlushMode.AUTO);

			hib = new HiberImpl(hiber);

		}

	}

	public static Optional<Session> getSession() {

		if (hiber != null && hiber.isOpen()) {
			return Optional.of(hiber);
		}
		return Optional.empty();

	}

	public static Optional<Hiber> getHiber() {
		if (hiber == null) {
			loadHiber();
		}
		if (hiber.isOpen() == false) {
			hiber = factory.openSession();
			hib = new HiberImpl(hiber);
		}
		return Optional.of(hib);
	}

	public static Optional<Hiber> getHiberTest() {
		if (hiber == null) {
			loadHiberTest();
		}
		if (hiber.isOpen() == false) {
			hiber = factory.openSession();
			hib = new HiberImpl(hiber);
		}
		return Optional.of(hib);

	}

}
