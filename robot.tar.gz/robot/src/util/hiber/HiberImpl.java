package util.hiber;

import java.io.Serializable;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.Transaction;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class HiberImpl implements Hiber {

	private Session ses;

	public HiberImpl(Session ses) {
		this.ses = ses;

	}

	public boolean execute(Consumer<Session> con) {

		Transaction tx = ses.beginTransaction();

		try {
			con.accept(ses);
			tx.commit();
			return true;
		} catch (Exception e) {

			e.printStackTrace();

			tx.rollback();
			return false;
		}

	}

	public <T> List<T> getAll(Class<T> cl) {

		
		
		CriteriaBuilder cb = ses.getCriteriaBuilder();
		CriteriaQuery<T> cr = cb.createQuery(cl);
		Root<T> root = cr.from(cl);
		cr.select(root);
		 
		Query query = ses.createQuery(cr);
		List<T> results = query.getResultList();
		
		return results;

	}

	public Session getSes() {
		return ses;
	}

	@Override
	public <T> List<T> query(String hql, Class<T> cl) {
		return ses.createQuery(hql, cl).list();

	}

	@Override
	public <T> void delete(T u) {
		ses.delete(u);

	}

	@Override
	public <T> ObservableList<T> getAllObservable(Class<T> cl) {

		return FXCollections.observableArrayList(getAll(cl));
	}

	@Override
	public <T> int save(T u) {

		Transaction tx = ses.beginTransaction();

		try {
			Serializable save = ses.save(u);
			tx.commit();
			return 0;
		} catch (Exception e) {

			e.printStackTrace();

			tx.rollback();
			return 1;
		}

	}

}
