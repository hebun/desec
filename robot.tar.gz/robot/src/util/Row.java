package util;

import java.util.LinkedHashMap;

public class Row extends LinkedHashMap<String, String> {
public static void main(String[] args) {
	Row r= new Row();
	
}
}
