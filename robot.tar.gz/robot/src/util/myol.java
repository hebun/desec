package util;

import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

public class myol implements ListChangeListener<String> {

	@Override
	public void onChanged(Change<? extends String> c) {
		
		
	}

}
