package util;

import java.util.ArrayList;

public class Table extends ArrayList<Row> {
	public Table() {
	
	}
	public static void main(String[] args) {
		Table t = new Table();
		
		t.get(0).get("id");
	}
}
