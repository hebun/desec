package util;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class MyMap<K, V> implements Map<K, V> {

	Object[] keys = new Object[10];
	Object[] values = new Object[10];
	int maxSize = 10;
	int incrementAmount = 10;
	int pointer = 0;

	@Override
	public int size() {
		return 0;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsKey(Object key) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsValue(Object value) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public V get(Object key) {
		int k = 0;
		for (Object object : keys) {
			if (key.equals(key)) {

				break;
			}
			k++;
		}

		if (k >= pointer)
			return null;

		return (V) values[k];
	}

	@Override
	public V put(K key, V value) {
		if (pointer >= maxSize) {
			maxSize += incrementAmount;
			incrementAmount *= 2;
			keys = Arrays.copyOf(keys, maxSize);
			values = Arrays.copyOf(values, maxSize);
		}

		keys[pointer] = key;
		values[pointer] = value;

		return value;
	}

	@Override
	public V remove(Object key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void putAll(Map<? extends K, ? extends V> m) {
		// TODO Auto-generated method stub

	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub

	}

	@Override
	public Set<K> keySet() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<V> values() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Entry<K, V>> entrySet() {
		// TODO Auto-generated method stub
		return null;
	}

}
