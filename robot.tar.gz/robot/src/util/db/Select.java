package util.db;

import com.mysql.jdbc.NotImplemented;

public class Select {
	public Select() throws NotImplemented {
		throw new NotImplemented();
	}
}
