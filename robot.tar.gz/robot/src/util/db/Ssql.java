package util.db;

import java.util.List;
import java.util.Map;

import util.dataprint.Console;
import util.dataprint.DataPrinter;

public class Ssql {
	public Ssql() {

	}

	public static String select(String cols) {
		return " select " + cols + " ";
	}

	public static String from(String table) {
		return " from " + table + " ";
	}

	public static String where(String cond) {
		return " where  " + cond + " ";
	}

	public static String and(String cond) {
		return " and " + cond + " ";
	}

	public static String or(String cond) {
		return " or  " + cond + " ";
	}

	public static String limit(int start, int end) {
		return " limt " + start + "," + end + " ";
	}

	public static String limit(int limit) {
		return " limit " + limit + " ";
	}

	public static void main(String[] args) {
		String sql = select("*") + from("justswapspec") + limit(10);
		List<Map<String, String>> list = Db.selectTable(sql);
		DataPrinter p=new Console();
		p.printTable(list);
		
	}
}
