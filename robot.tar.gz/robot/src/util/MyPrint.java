package util;

import java.util.List;
import java.util.Map;

public class MyPrint {
	static MyLogger log = MyLogger.getInstance();

	public static <T, K> void println(Map<K, T> map) {

		if (log.getLevel() < 3)
			return;
		System.out.println("Map { ");
		for (Map.Entry<K, T> iterable_element : map.entrySet()) {

			System.out.println(iterable_element.getKey() + ":" + iterable_element.getValue());

		}
		System.out.println("}");
	}

	public static <T, K> void println(List<Map<K, T>> list) {

		if (log.getLevel() < 3)
			return;

		System.out.println("List[");
		for (Map<K, T> map : list) {

			System.out.print("Map { ");
			for (Map.Entry<K, T> iterable_element : map.entrySet()) {

				System.out.print(iterable_element.getKey() + ":" + iterable_element.getValue() + ", ");

			}
			System.out.println("}");

		}
		System.out.println("]");
	}

	public static void println(Datatable list) {
		if (log.getLevel() < 3)
			return;
		System.out.println("Datatable[");

		System.out.println(list.columns);

		for (List<String> row : list.data) {
			System.out.println(row);
		}
		System.out.println("]");
	}
}
