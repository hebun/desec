package util.orm;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;

public abstract class SqlBase<T extends SqlBase<T>> {
	protected String fieldList;

	public static final String ISNULL = " is null ";
	protected String tableName;
	protected boolean isBuilt = false;
	protected String currentSql = "";
	protected String orderColumn = null;
	protected String orderWay = "";
	protected int start = 0, count = 0;
	public Map<String, Map.Entry<String, String>> where;// = new Hashtable<String, Map.Entry<String, String>>();
	protected boolean isPrepared = false;

	public SqlBase() {
		where = new Hashtable<String, Map.Entry<String, String>>();
	}

	public T doNotUsePrepared() {
		this.isPrepared = false;
		return thisAsT;
	}

	public T prepared() {
		this.isPrepared = true;
		return thisAsT;
	}

	@SuppressWarnings("unchecked")
	private final T thisAsT = (T) this;

	public T whereEntry(String type, String key, final Object value) {

		char charAt = key.charAt(key.length() - 1);
		if (charAt != ' ' && charAt != '<' && charAt != '>' && charAt != '=') {
			key = key + "=";
		}
		final String fkey = key;
		if (where.containsKey(type))
			type = type + " ";
		where.put(type, new Map.Entry<String, String>() {

			@Override
			public String getKey() {
				return fkey;
			}

			@Override
			public String getValue() {

				if (value == null)
					throw new RuntimeException("SQL: the value of key '" + fkey + "' is null in where statement");
				return value.toString();
			}

			@Override
			public String setValue(String value) {

				return null;
			}
		});

		return thisAsT;
	}

	public T where(final String key, final Object value) {

		return whereEntry("where", key, value);
		 
	}

	public T and(final String key, final String value) {
		if (where.size() == 0)
			throw new RuntimeException("cant use 'and' before 'where'");
		return whereEntry("and", key, value);
	}

	public T or(final String key, final String value) {
	//	Collection<Entry<String, String>> values = where.values();
		if (where.size() == 0)
			throw new RuntimeException("cant use 'or' before 'where'");

		return whereEntry("or", key, value);
	}

	public T desc() {
		this.orderWay = "desc";
		return thisAsT;
	}

	public T limit(int start, int count) {
		this.start = start;
		this.count = count;
		return thisAsT;
	}

	public T limit(int count) {

		return this.limit(0, count);
	}

	public String getFollowings() {
		String ret = "";

		if (orderColumn != null) {
			ret += " order by " + orderColumn + " " + orderWay;
		}
		if (count != 0) {
			ret += " limit " + start + "," + count;
		}
		return ret;
	}

	public abstract String get();

	

	

}
