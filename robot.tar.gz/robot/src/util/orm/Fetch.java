package util.orm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import util.Table;
import util.Datatable;
import util.Db;

public class Fetch extends SqlBase<Fetch> {

	public static final String COUNT = " count(id) as say ";

	String tableAlias;
	String onKey, onValue, onKey2, onValue2;
	String joinType, secondJoinType;
	String groupBy;
	List<Join> joins = new ArrayList<Join>();

	private boolean sqlSet = false;
	boolean quoteValue = true;

	private String currentSql;

	private boolean isObject = false;

	private Class<?> type;

	public Fetch noQuote() {
		quoteValue = false;
		return this;
	}

	public Fetch(String params) {
		setFields(params);

	}

	public Fetch() {
		this("*");

	}

	public Fetch custom(String sql) {
		this.currentSql = sql;
		sqlSet = true;
		return this;
	}

	public Fetch as(String al) {
		this.tableAlias = al;
		return this;
	}

	public Fetch asFirst() {
		this.tableAlias = this.tableName.substring(0, 1);
		return this;
	}

	public Fetch groupBy(String f) {
		this.groupBy = f;
		return this;
	}

	public Join join(String tablej) {
		Join join = new Join(tablej, this);
		this.joins.add(join);
		return join;
	}

	public Fetch setFields(String params) {
		this.isBuilt = false;
		fieldList = params;

		return this;
	}

	public Fetch where(String key, String value) {
		super.where(key, value);
		return this;

	}

	public Fetch from(Class<?> type) {
		this.isBuilt = false;
		String simpleName = type.getSimpleName();
		tableName = lowerFirst(simpleName);
		isObject = true;
		this.type = type;
		return this;
	}

	public static String upFirst(String str) {
		return str.substring(0, 1).toUpperCase(Locale.US) + str.substring(1);
	}

	public static String lowerFirst(String str) {
		return str.substring(0, 1).toLowerCase(Locale.US) + str.substring(1);
	}

	public Fetch from(String table) {
		this.isBuilt = false;

		tableName = table;
		isObject = false;
		return this;
	}

	public List<String> params() {
		if (!isPrepared) {
			throw new RuntimeException("This is not a prepared statement");
		}
		List<String> ret = new ArrayList<>();
		//Set<Map.Entry<String, String>> values =  where.values();
		for (Map.Entry<String, String> entry : where.values()) {
			ret.add(entry.getValue());
		}
		return ret;

	}

	@Override
	public String get() {

		if (sqlSet) {
			return this.currentSql;
		}
		StringBuilder builder = new StringBuilder("select ");
		builder.append(fieldList);

		if (tableName != null && tableName != "") {

			builder.append(" from `").append(this.tableName).append("` ");
			if (tableAlias != null && !tableAlias.equals("")) {
				builder.append(" as " + tableAlias);
			}
			for (Join join : joins) {
				builder.append(" " + join.joinType + " `" + join.table + "` as " + join.alias + "  on " + join.onKey
						+ "=" + join.onValue + " ");
			}

			Set<Map.Entry<String, Map.Entry<String, String>>> entries = where.entrySet();
			for (Map.Entry<String, Map.Entry<String, String>> en : entries) {
				builder.append(' ').append(en.getKey()).append(' ').append(en.getValue().getKey());
				if (isPrepared) {
					builder.append("? ");
				} else {
					if (quoteValue)
						builder.append("'");
					builder.append(en.getValue().getValue());
					if (quoteValue)
						builder.append("' ");
				}
			}
			if (groupBy != null) {
				builder.append(" group by ").append(this.groupBy).append("");
			}
		}
		this.currentSql = builder.toString();
		this.currentSql += super.getFollowings();
		this.isBuilt = true;
		return currentSql;
	}

	public Fetch order(String order) {

		this.orderColumn = order;
		return this;
	}
	public Table getData() {

		if (isPrepared) {
			throw new RuntimeException("prepared is not supported with Table/Row , yet");
			//return Db.preparedSelect(this.get(), this.params());
		} else {
			return Db.selectData(this.get());
		}
	}
	public List<Map<String, String>> getTable() {

		if (isPrepared) {
			return Db.preparedSelect(this.get(), this.params());
		} else {
			return Db.selectTable(this.get());
		}
	}

	public Datatable getDataTable() {
		if (isPrepared) {
			return Db.selectDataTable(this.get());
		} else {
			return Db.selectDataTable(this.get());
		}
	}

	public <T> List<T> getTType() {
		if (isPrepared) {
			return (List<T>) Db.preparedSelect(this.get(), this.params(), type);
		} else {
			return (List<T>) Db.select(this.get(), type);
		}

	}

}