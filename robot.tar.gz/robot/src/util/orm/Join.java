package util.orm;


public  class Join {
		String table, joinType, onKey, onValue, alias;
		private Fetch select;

		public Join(String table, Fetch select) {
			this.select = select;
			this.joinType = "inner join";
			this.table = table;
		}

		public Join left() {
			this.joinType = "left join";
			return this;
		}

		public Join right() {
			this.joinType = "right join";
			return this;
		}

		public Join as(String a) {
			this.alias = a;
			return this;
		}

		public Join asFirst() {
			this.alias = this.table.substring(0, 1);
			return this;
		}

		public Fetch on(String key, String value) {
			this.onKey = key;
			this.onValue = value;
			return select;
		}
	}
