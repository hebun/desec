package util;

public interface Callable {
	public void run();
}
