package util;

import java.awt.Component;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

@SuppressWarnings("serial")
public class Console {

	JScrollPane pane;
	private JPanel main;
	private JTextArea area;

	public Console(JPanel main) {

		this.main = main;
		area = new JTextArea();
		pane = new JScrollPane(area);
		pane.setSize(800, 400);
		main.add(pane);
		PrintStream out = new PrintStream(new OutputStream() {

			@Override
			public void write(int b) throws IOException {
				area.append("" + (char) b);
			}
		});
		System.setOut(out);
	}

	public void setLocation(int i, int j) {
		pane.setLocation(i, j);
		
	}

}
