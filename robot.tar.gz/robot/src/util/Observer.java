package util;

public interface Observer {
	default void update() {
	}
}
