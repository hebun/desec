package util.swing;

import java.awt.Dialog.ModalityType;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class FrameFactory {

	public static void show(JPanel panel) {

		show(panel, 1200);

	}

	public static void show(JPanel panel, int width, int height) {
		JFrame frame = new JFrame(panel.getName());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.setSize(width, height);
		frame.setVisible(true);
		frame.getContentPane().add(panel);
		frame.setLocationRelativeTo(null);

	}

	public static void showDialog(JPanel panel) {

		JDialog frame = new JDialog();
		frame.setTitle(panel.getName());
		// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setModalityType(ModalityType.DOCUMENT_MODAL);
		frame.setSize(1200, 900);

		frame.getContentPane().add(panel);
		frame.setLocationRelativeTo(null);

		frame.setVisible(true);
	}

	public static void show(JPanel panel, int width) {
		show(panel, width, 900);
	}
}
