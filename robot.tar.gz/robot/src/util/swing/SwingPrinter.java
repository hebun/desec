package util.swing;

import java.util.List;
import java.util.Map;

import util.dataprint.DataPrinter;
import util.db.Db;

public class SwingPrinter implements DataPrinter {

	public SwingPrinter() {

	}


	@Override
	public <T, K> void println(Map<K, T> map) {
		println((Map<String,T>)map);
	}

	@Override
	public <T, K> void println(List<Map<K, T>> list) {
	}

	@Override
	public void printTable(List<Map<String, String>> list) {
		
		Grid grid = new Grid();
		grid.setData(list);
		FrameFactory.show(grid);
		grid.resizeCjolumnWidth(grid.getTable());
	}

}
