package util.swing;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.List;
import java.util.Map;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import util.db.Db;

public class Grid extends JPanel {

	private static final long serialVersionUID = 6908667529782919971L;
	private JTable table;
	private TableModel model;
	int height = 400;
	int width = 1120;
	JScrollPane pane;

	public Grid() {

		super.setSize(width, height);
		this.setLocation(20, 20);
		setLayout(null);

	}

	@Override
	public void setSize(int w, int h) {
		super.setSize(w, h);
		width = w;
		height = h;

	}

	public static void main(String[] args) {

		Grid grid = new Grid();
		grid.setData(Db.selectTable("select * from wallet limit 20"));
		FrameFactory.show(grid);
		grid.resizeCjolumnWidth(grid.getTable());
		
	}

	public void setData(final List<Map<String, String>> data) {
		if (pane != null)
			this.remove(pane);
		model = new AbstractTableModel() {

			public Object getValueAt(int rowIndex, int columnIndex) {

				Object object = data.get(rowIndex).values().toArray()[columnIndex];
				// System.out.println("valu" + object);
				return object;
			}

			public int getRowCount() {

				return data.size();
			}

			public int getColumnCount() {

				try {
					return data.get(0).size();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					return 0;
				}
			}

			@Override
			public String getColumnName(int col) {
				String object = data.get(0).keySet().toArray()[col].toString();
				return object;
			}
		};
		setTable(new JTable(model));
		getTable().setAutoCreateRowSorter(true);
		// table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		pane = new JScrollPane(getTable());

		pane.setSize(width, height);
		// pane.setLocation(20, 120);
		pane.setPreferredSize(new Dimension(width, height));

		this.add(pane);

		getTable().setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {
				final Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row,
						column);
				// c.setBackground(row % 2 == 0 ? Color.LIGHT_GRAY : Color.WHITE);

				return c;
			}
		});
		// resizeColumnWidth(table);
		// table.setFillsViewportHeight(true);
		// table.repaint();

	}

	public void resizeCjolumnWidth(JTable table) {
		final TableColumnModel columnModel = table.getColumnModel();
		for (int column = 0; column < table.getColumnCount(); column++) {
			int width = 15; // Min width
			for (int row = 0; row < table.getRowCount(); row++) {
				TableCellRenderer renderer = table.getCellRenderer(row, column);
				Component comp = table.prepareRenderer(renderer, row, column);
				width = Math.max(comp.getPreferredSize().width + 1, width);
			}
			if (width > 300)
				width = 300;
			columnModel.getColumn(column).setPreferredWidth(width);
		}
	}

	public void setsModel(TableModel beanTableModel) {

		model = beanTableModel;
		setTable(new JTable(model));

		pane.setViewportView(getTable());
		pane.setSize(width, height);
		pane.setLocation(20, 20);
		pane.setPreferredSize(new Dimension(width, height));
		this.add(pane);
		getTable().setFillsViewportHeight(true);
	}

	public JTable getTable() {
		return table;
	}

	public void setTable(JTable table) {
		this.table = table;
	}
}
