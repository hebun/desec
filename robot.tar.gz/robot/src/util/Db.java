package util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.swing.JOptionPane;


public class Db {

	public static String JDBC_sDRIVER = "com.mysql.jdbc.Driver";

	public static String DB_URL = "jdbc:mysql://localhost:3306/betting?useUnicode=true&characterEncoding=utf8";
	public static String USER = "root";
	public static String PASS = "2882t";
	public static String database = "";

	public static boolean started = false;
	static Connection conn = null;
	static Statement stmt = null;
	static int say = 0;
	public static boolean debug = false;
	public static boolean dumpTime = false;
	static MyLogger log = MyLogger.getInstance(3);

	public static boolean start(String caller) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			stmt = conn.createStatement();
		} catch (SQLException e) {
			log.severe("cant connect to db." + e.getMessage());

			JOptionPane.showMessageDialog(null, "cant connect to db. " + e.getMessage());
			return false;
		} catch (ClassNotFoundException e) {
			log.severe("cant connect to db." + e.getMessage());
			JOptionPane.showMessageDialog(null, "cant connect to db. " + e.getMessage());
			// e.printStackTrace();
			return false;
		}

		started = true;
		return true;
	}

	public static synchronized void select(String sql, SelectCallbackLoop callback) {

		try {
			if (debug)
				log.info(sql);
			start("");
			ResultSet rs = stmt.executeQuery(sql);
			ResultSetMetaData metaData = rs.getMetaData();
			int colCount = metaData.getColumnCount();

			String[] columns = new String[colCount];

			for (int i = 0; i < colCount; i++) {
				columns[i] = new String(metaData.getColumnLabel(i + 1));
			}

			while (rs.next()) {

				Map<String, String> map = new LinkedHashMap<String, String>();

				for (String col : columns) {
					String string = rs.getString(col);
					if (string == null)
						string = "null";
					map.put(col, string);

				}
				callback.callback(map);

			}

		} catch (SQLException se) {
			log.warning(se.getMessage());
		} catch (Exception e) {
			log.warning(e.getMessage());
		} finally {
			close("");
		}

	}

	public static Datatable selectDataTable(String sql) {

		long start = System.currentTimeMillis();

		Datatable list = null;

		try {

			start("");
			ResultSet rs = stmt.executeQuery(sql);

			ResultSetMetaData data = rs.getMetaData();

			int colCount = data.getColumnCount();

			int k = 0;
			while (rs.next()) {

				if (k++ == 0) {
					//
					List<String> cols = new ArrayList<>();

					for (int i = 1; i <= colCount; i++) {

						String columnLabel = data.getColumnLabel(i);
						columnLabel = makeUniqueColumnLabel(cols, columnLabel);
						cols.add(columnLabel);
					}
					list = new Datatable(cols);
				} else {
					List<String> row = new ArrayList<>();
					for (int i = 1; i <= colCount; i++) {

						String value = rs.getString(i) == null ? " " : rs.getString(i);
						row.add(value);

					}

					list.add(row);
				}

			}
		} catch (SQLException se) {
			log.warning(se.getMessage() + " sql:" + sql);
			se.printStackTrace();
		} catch (Exception e) {
			log.warning(e.getMessage());
			e.printStackTrace();
		} finally {
			close("");
		} // end try
		if (debug) {
			log.info(sql + " time:" + (System.currentTimeMillis() - start));
		}
		return list;
	}

	private static String makeUniqueColumnLabel(List<String> cols, String columnLabel) {
		if (cols.contains(columnLabel)) {
			columnLabel += "_1";
		}
		if (cols.contains(columnLabel)) {
			columnLabel = columnLabel.substring(0, columnLabel.length() - 2) + "_2";
		}
		if (cols.contains(columnLabel)) {
			columnLabel = columnLabel.substring(0, columnLabel.length() - 2) + "_3";
		}
		return columnLabel;
	}

	
	
	public static synchronized List<Map<String, String>>  selectTable(String sql) {

		long start = System.currentTimeMillis();

		List<Map<String, String>> list = null;

		try {

			start("");
			ResultSet rs = stmt.executeQuery(sql);

			ResultSetMetaData data = rs.getMetaData();

			int colCount = data.getColumnCount();

			list = new ArrayList<Map<String, String>>();

			while (rs.next()) {

				Map<String, String> hash = new LinkedHashMap<String, String>();
				for (int i = 1; i <= colCount; i++) {

					String value = rs.getString(i) == null ? " " : rs.getString(i);
					String columnLabel = data.getColumnLabel(i);
					columnLabel = makeUniqueColumnLabel(hash, columnLabel);
					hash.put(columnLabel, value);
				}
				list.add(hash);

			}
		} catch (SQLException se) {
			log.warning(se.getMessage() + " sql:" + sql);
			se.printStackTrace();
		} catch (Exception e) {
			log.warning(e.getMessage());
			e.printStackTrace();
		} finally {
			close("");
		} // end try
		if (debug) {
			log.info(sql + " time:" + (System.currentTimeMillis() - start));
		}
		return list;
	}

	private static String makeUniqueColumnLabel(Map<String, String> hash, String columnLabel) {
		if (hash.containsKey(columnLabel)) {
			columnLabel += "_1";
		}
		if (hash.containsKey(columnLabel)) {
			columnLabel = columnLabel.substring(0, columnLabel.length() - 2) + "_2";
		}
		if (hash.containsKey(columnLabel)) {
			columnLabel = columnLabel.substring(0, columnLabel.length() - 2) + "_3";
		}
		return columnLabel;
	}

	public static synchronized int insert(String sql) {

		try {
			//log.info(sql);
			if (debug)
				log.info(sql);
			start("query not started");
			say++;
			if (say % 100 == 0)
				System.out.println(say + ".");

			int rs = stmt.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);

			if (rs == 0)
				return rs;
			ResultSet generatedKeys = stmt.getGeneratedKeys();
			if (generatedKeys.next()) {

				int long1 = (int) generatedKeys.getLong(1);
				// log.info(long1 + ":long1");
				return long1;
			}
			return rs;
		} catch (SQLException se) {

			log.warning("sql="+sql+" "+se.getMessage());
			//JOptionPane.showMessageDialog(null, "Db access error: " + se.getMessage());
			se.printStackTrace();
			return 0;
		} catch (Exception e) {

			System.out.println("query ex");
			return 0;
		} finally {

			close("");

		}

	}

	public static synchronized int prepareInsert(String sql, List<String> params) {
		DB_URL = "jdbc:mysql://localhost:3306/depoapp?useUnicode=true&characterEncoding=utf8";
		if (debug) {
			String pars = "";

			for (String string : params) {
				pars += string + ",";
			}
			log.info(sql + " pars:" + pars);
		}
		PreparedStatement statement = null;
		started = true;
		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			statement = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			for (int i = 1; i <= params.size(); i++) {
				statement.setString(i, params.get(i - 1));
			}
			int res = statement.executeUpdate();
			if (res == 0)
				return res;
			ResultSet generatedKeys = statement.getGeneratedKeys();
			if (generatedKeys.next()) {
				return (int) generatedKeys.getLong(1);
			}
			return res;
		} catch (Exception ex) {
			log.warning(ex.getMessage());
			return 0;

		} finally {
			try {
				conn.close();
				statement.close();
			} catch (Exception ex) {

			}
		}
	}

	public static int update(String sql) {
		return insert(sql);
	}

	public static int delete(String sql) {
		return insert(sql);
	}

	public static void close(String caller) {

		try {
			if (stmt != null)
				stmt.close();
			conn.close();
		} catch (SQLException e) {
			log.warning(e.getMessage());
		} catch (Exception e) {
			log.warning(e.getMessage());
		}
		started = false;

	}

	public static Map<String, String> callProcedure(String sql) {
		try {
			start("");
			Map<String, String> map = new HashMap<String, String>();

			CallableStatement callableStatement = conn.prepareCall("{" + sql + "}");

			callableStatement.registerOutParameter("pcount", Types.INTEGER);
			callableStatement.registerOutParameter("ucount", Types.INTEGER);

			boolean hadResults = callableStatement.execute();

			while (hadResults) {
				ResultSet rs = callableStatement.getResultSet();

				// process result set

				hadResults = callableStatement.getMoreResults();
			}

			map.put("pcount", callableStatement.getInt("pcount") + "");
			map.put("ucount", callableStatement.getInt("ucount") + "");
			return map;
		} catch (SQLException e) {
			log.warning(e.getMessage());
		}
		return new HashMap<String, String>();

	}

	public static void main(String[] args) {
		
	//	Db.selectTable("select * )
	}

	public static interface SelectCallback {
		public void callback(ResultSet rs, String[] columns) throws SQLException;

	}

	public static interface SelectCallbackLoop {

		public void callback(Map<String, String> map);
	}

	public static interface SelectCallbackTable {

		public void callback(String[] columns, List<List<String>> data);
	}

	public static synchronized List<Map<String, String>> preparedSelect(String sql, List<String> params) {
		PreparedStatement statement = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			started = true;
			statement = conn.prepareStatement(sql);
			for (int i = 1; i <= params.size(); i++) {
				statement.setString(i, params.get(i - 1));
			}

			ResultSet rs = statement.executeQuery();

			ResultSetMetaData data = rs.getMetaData();

			int colCount = data.getColumnCount();

			ArrayList<Map<String, String>> list = new ArrayList<Map<String, String>>();

			while (rs.next()) {

				Map<String, String> hash = new LinkedHashMap<String, String>();
				for (int i = 1; i <= colCount; i++) {

					String value = rs.getString(i) == null ? " " : rs.getString(i);
					String columnLabel = data.getColumnLabel(i);
					columnLabel = makeUniqueColumnLabel(hash, columnLabel);
					hash.put(columnLabel, value);
				}
				list.add(hash);

			}
			if (debug) {
				String pars = "";
				for (String p : params) {
					pars += p + ",";
				}
				log.info(sql + " pars:" + pars);
			}
			return list;

		} catch (ClassNotFoundException e) {
			log.warning(e.getMessage());
			return null;

		} catch (SQLException e) {
			log.warning(e.getMessage());
			return null;

		} finally {
			close("");
		}

	}

	public static synchronized <T> List<T> select(String sql, Class<T> type) {
		long start = System.currentTimeMillis();

		try {

			start("");
			ResultSet rs = stmt.executeQuery(sql);
			ResultSetMetaData metaData = rs.getMetaData();
			int colCount = metaData.getColumnCount();

			String[] columns = new String[colCount];

			for (int i = 0; i < colCount; i++) {
				columns[i] = new String(metaData.getColumnLabel(i + 1));
			}
			List<T> list = new ArrayList<T>();

			while (rs.next()) {
				T obj = type.newInstance();
				for (Field f : type.getDeclaredFields()) {
					if (Modifier.isPrivate(f.getModifiers())) {
						String input = f.getName();
						input = input.substring(0, 1).toUpperCase(Locale.ROOT) + input.substring(1);
						Method met;
						Class<?> type2 = f.getType();
						if (type2 == String.class) {
							try {
								Object object = rs.getObject(f.getName());

								met = type.getMethod("set" + input, String.class);
								if (object != null)

									met.invoke(obj, object.toString());

							} catch (NoSuchMethodException e) {
								log.info(e.getMessage());
							} catch (Exception e) {
								log.info(e.toString());
							}
						}
					}
				}
				list.add(obj);
			}
			return list;
		} catch (SQLException se) {
			log.warning(se.getMessage() + ":" + sql);
			return new ArrayList<T>();
		} catch (Exception e) {
			log.warning(e.getMessage() + ":" + sql);
			return new ArrayList<T>();
		} finally {
			if (debug)
				log.info(sql + " time:" + (System.currentTimeMillis() - start));
			close("");
		}

	}

	public synchronized static <T> List<T> preparedSelect(String sql, List<String> params, Class<T> type) {
		PreparedStatement statement = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			started = true;
			statement = conn.prepareStatement(sql);
			for (int i = 1; i <= params.size(); i++) {
				statement.setString(i, params.get(i - 1));
			}

			ResultSet rs = statement.executeQuery();

			List<T> list = new ArrayList<>();

			while (rs.next()) {
				T obj = type.newInstance();
				for (Field f : type.getDeclaredFields()) {
					if (Modifier.isPrivate(f.getModifiers())) {
						String input = f.getName();
						input = input.substring(0, 1).toUpperCase(Locale.US) + input.substring(1);
						Method met = null;
						Class<?> type2 = f.getType();
						Object object = null;
						try {
							object = rs.getObject(f.getName());

							String methodName = "set" + input;
							met = type.getMethod(methodName, String.class);
							if (object != null)

								met.invoke(obj, object.toString());

						} catch (NoSuchMethodException e) {
							log.info(e.getMessage());

						} catch (Exception e) {

							// log.info(object+"=="+met.toString()+"==="+
							// e.toString());

						}
					}
				}
				list.add(obj);
			}
			if (debug) {
				String pars = "";
				for (String p : params) {
					pars += p + ",";
				}
				log.info(sql + " pars: " + pars);
			}
			return list;

		} catch (ClassNotFoundException e) {
			log.warning(e.getMessage() + ":" + sql);

		} catch (SQLException e) {
			log.warning(e.getMessage() + ":" + sql);

		} catch (InstantiationException e1) {
			log.warning(e1.getMessage() + ":" + sql);
		} catch (IllegalAccessException e1) {
			log.warning(e1.getMessage() + ":" + sql);
		}
		return new ArrayList<T>();

	}

	public static List<Map<String, String>> selectFrom(String table) {
		return selectTable("select * from `" + table + "`");
	}

	public static Table selectData(String sql) {
		long start = System.currentTimeMillis();

		Table list = null;

		try {

			start("");
			ResultSet rs = stmt.executeQuery(sql);

			ResultSetMetaData data = rs.getMetaData();

			int colCount = data.getColumnCount();

			list = new Table();

			while (rs.next()) {

				Row hash = new Row();
				for (int i = 1; i <= colCount; i++) {

					String value = rs.getString(i) == null ? " " : rs.getString(i);
					String columnLabel = data.getColumnLabel(i);
					columnLabel = makeUniqueColumnLabel(hash, columnLabel);
					hash.put(columnLabel, value);
				}
				list.add(hash);

			}
		} catch (SQLException se) {
			log.warning(se.getMessage() + " sql:" + sql);
			se.printStackTrace();
		} catch (Exception e) {
			log.warning(e.getMessage());
			e.printStackTrace();
		} finally {
			close("");
		} // end try
		if (debug) {
			log.info(sql + " time:" + (System.currentTimeMillis() - start));
		}
		return list;
	}

}
