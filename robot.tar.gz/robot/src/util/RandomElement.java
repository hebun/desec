package util;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class RandomElement<T> {
	private List<T> list;

	public RandomElement(List<T> list) {
		this.list = list;

	}

	public T get() {
		return list.get(getRandom(list.size()));
	}

	private static int getRandom(int max) {
		return ThreadLocalRandom.current().nextInt(0, max);
	}

}
