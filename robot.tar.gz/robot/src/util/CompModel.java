package util;

import java.awt.Component;

public interface CompModel {
	int getColumnCount();

	int getRowCount();
	
	Component getCompAt(int x,int y);
}
