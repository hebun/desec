package util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.codec.Charsets;

public class ReadFile {

	private String ls;
	private String cs;
	private String filename;

	public ReadFile(String filename, String ls, String cs) {
		this.filename = filename;
		this.ls = ls;
		if (cs == null)
			this.cs = ",";
		else
			this.cs = cs;

	}

	public ReadFile(String filename) {
		this.filename = filename;

	}

	public StringBuilder getStringBuilder() {

		FileReader fileReader = null;
		try {
			fileReader = new FileReader(this.filename,Charset.forName("UTF-8"));
			// System.out.println(Paths.get("./").toAbsolutePath().toString());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		}
		StringBuilder sb = new StringBuilder();
		try (BufferedReader br = new BufferedReader(fileReader)) {

			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				//sb.append(System.lineSeparator());
				line = br.readLine();
			}

		} catch (IOException e) {

			e.printStackTrace();

		}
		return sb;
	}

	public static void main(String[] args) {
		
		ReadFile readFile = new ReadFile("C:/folder/ismettung.txt");
		StringBuilder sb = readFile.getStringBuilder();
		
		System.out.println(sb.toString());

	}

	public List<Map<String, String>> getTable(List<String> columnNames) {
		if (columnNames == null)
			columnNames = new ArrayList<String>();
		List<Map<String, String>> table = new ArrayList<>();
		FileReader fileReader = null;
		try {
			fileReader = new FileReader(this.filename);
			// System.out.println(Paths.get("./").toAbsolutePath().toString());
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		}
		try (BufferedReader br = new BufferedReader(fileReader)) {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {

				Map<String, String> columns = new HashMap<>();
				String[] split = line.split(Pattern.quote(this.cs));

				int k = 0;
				for (String string : split) {
					columns.put(columnNames.size() == 0 ? k + ".col" : columnNames.get(k), string);
					k++;
					if (k > 2222)
						break;
				}

				table.add(columns);
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			// return sb.toString();
		} catch (IOException e) {

			e.printStackTrace();
			// return "";
		}
		return table;
	}

}
