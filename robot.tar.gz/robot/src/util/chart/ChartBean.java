package util.chart;

import java.util.Calendar;
import java.util.Date;

public class ChartBean {

	private Date tarih;
	private double value;
	private String text;

	public ChartBean(Date tarih, double value, String text) {
		if (tarih == null) {
			tarih = Calendar.getInstance().getTime();
		}
		this.tarih = tarih;
		this.value = value;
		this.text = text;
	}

	public ChartBean(Date tarih, double value) {
		this(tarih, value, "");
	}

	public ChartBean(double value) {
		this(Calendar.getInstance().getTime(), value, "");
	}

	public Date getTarih() {
		return tarih;
	}

	public void setTarih(Date tarih) {
		this.tarih = tarih;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
