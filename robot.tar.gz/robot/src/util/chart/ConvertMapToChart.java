package util.chart;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import util.Util;
import util.chart.ChartBean;

public class ConvertMapToChart {

	private List<Map<String, String>> table;

	public ConvertMapToChart(List<Map<String, String>> table) {
		this.table = table;

	}

	public List<ChartBean> getChartList() {

		Set<Entry<String, String>> set = table.get(0).entrySet();

		Iterator<Entry<String, String>> it = set.iterator();

		for (; it.hasNext();) {
			Entry<String, String> entry = (Entry<String, String>) it.next();
			if (!entry.getKey().equalsIgnoreCase("tarih")) {
				return getChartList(entry.getKey());
			}
		}
		return null;

	}

	public List<ChartBean> getChartList(String col) {
		// System.out.println("getchalist");
		ArrayList<ChartBean> list = new ArrayList<ChartBean>();
		for (Map<String, String> map : table) {
			double value = Util.getDoubleSafe(map.get(col));

			ChartBean cb = new ChartBean(Util.getTimeFromString(map.get("tarih")), value);

			list.add(cb);

		}
		Collections.reverse(list);
		return list;
	}

}
