package util.chart;

import java.util.List;

public interface Chartable {

	List<ChartBean> getChartList(String string);

	String getFieldName();

}
