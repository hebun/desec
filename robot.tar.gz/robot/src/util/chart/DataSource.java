package util.chart;

import java.util.List;
import java.util.Map;

public interface DataSource {
	public Map<String, List<ChartBean>> getData();

	public boolean isFixed();

	public float getDistance();

	public int startValue();
}
