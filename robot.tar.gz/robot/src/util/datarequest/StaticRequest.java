package util.datarequest;

import java.util.List;

import org.apache.http.message.BasicNameValuePair;

public class StaticRequest implements DataRequest {

	@Override
	public StringBuffer getFromNet(String url) {
		return null;
	}

	@Override
	public String post(String url, String payLoad) {
		return 	"";
	}

	@Override
	public String post(String url, List<BasicNameValuePair> postParams) throws Exception {
		return null;
	}

}
