package util.datarequest;

import java.util.List;

import org.apache.http.message.BasicNameValuePair;

public interface DataRequest {

	StringBuffer getFromNet(String url);

	String post(String url, String payLoad);

	String post(String url, List<BasicNameValuePair> postParams) throws Exception;

}