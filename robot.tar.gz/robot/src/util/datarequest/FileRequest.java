package util.datarequest;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.http.message.BasicNameValuePair;

public class FileRequest implements DataRequest {

	@Override
	public StringBuffer getFromNet(String url) {
		try {
		
			BufferedReader br = new BufferedReader(
					new InputStreamReader(new FileInputStream("marslive.json"), "utf-8"));

			StringBuffer sb = new StringBuffer();
			String line = br.readLine();
			sb.append(line + "\n");
			while ((line = br.readLine()) != null) {
				sb.append(line + "\n");
			}
			br.close();

			return sb;

		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public String post(String url, String payLoad) {
		return null;
	}

	@Override
	public String post(String url, List<BasicNameValuePair> postParams) throws Exception {
		return null;
	}

}
