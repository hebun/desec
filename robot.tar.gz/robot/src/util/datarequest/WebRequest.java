package util.datarequest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import bettingutil.Mac;
import util.MyLogger;

public class WebRequest implements DataRequest {
	static MyLogger log = MyLogger.getInstance();
	private static PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
	private static CloseableHttpClient client = HttpClients.custom().setConnectionManager(cm).build();

	@Override
	public StringBuffer getFromNet(String url) {
		// log.info("getting " + " from net: "+url);
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);
		StringBuffer result = null;
		String host = "";
		try {
			host = new URL(url).getHost();
			request.setHeader("Host", host);
		} catch (MalformedURLException e1) {

		}

		request.setHeader("Authority", "api.trongrid.io");
		request.setHeader("Accept", "application/json, text/plain, */*");
		request.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)"
						+ " Chrome/88.0.4324.146 Safari/537.36");
		request.setHeader("Content-Type", "application/json;charset=UTF-8");

		request.setHeader("Referer", host);
		request.setHeader("Accept-Language", "en-US,en;q=0.9,tr;q=0.8");
		HttpResponse response;
		try {
			response = client.execute(request);

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

			result = new StringBuffer();
			// result.append("x");
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line + "\n");

			}
		} catch (IOException e) {

			e.printStackTrace();
		}
		// result.append("x");
		return result;
	}

	public static void main(String[] args) throws Exception {

//		String url = "http://localhost:8096";
//
//		DataRequest r = new WebRequest();
//		StringBuffer res = r.getFromNet(url);
	 System.out.println(marsLive());
		// System.out.println(res);

	}

	private static List<Mac> marsLive() {
		String url = "https://sport.marsbahis318.com/Live/GetEventsList?sportId=1&langId=4&partnerId=250&stTypes=1&stTypes=702&stTypes=2&stTypes=3&stTypes=37&countryCode=TR";

		DataRequest r = new WebRequest();
		StringBuffer res = r.getFromNet(url);

		JsonReader red = Json.createReader(new StringReader(res.toString()));
		JsonArray array = red.readArray();

		List<Mac> maces = new ArrayList<Mac>();
		for (int i = 0; i < array.size(); i++) {

			Mac mac = new Mac();

			JsonObject obj = array.getJsonObject(i);
			String macname = obj.getJsonString("N").getString();
			String[] split = macname.split(" - ");

			System.out.println(macname);
			mac.setHometeam(split[0]);
			mac.setAwayteam(split[1]);

			JsonArray stakeTypes = obj.getJsonArray("StakeTypes");
			if (stakeTypes.size() < 1)
				continue;
			JsonArray stakes = stakeTypes.getJsonObject(0).getJsonArray("Stakes");

			int stakeSize = stakes.size();

			for (int j = 0; j < stakeSize; j++) {

				JsonObject stake = stakes.getJsonObject(j);

				JsonNumber hn = stake.getJsonNumber("F");
				int odd = (int) (hn.doubleValue() * 100);

				if (j == 0)
					mac.setHt(odd);
				else if (j == 1)
					mac.setDraw(odd);
				else if (j == 2)
					mac.setAt(odd);

				System.out.println("          " + hn);
			}
			maces.add(mac);
		}
		return maces;
	}

	@Override
	public String post(String url, String payLoad) {
		log.level = 1;
		String URL = url;
		HttpPost request = new HttpPost(URL);

		try {
			request.setHeader("Host", new URL(URL).getHost());
		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		StringEntity stringEntity = null;
		try {
			stringEntity = new StringEntity(payLoad);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setEntity(stringEntity);

		HttpClient client = HttpClientBuilder.create().build();
		HttpResponse response = null;
		try {
			response = client.execute(request);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int responseCode = response.getStatusLine().getStatusCode();

		log.info(".........Sending 'POST' request to URL : " + URL + " with parameters: " + payLoad
				+ ", with response code: " + responseCode);

		StringBuffer result = new StringBuffer();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))) {
			for (String line; (line = br.readLine()) != null;) {
				result.append(line);
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result.toString();

	}

	@Override
	public String post(String url, List<BasicNameValuePair> postParams) throws Exception {

		String URL = url;
		HttpPost request = new HttpPost(URL);

		request.setHeader("Host", new URL(URL).getHost());

		request.setHeader("Authority", "api.trongrid.io");
		request.setHeader("Accept", "application/json, text/plain, */*");
		request.setHeader("User-Agent",
				"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.146 Safari/537.36");
		request.setHeader("Content-Type", "application/json;charset=UTF-8");
		request.setHeader("Origin", "https://justswap.io");
		request.setHeader("Sec-Fetch-Site", "cross-site");
		request.setHeader("Sec-Fetch-Mode", "cors");
		request.setHeader("Sec-Fetch-Dest", "empty");
		request.setHeader("Referer", "https://justswap.io/");
		request.setHeader("Accept-Language", "en-US,en;q=0.9,tr;q=0.8");

		List<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();

		list.add(new BasicNameValuePair("contract_address", "4184716914c0fdf7110a44030d04d0c4923504d9cc"));
		list.add(new BasicNameValuePair("function_selector", "balanceOf(address)"));
		list.add(new BasicNameValuePair("owner_address", "417e5f4552091a69125d5dfcb7b8c2659029395bdf"));
		list.add(new BasicNameValuePair("parameter",
				"00000000000000000000000064ee8c1a2da984ba891834268db95fa544fe0938"));

		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(list);

		// entity.writeTo(System.out);
		// System.out.println("\nx" + entity.toString());
		// request.setEntity(entity);

		// request.setParams(params);
		StringEntity stringEntity = new StringEntity(
				"{\"contract_address\":\"4184716914c0fdf7110a44030d04d0c4923504d9cc\",\"owner_address\":\"417e5f4552091a69125d5dfcb7b8c2659029395bdf\",\"function_selector\":\"balanceOf(address)\",\"parameter\":\"00000000000000000000000064ee8c1a2da984ba891834268db95fa544fe0938\"}");
		request.setEntity(stringEntity);
		System.out.println(stringEntity.getContent());
		stringEntity.writeTo(System.out);
		System.out.println(request.toString());
		HttpClient client = HttpClientBuilder.create().build();
		HttpResponse response = client.execute(request);

		int responseCode = response.getStatusLine().getStatusCode();

		log.info(".........Sending 'POST' request to URL : " + URL + " with parameters: " + postParams
				+ ", with response code: " + responseCode);

		StringBuffer result = new StringBuffer();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))) {
			for (String line; (line = br.readLine()) != null;) {
				result.append(line);
			}
			br.close();
		}
		return result.toString();
	}
}
