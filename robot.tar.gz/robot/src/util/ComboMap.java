package util;

import java.util.HashMap;

@SuppressWarnings("serial")
class ComboMap extends HashMap<String, String> {

	private String display;

	public ComboMap(String display) {
		super();
		this.display = display;

	}

	public String toString() {
		return this.get(display);

	}
}