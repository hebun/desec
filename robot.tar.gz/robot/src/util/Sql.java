package util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Map;


public abstract class Sql<T extends Sql<T>> {
	protected String fieldList;

	public static final String ISNULL = " is null ";
	protected String tableName;
	protected boolean isBuilt = false;
	protected String currentSql = "";
	protected String orderColumn = null;
	protected String orderWay = "";
	protected int start = 0, count = 0;
	protected Map<String, Map.Entry<String, String>> where = new Hashtable<String, Map.Entry<String, String>>();
	protected boolean isPrepared = false;

	public T doNotUsePrepared() {
		this.isPrepared = false;
		return thisAsT;
	}

	public T prepared() {
		this.isPrepared = true;
		return thisAsT;
	}

	@SuppressWarnings("unchecked")
	private final T thisAsT = (T) this;

	public T whereEntry(String type, String key, final Object value) {

		char charAt = key.charAt(key.length() - 1);
		if (charAt != ' ' && charAt != '<' && charAt != '>' && charAt != '=') {
			key = key + "=";
		}
		final String fkey = key;
		if (where.containsKey(type))
			type = type + " ";
		where.put(type, new Map.Entry<String, String>() {

			@Override
			public String getKey() {
				return fkey;
			}

			@Override
			public String getValue() {

				if (value == null)
					throw new RuntimeException("SQL: the value of key '" + fkey + "' is null in where statement");
				return value.toString();
			}

			@Override
			public String setValue(String value) {

				return null;
			}
		});

		return thisAsT;
	}

	public T where(final String key, final Object value) {

		return whereEntry("where", key, value);
	}

	public T and(final String key, final String value) {
		if (where.size() == 0)
			throw new RuntimeException("cant use 'and' before 'where'");
		return whereEntry("and", key, value);
	}

	public T or(final String key, final String value) {
		if (where.size() == 0)
			throw new RuntimeException("cant use 'or' before 'where'");

		return whereEntry("or", key, value);
	}

	public T desc() {
		this.orderWay = "desc";
		return thisAsT;
	}

	public T limit(int start, int count) {
		this.start = start;
		this.count = count;
		return thisAsT;
	}

	public T limit(int count) {

		return this.limit(0, count);
	}

	public String getFollowings() {
		String ret = "";

		if (orderColumn != null) {
			ret += " order by " + orderColumn + " " + orderWay;
		}
		if (count != 0) {
			ret += " limit " + start + "," + count;
		}
		return ret;
	}

	public abstract String get();

	public static Map<String, String> getFirst(String table) {
		return new Sql.Select().from(table).order("id").getTable().get(0);
	}

	public static Map<String, String> getRandom(String table) {
		return new Sql.Select().from(table).order("RAND()").limit(1).getTable().get(0);
	}

	public static Map<String, String> getById(String table, String id) {
		return new Sql.Select().from(table).where("id", id).getTable().get(0);
	}

	public static class Delete extends Sql<Delete> {

		public Delete(String table) {
			this.tableName = table;

		}

		@Override
		public String get() {
			if (isBuilt)
				return currentSql;
			if (where.size() == 0)
				throw new RuntimeException("cant use delete without where");
			StringBuilder builder = new StringBuilder("delete from  `");
			builder.append(this.tableName);
			builder.append("`");
			for (Map.Entry<String, Map.Entry<String, String>> en : where.entrySet()) {
				builder.append(' ').append(en.getKey()).append(' ').append(en.getValue().getKey());

				builder.append("'").append(en.getValue().getValue()).append("' ");

			}

			this.currentSql = builder.toString();
			this.isBuilt = true;
			this.currentSql += super.getFollowings();
			return currentSql;
		}

		public int run() {

			return Db.delete(this.get());

		}

	}

	public static class Update extends Sql<Update> {
		Map<String, Object> fields = new Hashtable<String, Object>();

		public Update(String table) {
			this.tableName = table;

		}

		public List<String> params() {
			List<String> ret = new ArrayList<>();
			for (Object string : fields.values()) {
				ret.add(string.toString());
			}

			for (Map.Entry<String, Map.Entry<String, String>> en : where.entrySet()) {

				ret.add(en.getValue().getValue());
			}

			return ret;

		}

		boolean quoteValue = true;

		public Update noQuote() {
			quoteValue = false;
			return this;
		}

		public Update addAll(Map<String, Object> fields) {

			if (fields == null) {
				throw new RuntimeException("the map for update  is null");
			}
			this.fields.putAll(fields);

			return this;

		}

		@Override
		public String get() {
			if (isBuilt)
				return currentSql;
			if (where.size() == 0)
				throw new RuntimeException("cant use update without where");

			if (fields.size() <= 0) {
				throw new RuntimeException("Sql.Update:there is no column to set  ");
			}

			StringBuilder builder = new StringBuilder("update ");
			builder.append(this.tableName);
			builder.append(" set ");
			for (Map.Entry<String, Object> en : fields.entrySet()) {
				builder.append(en.getKey()).append("=");

				if (isPrepared) {
					builder.append("?,");
				} else {

					if (quoteValue)
						builder.append("'");
					builder.append(en.getValue().toString());
					if (quoteValue)
						builder.append("'");
					builder.append(",");
				}
			}
			builder.deleteCharAt(builder.length() - 1);
			for (Map.Entry<String, Map.Entry<String, String>> en : where.entrySet()) {
				builder.append(' ').append(en.getKey()).append(' ').append(en.getValue().getKey());
				if (isPrepared) {
					builder.append("? ");
				} else {
					builder.append("'").append(en.getValue().getValue()).append("' ");
				}
			}

			this.currentSql = builder.toString();
			this.currentSql += super.getFollowings();
			this.isBuilt = true;
			return currentSql;
		}

		public Update add(String key, Object value) {

			this.fields.put(key, value);
			return this;

		}

		public int run() {
			if (isPrepared) {
				return Db.prepareInsert(this.get(), this.params());
			} else {
				return Db.update(this.get());
			}
		}

	}

	public static class Insert extends Sql<Insert> {
		private Map<String, Object> fields = new Hashtable<String, Object>();
		String ignore = "";

		String excludes = "";
		boolean isObject = false;
		Object bean = null;

		public Insert(String table) {
			this.tableName = table;

		}

		public <T> Insert(T tripleBean) {
			isObject = true;
			bean = tripleBean;
		}

		public Insert ignore() {
			ignore = "ignore";
			return this;
		}

		public List<String> params() {
			List<String> ret = new ArrayList<>();
			for (Object string : getFields().values()) {
				ret.add(string.toString());
			}
			return ret;

		}

		public Insert add(String key, Object value) {

			if (value == null) {
				throw new RuntimeException("the value for key '" + key + "' is null");
			}
			this.getFields().put(key, value);
			isBuilt = false;
			return this;

		}

		public Insert addNow(String key) {

			this.getFields().put(key, "NOW()");
			return this;

		}

		public Insert addAll(Map<String, Object> fields) {

			if (fields == null) {
				throw new RuntimeException("the map for inserts  is null");
			}
			this.getFields().putAll(fields);

			return this;

		}

		@Override
		public String get() {

			if (isBuilt)
				return currentSql;

			if (isObject) {
				StringBuilder builder = new StringBuilder("insert " + ignore + " into ");
				builder.append("`" + this.tableName + "`");
				builder.append("(");
				Field[] declaredFields = bean.getClass().getDeclaredFields();

				for (Field field : declaredFields) {

					String name = field.getName();
					if (!name.equals(excludes))

						builder.append(name + ",");

				}
				builder.deleteCharAt(builder.length() - 1);
				builder.append(") values (");
				for (Field field : declaredFields) {

					String input = field.getName();
					String name = field.getName();
					if (name.equals(excludes))
						continue;
					input = input.substring(0, 1).toUpperCase(Locale.ROOT) + input.substring(1);
					Method met;

					String getMethod = null;

					try {

						if (field.getType() == boolean.class) {
							getMethod = "is" + input;
						} else {
							getMethod = "get" + input;

						}
						met = bean.getClass().getMethod(getMethod);

						String ret = met.invoke(bean).toString();

						if (field.getType() == String.class) {
							ret = "'" + ret + "'";
						}

						builder.append(ret + ",");

					} catch (IllegalArgumentException | IllegalAccessException e) {
						System.out.println(e.getMessage());
					} catch (NoSuchMethodException e) {
						System.out.println(getMethod + e.getMessage());
					} catch (SecurityException e) {
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						e.printStackTrace();
					}

				}
				builder.deleteCharAt(builder.length() - 1);
				builder.append(")");
				this.currentSql = builder.toString();
				this.currentSql += super.getFollowings();
				this.isBuilt = true;
				return currentSql;

			} else {
				StringBuilder builder = new StringBuilder("insert " + ignore + " into ");
				builder.append("`" + this.tableName + "`");
				builder.append("(");
				for (Map.Entry<String, Object> en : getFields().entrySet()) {
					builder.append(en.getKey());
					builder.append(",");
				}
				builder.deleteCharAt(builder.length() - 1);
				builder.append(") values (");
				for (Map.Entry<String, Object> en : getFields().entrySet()) {

					if (isPrepared) {
						builder.append("?,");

					} else {
						builder.append("'").append(en.getValue().toString()).append("',");
					}
				}
				builder.deleteCharAt(builder.length() - 1);
				builder.append(")");
				this.currentSql = builder.toString();
				this.currentSql += super.getFollowings();
				this.isBuilt = true;
				return currentSql;
			}
		}

		public int run() {

			if (this.fields.get("userid") == null) {
				// throw new RuntimeException("can not use insert without userid sql:" +
				// this.get());
				//MyLogger.getInstance().warning("can not use insert without userid sql:" + this.get());
			}

			if (isPrepared) {
				return Db.prepareInsert(this.get(), this.params());
			} else {

				return Db.insert(this.get());
			}
		}

		public Map<String, Object> getFields() {
			return fields;
		}

		public void setFields(Map<String, Object> fields) {
			this.fields = fields;
		}

		public Insert into(String string) {
			this.tableName = string;
			return this;

		}

		public Insert exclude(String string) {

			this.excludes = string;
			return this;
		}

	}

	public static class Max {
		private String field;
		private String table;

		public Max(String field) {
			this.field = field;

		}

		public Max from(String table) {
			this.table = table;
			return this;
		}

		public int where(String key, String value) {

			String string = new Sql.Select("max(" + field + ") as max_").from(table).where(key, value).getTable().get(0)
					.get("max_");
			if (string == null || string.equals(""))
				throw new RuntimeException("cant use update without where");
			return Integer.parseInt(string);
		}
	}

	public static class Count {
		String table;
		String key, value;
		String keyAnd, valueAnd;

		public Count(String table) {
			this.table = table;
		}

		public Count where(String key, String value) {
			this.key = key;
			this.value = value;
			return this;
		}

		public Count and(String key, String value) {
			this.key = key;
			this.value = value;
			return this;
		}

		public int get() {
			if (key == null || value == null) {
				key = "1";
				value = "1";
			}

			if (keyAnd == null || valueAnd == null) {
				keyAnd = "1";
				valueAnd = "1";
			}
			Select sql = new Sql.Select("count(*) as say").from(this.table).where(key, value).and(keyAnd, valueAnd);

			String say = sql.getTable().get(0).get("say");
			int parseInt = 0;
			try {
				parseInt = Integer.parseInt(say);
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
			return parseInt;

		}
	}

	public static Date getTimeFromString(String time) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd H:m:s");

		Date ret = null;
		try {
			ret = dateFormat.parse(time);
		} catch (ParseException e) {
		
		}
		return ret;

	}

	public static LocalDateTime getLocalDateTimeFromString(String time) {
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd H:m:s.S");

		LocalDateTime ret;

		try {
			ret = LocalDateTime.parse(time, dateFormat);
		} catch (Exception e) {
			return null;
		}

		return ret;

	}

	public static String getFormattedTime() {
		Date time = Calendar.getInstance().getTime();

		return getFormattedTime(time);

	}

	public static String getFormattedTime(Date time) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("Y-M-d H:m:s");

		String formattedTime = dateFormat.format(time);
		return formattedTime;
	}

	public static class Select extends Sql<Select> {

		public static final String COUNT = " count(id) as say ";

		String tableAlias;
		String onKey, onValue, onKey2, onValue2;
		String joinType, secondJoinType;
		String groupBy;
		List<Join> joins = new ArrayList<Sql.Join>();

		private boolean sqlSet = false;
		boolean quoteValue = true;

		public Select noQuote() {
			quoteValue = false;
			return this;
		}

		public Select(String params) {
			setFields(params);

		}

		public Select() {
			this("*");

		}

		public Select custom(String sql) {
			this.currentSql = sql;
			sqlSet = true;
			return this;
		}

		public Select as(String al) {
			this.tableAlias = al;
			return this;
		}

		public Select asFirst() {
			this.tableAlias = this.tableName.substring(0, 1);
			return this;
		}

		public Select groupBy(String f) {
			this.groupBy = f;
			return this;
		}

		public Join join(String tablej) {
			Join join = new Join(tablej, this);
			this.joins.add(join);
			return join;
		}

		public Select setFields(String params) {
			this.isBuilt = false;
			fieldList = params;

			return this;
		}

		public Select from(String table) {
			this.isBuilt = false;
			tableName = table;

			return this;
		}

		public List<String> params() {
			if (!isPrepared) {
				throw new RuntimeException("This is not a prepared statement");
			}
			List<String> ret = new ArrayList<>();
			for (Map.Entry<String, String> entry : where.values()) {
				ret.add(entry.getValue());
			}
			return ret;

		}

		@Override
		public String get() {

			if (sqlSet) {
				return this.currentSql;
			}
			StringBuilder builder = new StringBuilder("select ");
			builder.append(fieldList);

			if (tableName != null && tableName != "") {

				builder.append(" from `").append(this.tableName).append("` ");
				if (tableAlias != null && !tableAlias.equals("")) {
					builder.append(" as " + tableAlias);
				}
				for (Join join : joins) {
					builder.append(" " + join.joinType + " `" + join.table + "` as " + join.alias + "  on " + join.onKey
							+ "=" + join.onValue + " ");
				}

				for (Map.Entry<String, Map.Entry<String, String>> en : where.entrySet()) {
					builder.append(' ').append(en.getKey()).append(' ').append(en.getValue().getKey());
					if (isPrepared) {
						builder.append("? ");
					} else {
						if (quoteValue)
							builder.append("'");
						builder.append(en.getValue().getValue());
						if (quoteValue)
							builder.append("' ");
					}
				}
				if (groupBy != null) {
					builder.append(" group by ").append(this.groupBy).append("");
				}
			}
			this.currentSql = builder.toString();
			this.currentSql += super.getFollowings();
			this.isBuilt = true;
			return currentSql;
		}

		public Select order(String order) {

			this.orderColumn = order;
			return this;
		}

		public List<Map<String, String>> getTable() {
			if (isPrepared) {
				return Db.preparedSelect(this.get(), this.params());
			} else {
				return Db.selectTable(this.get());
			}
		}

		public Datatable getDataTable() {
			if (isPrepared) {
				return Db.selectDataTable(this.get());
			} else {
				return Db.selectDataTable(this.get());
			}
		}

		public <T> List<T> getType(Class<T> type) {
			if (isPrepared) {
				return Db.preparedSelect(this.get(), this.params(), type);
			} else {
				return Db.select(this.get(), type);
			}
		}

	}

	public static class Join {
		String table, joinType, onKey, onValue, alias;
		private Select select;

		public Join(String table, Select select) {
			this.select = select;
			this.joinType = "inner join";
			this.table = table;
		}

		public Join left() {
			this.joinType = "left join";
			return this;
		}

		public Join right() {
			this.joinType = "right join";
			return this;
		}

		public Join as(String a) {
			this.alias = a;
			return this;
		}

		public Join asFirst() {
			this.alias = this.table.substring(0, 1);
			return this;
		}

		public Select on(String key, String value) {
			this.onKey = key;
			this.onValue = value;
			return select;
		}
	}

	public static List<Map<String, String>> getAll(String string) {
		// TODO Auto-generated method stub
		return new Sql.Select().from(string).getTable();
	}

}
