package util.dataprint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface DataPrinter {

	default <T> void printTable(Map<String, T> map) {
		Map<String, String> m = new HashMap<>();

		for (Map.Entry<String, T> entry : map.entrySet()) {
			m.put(entry.getKey(), entry.getValue().toString());
		}

		List<Map<String, String>> list = new ArrayList<>();
		list.add(m);

		printTable(list);
	}

	<T, K> void println(Map<K, T> map);

	<T, K> void println(List<Map<K, T>> list);

	void printTable(List<Map<String, String>> list);

}