package util.dataprint;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import bettingutil.DualMac;
import tui.ConsoleColors;
import util.db.Db;

public class Console implements DataPrinter {
	public static void main(String[] args) {
		new Console().println(Db.selectTable("select * from justswapspec limit 20"));
	}

	@Override
	public <T, K> void println(Map<K, T> map) {

		System.out.println("Map { ");
		for (Map.Entry<K, T> entry : map.entrySet()) {

			System.out.println(entry.getKey() + ":" + entry.getValue());

		}
		System.out.println("}");
	}

	@Override
	public <T, K> void println(List<Map<K, T>> list) {

		System.out.println("List[");
		for (Map<K, T> map : list) {

			System.out.print("Map { ");
			for (Map.Entry<K, T> entry : map.entrySet()) {

				System.out.print(entry.getKey() + ":" + entry.getValue() + ", ");

			}
			System.out.println("}");

		}
		System.out.println("]");
	}

	@Override
	public void printTable(List<Map<String, String>> list) {

		Map<String, Integer> heads = new LinkedHashMap<>();

		String line = "";

		for (Map<String, String> map : list) {

			for (Entry<String, String> entry : map.entrySet()) {

				replaceNull(entry);
				makeHeader(heads, entry);

			}
		}

		line = getHeaderLine(heads, line);
		System.out.println(line);

		String headers = getHeaders(heads);
		System.out.println( headers );
		System.out.println(line);

		for (Map<String, String> map : list) {

			String row = getRow(heads, map);
			System.out.println(row);

		}

	}

	private String getRow(Map<String, Integer> heads, Map<String, String> map) {
		String ret = "";
		for (Entry<String, String> entry : map.entrySet()) {
			String pad = "";
			for (int i = 0; i < heads.get(entry.getKey()) - entry.getValue().length(); i++) {
				pad += " ";
			}

			ret += "| " + entry.getValue() + pad;
		}
		return ret;
	}

	private String getHeaders(Map<String, Integer> heads) {
		String headers = "";
		for (Entry<String, Integer> entry : heads.entrySet()) {

			try {

				String pad = "";
				for (int i = 0; i < entry.getValue() - entry.getKey().length(); i++) {
					pad += " ";
				}

				headers += "| " + entry.getKey() + pad;

			} catch (IllegalArgumentException e) {
				System.out.println(e.getMessage());
			} catch (SecurityException e) {
				e.printStackTrace();
			}
		}
		return headers;
	}

	private String getHeaderLine(Map<String, Integer> heads, String line) {
		for (Entry<String, Integer> entry : heads.entrySet()) {

			line += "+";
			for (int i = 0; i < entry.getValue() + 1; i++) {
				line += "-";
			}

		}
		return line;
	}

	private void makeHeader(Map<String, Integer> heads, Entry<String, String> entry) {
		int valueLen = entry.getValue().length();
		int keyLen = entry.getKey().length();
		int length = valueLen > keyLen ? valueLen : keyLen;

		if (heads.get(entry.getKey()) != null) {
			if (length > heads.get(entry.getKey())) {

				heads.put(entry.getKey(), length);
			}
		} else {
			heads.put(entry.getKey(), length);
		}
	}

	private void replaceNull(Entry<String, String> entry) {
		if (entry.getValue() == null) {
			entry.setValue("NULL");
		}
	}

	public <T> void printGrid(List<T> dms, Class<T> type) {

		List<Map<String, String>> list = convertTypeToMap(dms, type);

		printTable(list);

	}

	public static <T> List<Map<String, String>> convertTypeToMap(List<T> dms, Class<T> type) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();

		Field[] declaredFields = type.getDeclaredFields();
		for (int i = 0; i < dms.size(); i++) {
			T obj = dms.get(i);
			Map<String, String> map = new LinkedHashMap<String, String>();

			map.put("ind", i+"");
			for (Field field : declaredFields) {
				try {

					String input = field.getName();

					if (excludeField(input)) {
						continue;
					}

					input = input.substring(0, 1).toUpperCase(Locale.ROOT) + input.substring(1);
					Method method = type.getMethod("get" + input);
					map.put(field.getName(), method.invoke(obj).toString());

				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				} catch (NoSuchMethodException e) {
				} catch (Exception e) {

				}

			}
			list.add(map);
		}
		return list;
	}

	public static boolean excludeField(String input) {

		switch (input) {
		case "bf":

			return true;
		case "maxlimit":

			return true;

		case "buro":

			return true;
		case "profitedOdd":

			return true;

		case "limitprofit":

			return true;

		case "ratio":

			return true;
		case "tarih":

			return true;
		case "buroTarih":

			return true;

		default:
			return false;
		}

	}
}
