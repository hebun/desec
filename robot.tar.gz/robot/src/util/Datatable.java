package util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class Datatable {
	public List<String> columns;
	public List<List<String>> data;

	public Datatable(List<String> columns) {
		this.columns = columns;
		data = new ArrayList<>();
	}

	public Datatable(String... columns) {
		this.columns = Arrays.asList(columns);
		data = new ArrayList<>();
	}

	public void add(List<String> row) {
		if (columns.size() != row.size()) {
			throw new RuntimeException("invalid column size of row:" + row.size());
		}
		data.add(row);
	}

	public void add(String... row) {
		if (columns.size() != row.length) {
			throw new RuntimeException("invalid column size of row:" + row.length);
		}
		data.add(Arrays.asList(row));
	}

	public void addAll(List<List<String>> all) {
		if (columns.size() != all.get(0).size()) {
			throw new RuntimeException("invalid column size of row:" + all.get(0).size());
		}
		data.addAll(all);
	}

	public String get(int rowIndex, int columnIndex) {

		return this.data.get(rowIndex).get(columnIndex);
	}

	public void set(int rowIndex, int columnIndex, String string) {
		this.data.get(rowIndex).set(columnIndex, string);

	}

}
