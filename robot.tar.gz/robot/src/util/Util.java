package util;

import java.awt.Dialog.ModalityType;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.Map.Entry;
import java.util.regex.Pattern;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;


public class Util {
	public static void launchOneTab(JPanel panel) {

		launchOneTab(panel, 1200);

	}

	public static void launchDialog(JPanel panel) {

		JDialog frame = new JDialog();
		frame.setTitle(panel.getName());
		// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setModalityType(ModalityType.DOCUMENT_MODAL);
		frame.setSize(1200, 900);

		frame.getContentPane().add(panel);
		frame.setLocationRelativeTo(null);

		frame.setVisible(true);
	}

	public static void launchOneTab(JPanel panel, int size) {

		JFrame frame = new JFrame(panel.getName());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.setSize(size, 900);
		frame.setVisible(true);
		frame.getContentPane().add(panel);
		frame.setLocationRelativeTo(null);

	}

	public static String getFormattedTime(Date time) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("Y-M-d H:m:s");

		String formattedTime = dateFormat.format(time);
		return formattedTime;
	}

	public static LocalDate dateToLocaldate(Date date) {
		return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}

	public static Date getTimeFromString(String time) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd H:m:s");

		Date ret = null;
		try {
			ret = dateFormat.parse(time);
		} catch (ParseException e) {
			// MyPanel.log.warning("date pars ex:" + e.getMessage());
		}
		return ret;

	}

	public static String noprecdouble(double d) {
		DecimalFormat format = new DecimalFormat("0.#");
		format.setDecimalFormatSymbols(DecimalFormatSymbols.getInstance(Locale.ROOT));
		return format.format(d);
	}

	public static String getHttp(String url, List<NameValuePair> headers) throws IOException {
		HttpRequestBase request = new HttpGet(url);

		if (headers != null) {
			for (NameValuePair header : headers) {
				request.addHeader(header.getName(), header.getValue());
			}
		}

		HttpClient httpClient = HttpClientBuilder.create().build();
		HttpResponse response = httpClient.execute(request);

		HttpEntity entity = response.getEntity();
		if (entity != null) {
			return EntityUtils.toString(entity);

		}
		return null;
	}

	public static Map<String, String> fetchDoviz() throws Exception {

		System.out.println("fetching doviz");
		String http = getHttp("https://kur.doviz.com/", null);

		// System.out.println(http);

		Map<String, String> map = new HashMap<>();
		Document parse = Jsoup.parse(http);

		org.jsoup.nodes.Element table = parse.getElementById("currencies");

		org.jsoup.nodes.Element td = table.getElementsByTag("tr").get(1).getElementsByTag("td").get(2);
		String usd = td.text().replace(",", ".");

		org.jsoup.nodes.Element tdeuro = table.getElementsByTag("tr").get(2).getElementsByTag("td").get(2);
		String euro = tdeuro.text().replace(",", ".");

		map.put("usd", usd);
		map.put("eur", euro);

		return map;

		// throw new Exception();

	}

	public static void appendToFile(String filename, String str) {
		// append mode
		try (FileWriter writer = new FileWriter(filename, true); BufferedWriter bw = new BufferedWriter(writer)) {

			bw.write(str);
			bw.write("\n");

		} catch (IOException e) {
			System.err.format("IOException: %s%n", e);
		}
	}

	public static float SAMPLE_RATE = 5000f;

	public static void tone(int hz, int msecs) {
		tone(hz, msecs, 0.5);
	}

	public static void tone() {
		tone(800, 400, 0.2);
	}

	public static void tone(int hz, int msecs, double vol) {
//
//		System.out.println("toneing from wav file");
//
//		SimpleAudioPlayer.beep();
		//if (true)			return;

		try {
			byte[] buf = new byte[1];
			AudioFormat af = new AudioFormat(SAMPLE_RATE, // sampleRate
					8, // sampleSizeInBits
					1, // channels
					true, // signed
					false); // bigEndian
			SourceDataLine sdl = AudioSystem.getSourceDataLine(af);
			sdl.open(af);
			sdl.start();
			for (int i = 0; i < msecs * 6; i++) {
				double angle = i / (SAMPLE_RATE / hz) * 2.0 * Math.PI;
				buf[0] = (byte) (Math.sin(angle) * 127.0 * vol);
				sdl.write(buf, 0, 1);
			}
			sdl.drain();
			sdl.stop();
			sdl.close();
		} catch (Exception e) {
			System.out.println("sound ex in util tone():" + e.getMessage());
		}
	}

	public static Date localdateToDate(LocalDate dateToConvert) {
		Instant instant = Instant.from(dateToConvert.atStartOfDay(ZoneId.systemDefault()));
		Date date = Date.from(instant);
		return date;
	}

	public static boolean contains(String base, String str) {

		String[] words = str.split(Pattern.quote(" "));

		int k = 0;
		for (String string : words) {
			k++;

			if (base.indexOf(string) == -1)
				return false;

		}

		return true;
	}

	public static LocalDateTime toLocalDateTime(Calendar calendar) {
		if (calendar == null) {
			return null;
		}
		TimeZone tz = calendar.getTimeZone();
		ZoneId zid = tz == null ? ZoneId.systemDefault() : tz.toZoneId();
		return LocalDateTime.ofInstant(calendar.toInstant(), zid);
	}

	public static String macAdress() {

		InetAddress ip;
		try {

			ip = InetAddress.getLocalHost();
			// System.out.println("Current IP address : " + ip.getHostAddress());

			NetworkInterface network = NetworkInterface.getByInetAddress(ip);

			byte[] mac = network.getHardwareAddress();

			// System.out.print("Current MAC address : ");

			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < mac.length; i++) {
				sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
			}
			System.out.println(sb.toString());
			return sb.toString();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		} catch (SocketException e) {

			e.printStackTrace();

		}
		return "";

	}

	public static void main(String[] args) {
		tone();
	//	tone();

	}

	private static void playWavFile() {

		System.out.println("here");
		String audioFilePath = "beep.wav";
		File audioFile = new File(audioFilePath);

		AudioInputStream audioStream;
		try {
			audioStream = AudioSystem.getAudioInputStream(audioFile);

			AudioFormat format = audioStream.getFormat();

			DataLine.Info info = new DataLine.Info(Clip.class, format);
			Clip audioClip = (Clip) AudioSystem.getLine(info);
			audioClip.open(audioStream);

			audioClip.start();
			audioClip.close();
			audioStream.close();
		} catch (UnsupportedAudioFileException | IOException e) {

			e.printStackTrace();
		} catch (LineUnavailableException e) {

			e.printStackTrace();
		}
	}

	public static int getTodayDow() {
		return Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
	}

	public static String getFormattedTime() {

		Date time = Calendar.getInstance().getTime();

		return getFormattedTime(time);
	}

	public static Double getDouble(String str) {
		try {
			return Double.parseDouble(str.replace(',', '.'));
		} catch (NumberFormatException e) {

			// DoDepo.log.info(str + " is not double");
			return null;
		}
	}

	public static double getDoubleSafe(String str) {
		if (str == null)
			return 0;
		try {
			return Double.parseDouble(str.replace(',', '.'));
		} catch (NumberFormatException e) {

			// DoDepo.log.info(str + " is not double returning 0");
			return 0;
		}
	}

	public static String formatDouble(double d, int digits) {
		String digit = "#0.";

		for (int i = 0; i < digits; i++) {
			digit += "0";
		}

		DecimalFormat df = new DecimalFormat(digit);

		return df.format(d).replace('.', ',');
	}

	public static String formatDouble(String d, int digits) {
		String digit = "#0.";

		for (int i = 0; i < digits; i++) {
			digit += "0";
		}

		DecimalFormat df = new DecimalFormat(digit);

		return df.format(getDoubleSafe(d));
	}

	public static String getFormattedDate(Date time) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("Y-MM-dd");

		String formattedTime = dateFormat.format(time);
		return formattedTime;

	}

	public static String getFormattedTimeDot(Date time) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy H:m");

		String formattedTime = dateFormat.format(time);
		return formattedTime;

	}

	public static String getFormattedDateDot(Date time) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.Y");

		String formattedTime = dateFormat.format(time);
		return formattedTime;

	}

	public static void printTable(List<Map<String, String>> list) {

		Map<String, Integer> heads = new LinkedHashMap<>();

		String line = "";

		for (Map<String, String> map : list) {

			for (Entry<String, String> entry : map.entrySet()) {

				if (entry.getValue() == null) {
					entry.setValue("NULL");
				}
				int valueLen = entry.getValue().length();
				int keyLen = entry.getKey().length();
				int length = valueLen > keyLen ? valueLen : keyLen;

				if (heads.get(entry.getKey()) != null) {
					if (length > heads.get(entry.getKey())) {

						heads.put(entry.getKey(), length);
					}
				} else {
					heads.put(entry.getKey(), length);
				}

			}
		}

		for (Entry<String, Integer> entry : heads.entrySet()) {

			line += "+";
			for (int i = 0; i < entry.getValue() + 1; i++) {
				line += "-";
			}

		}

		System.out.println(line);
		for (Entry<String, Integer> entry : heads.entrySet()) {

			try {

				String pad = "";
				for (int i = 0; i < entry.getValue() - entry.getKey().length(); i++) {
					pad += " ";
				}

				System.out.print("| " + entry.getKey() + pad);

			} catch (IllegalArgumentException e) {
				System.out.println(e.getMessage());
			} catch (SecurityException e) {
				e.printStackTrace();
			}
		}
		System.out.println();
		System.out.println(line);

		for (Map<String, String> map : list) {

			for (Entry<String, String> entry : map.entrySet()) {
				String pad = "";
				for (int i = 0; i < heads.get(entry.getKey()) - entry.getValue().length(); i++) {
					pad += " ";
				}

				System.out.print("| " + entry.getValue() + pad);
			}
			System.out.println();

		}

	}

	public static int getIntSafe(String str) {
		try {
			return Integer.parseInt(str);
		} catch (NumberFormatException e) {
			return 0;
		}
	}

	public static Date getDateFromString(String datestr) {

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		// if(datestr.length()>10)
		// datestr=datestr.substring(0,10);
		Date ret = null;
		try {
			ret = dateFormat.parse(datestr);

		} catch (ParseException e) {
			// MyPanel.log.warning("date pars ex:" + e.getMessage());
		}
		return ret;
	}

	public static <T> void printTable(Map<String, T> map) {

		Map<String, String> m = new HashMap<>();

		for (Map.Entry<String, T> entry : map.entrySet()) {
			m.put(entry.getKey(), entry.getValue().toString());
		}

		List<Map<String, String>> list = new ArrayList<>();
		list.add(m);

		printTable(list);

	}

	public static String getFormattedDateToday() {

		Calendar cal = Calendar.getInstance();

		Date time = cal.getTime();

		return getFormattedDate(time);

	}

	public static String formatDouble(String string) {
		return formatDouble(string, 2);
	}

	public static String formatDouble(double net7) {
		return formatDouble(net7, 2);
	}

	public static Object getFormattedDateDot(LocalDate start) {

		return getFormattedDate(localdateToDate(start));
	}

	public static String getFormattedDateTomorrow() {

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, 1);
		Date time = cal.getTime();

		return getFormattedDate(time);

	}

	public static void sleepms(int i) {
		try {
			Thread.sleep(i);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void sleep(int i) {
		try {
			Thread.sleep(i * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
