package util.command;

public class History extends AbstractCommand {

	private String input;

	public History(String input) {
		this.input = input;

	}

	@Override
	public boolean validate() {
		return true;
	}

	@Override
	public void execute() {
		System.out.print(input);
	}

	@Override
	public String getInput() {
		return input;
	}

}
