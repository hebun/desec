package util.command;

public class ShowHistory extends AbstractCommand implements Command {

	public ShowHistory() {

	}

	@Override
	public boolean validate() {
		return true;
	}

	@Override
	public void execute() {
		
		
	}

}
