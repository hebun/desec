package util.command;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.function.Consumer;

public class CommandManager {

	private Factory factory;

	public CommandManager() {
		factory = new Factory();

	}

	public void evaluate(Command com) {

		if (com == null) {
			System.out.println("invalid command");
			return;
		}

		if (com.validate()) {
			com.execute();
		}
	}

	public void start() {
		new Thread(this::initCommand).start();
	}

	public void addCommand(String co, Consumer<String> r) {
		Command command = new Command() {

			private String input;

			@Override
			public boolean validate() {
				return true;
			}

			@Override
			public void setInput(String input) {
				this.input = input;
			}

			@Override
			public String getInput() {
				return null;
			}

			@Override
			public void execute() {
			
				r.accept(input);
			}
		};

		factory.addCommand(co, command);

	}

	public void initCommand() {

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		while (true) {

			String input = "";
			try {

				input = reader.readLine();
			} catch (IOException e) {

			}
			if (processCommand(input))
				break;

		}
	}

	public boolean processCommand(String input) {

		if (input.equals("q")) {
			System.exit(0);
			return true;
		}
		
		Command command = factory.getCommand(input.split(" ")[0]);
		command.setInput(input);
		command.execute();
		return false;
	}
}
