package util.command;

public class DoNothing extends AbstractCommand {

	@Override
	public boolean validate() {
		return true;
	}

	@Override
	public void execute() {
	}

	@Override
	public String getInput() {
		return null;
	}

}
