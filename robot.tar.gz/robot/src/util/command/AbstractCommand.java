package util.command;



public abstract class AbstractCommand implements Command {
	protected String input;


	

	public AbstractCommand() {

	}

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}



}
