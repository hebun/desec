package util.command;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Help extends AbstractCommand {

	private Map<String, Command> commands;

	public Help(Map<String, Command> commands) {
		this.commands = commands;

	}

	@Override
	public boolean validate() {
		return true;
	}

	@Override
	public void execute() {

		Set<Entry<String, Command>> set = commands.entrySet();

		for (Entry<String, Command> entry : set) {
			System.out.println(entry.getKey() + ":" + entry.getValue().getClass().getSimpleName());
		}

	}

}
