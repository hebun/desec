package util.command;


public interface Command {
	public boolean validate();

	public void execute();

	public String getInput();


	public void setInput( String input);
	
}
