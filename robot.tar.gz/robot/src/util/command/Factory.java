package util.command;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Stack;



public class Factory {

	private Stack<Command> history = new Stack<Command>();
	private Map<String, Command> commands = new HashMap<>();


	public Factory() {
	

		commands.put("h", new Help(commands));
	

		for (Entry<String, Command> c : commands.entrySet()) {

	
		}

	}

	public Command getCommand(String input) {
		Command comm = null;

		if (input.equals("")) {
			if (history.size() == 0) {
				comm = new DoNothing();
			} else {
				History his = new History(history.pop().getInput());

				comm = his;
			}

		}

		for (Entry<String, Command> c : commands.entrySet()) {

			if (input.startsWith(c.getKey())) {
				comm = c.getValue();
				comm.setInput(input);
				break;
			}

		}
		if (comm != null)
			history.push(comm);
		return comm;

	}

	public void addCommand(String co, Command c) {

		Set<Entry<String, Command>> set = commands.entrySet();

		for (Entry<String, Command> entry : set) {

			if (entry.getKey().equals(co)) {
				throw new RuntimeException(co + " command already exists ");
			}

		}

		c.setInput(co);
		
		commands.put(co, c);

	}
}
