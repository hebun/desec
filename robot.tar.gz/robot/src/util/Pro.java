package util;

import java.util.HashMap;
import java.util.Map;

public class Pro {

	long time;
	static long stime = 0;
	private String name = " ";
	static MyLogger log;
	static Map<String,Long> map=new HashMap<>();
	static {
		log = MyLogger.getInstance();
	}

	public Pro(String name) {
		this.name = name;
		time = System.nanoTime();
	}

	public Pro() {

		time = System.nanoTime();
	}

	public void start() {

	}
	public static void prints(String str) {
		long nano = System.nanoTime();
		if(map.containsKey(str)) {
			
			long diff = nano - map.get(str);
			
			log.pro(str+":"+(diff/100_000));
					
		}
		
		map.put(str, nano);
		
	}

	public void print() {
		
		String getOut = getOut();
		System.out.println(getOut);
	
	}

	public  String getOut( ) {
		long nano = System.nanoTime();
		long diff = nano - time;
		String getOut = name + ":" + (diff / 100000);
		time = nano;
		return getOut;
	}

	public void print(String lbl) {
		long nano = System.nanoTime();
		long diff = nano - time;
		System.out.println(lbl + ":" + (diff / 100000));
		time = nano;
	}

	public static void tick() {
		if (stime == 0) {
		
		} else {
			long nano = System.nanoTime();
			long diff = (nano - stime)/1_000_00;
		//	log.pro(diff + "");
		}
		stime = System.nanoTime();
	}
	public static void tick(String name) {
		if (stime == 0) {
		
		} else {
			long nano = System.nanoTime();
			long diff = (nano - stime)/1_000_000;
			log.pro(name+":"+diff + "");
		}
		stime = System.nanoTime();
	}
}
