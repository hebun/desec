package util;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class MyList<E> implements List<E> {

	private Object[] data;
	int pointer = 0;
	int maxSize = 10;
	int incrementAmount = 10;

	public MyList() {
		data = new Object[10];
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return pointer;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean contains(Object o) {

		return false;
	}

	@Override
	public Iterator<E> iterator() {

		return null;
	}

	@Override
	public Object[] toArray() {

		return data;
	}

	@Override
	public <T> T[] toArray(T[] a) {

		return (T[]) data;
	}

	@Override
	public boolean add(E e) {

		if (pointer >= maxSize) {
			maxSize += incrementAmount;
			incrementAmount*=2;
			data = Arrays.copyOf(data, maxSize);
		}

		data[pointer] = e;
		pointer++;
		return true;
	}

	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addAll(Collection<? extends E> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addAll(int index, Collection<? extends E> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void clear() {
		pointer = 0;

	}

	@Override
	public E get(int index) {
		if (index >= pointer)
			return null;
		return (E) data[index];

	}

	@Override
	public E set(int index, E element) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void add(int index, E element) {
		// TODO Auto-generated method stub

	}

	@Override
	public E remove(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int indexOf(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int lastIndexOf(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ListIterator<E> listIterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ListIterator<E> listIterator(int index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<E> subList(int fromIndex, int toIndex) {
		// TODO Auto-generated method stub
		return null;
	}

}
