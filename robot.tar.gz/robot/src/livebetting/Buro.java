package livebetting;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import bettingutil.Mac;
import util.Util;
import util.db.Db;

public interface Buro {
	public List<Mac> getLiveMatches();
	
	default List<Mac> getMatchesFromDb(String buro) {
		
		List<Mac> maces = new ArrayList<Mac>();
		Db.setDB_URL("jdbc:mysql://127.0.0.1:3306/betting?useUnicode=true&characterEncoding=utf8");
		Db.selectFast("select * from mac where buro='bf'", rs -> {
			Mac mac = new Mac();
			try {
				mac.setHometeam(rs.getString("hometeam"));

				mac.setAwayteam(rs.getString("awayteam"));

				mac.setHt(rs.getInt("ht"));

				mac.setDraw(rs.getInt("draw"));

				mac.setAt(rs.getInt("at"));
				mac.setBuro("bf");
				
				Date date =Util.getTimeFromString(rs.getString("tarih"));
				mac.setTarih(date);
				maces.add(mac);
			} catch (SQLException e) {

				e.printStackTrace();
			}
		});

		return maces;
		
	}
}
