package livebetting;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import bettingutil.DualMac;
import util.dataprint.Console;
import util.db.Db;
import util.swing.FrameFactory;
import util.swing.Grid;

public class SwingLive extends JPanel implements View {

	private Grid grid;
	LiveBetModel model;

	public SwingLive() {

		grid = new Grid();
		// grid.setData(Db.selectTable("select * from wallet limit 20"));

		grid.setLocation(20, 20);
		this.setLayout(null);
		this.add(grid);
	}

	public static void main(String[] args) {

		SwingLive panel = new SwingLive();

		LiveBetModel modeld = new LiveBetModel();

		panel.setModel(modeld);

		MarsOrbit mo = new MarsOrbit(modeld, panel);

		new Thread(() -> {
			mo.run();
		}).start();

		FrameFactory.show(panel);
	}

	private void setModel(LiveBetModel modeld) {
		this.model = modeld;
	}

	@Override
	public void refresh() {

		SwingUtilities.invokeLater(() -> {

			grid.setData(Console.convertTypeToMap(model.getDms(), DualMac.class));
			grid.resizeCjolumnWidth(grid.getTable());
		});
	}
}
