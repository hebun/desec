package livebetting;

import java.util.List;

import bettingutil.DualMac;
import bettingutil.DualMacs;
import bettingutil.LigFilter;
import bettingutil.Mac;
import util.MyLogger;
import util.Pro;

public class LiveBetModel {
	MyLogger log = MyLogger.getInstance();

	private List<Mac> marsLive;
	private List<Mac> orbit;
	private List<Mac> tempoLive;

	private List<DualMac> dms;
	private String marsNo = "446";
	private List<Mac> inter;

	private int maxOran = 1000;
	private LigFilter ligFilter;
	private DualMacs dm;

	public LiveBetModel() {

		ligFilter = new LigFilter();
		dm = new DualMacs(maxOran, ligFilter);
	}

	public void dualMacs() {

		Pro.prints("dm");
		dms = dm.findDualMacs(orbit, marsLive);

		dms.addAll(dm.findDualMacs(orbit, tempoLive));

		dms.sort((o1, o2) -> Double.compare(o2.getRatio(), o1.getRatio()));

		dm.warn(dms);
		Pro.prints("dm");
	}

	public List<Mac> getMarsLive() {
		return marsLive;
	}

	public void setMarsLive(List<Mac> marsLive) {
		this.marsLive = marsLive;
	}

	public List<Mac> getOrbit() {
		return orbit;
	}

	public void setOrbit(List<Mac> orbit) {
		this.orbit = orbit;
	}

	public List<DualMac> getDms() {
		return dms;
	}

	public void setDms(List<DualMac> dms) {
		this.dms = dms;
	}

	public String getMarsNo() {
		return marsNo;
	}

	public void setMarsNo(String marsNo) {
		this.marsNo = marsNo;
	}

	public List<Mac> getInter() {
		return inter;
	}

	public void setInter(List<Mac> inter) {
		this.inter = inter;
	}

	public int getMaxOran() {
		return maxOran;
	}

	public void setMaxOran(int maxOran) {
		this.maxOran = maxOran;
	}

	public List<Mac> getTempoLive() {
		return tempoLive;
	}

	public void setTempoLive(List<Mac> tempoLive) {
		this.tempoLive = tempoLive;
	}

	public void excludeLig(int ind) {
		String lig = dms.get(ind).getLigname();
		log.info("adding lig:" + lig);
		ligFilter.addLig(lig);
	}

}
