package livebetting;

import java.util.List;

import bettingutil.Mac;

public class Orbit implements Buro {

	@Override
	public List<Mac> getLiveMatches() {
		
		
		
		return null;
	}

}
