package livebetting;

import bettingutil.DualMac;
import util.dataprint.Console;

public class ConsoleView implements View {
	private LiveBetModel model;
	Console console = new Console();
	public ConsoleView(LiveBetModel model) {
		this.model = model;
		
	}

	@Override
	public void refresh() {
	
		console.printGrid(model.getDms(), DualMac.class);
	}

}
