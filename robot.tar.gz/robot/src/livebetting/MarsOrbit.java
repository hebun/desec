package livebetting;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import bettingutil.DualMac;
import bettingutil.DualMacs;
import bettingutil.Mac;
import util.Util;
import util.command.CommandManager;
import util.dataprint.Console;
import util.db.Db;

public class MarsOrbit {

	private static double maxOran;
	private CommandManager cm;
	private LiveBetModel model;
	private View view;

	public MarsOrbit(LiveBetModel model, View view) {
		this.model = model;
		this.view = view;
		cm = new CommandManager();

	}

	public static void main(String[] args) {
		for (String string : args) {
			System.out.println(string);
		}

		String marsNo = "";
		if (args.length > 0)
			marsNo = args[0];
		else {
			marsNo = "404";
		}
		if (args.length > 1)

			maxOran = Util.getDoubleSafe(args[1]);
		else {
			maxOran = 10;
		}

		LiveBetModel modeld = new LiveBetModel();
		modeld.setMarsNo(marsNo);
		modeld.setMaxOran((int) (maxOran * 100));
		MarsOrbit mo = new MarsOrbit(modeld, new ConsoleView(modeld));
		mo.run();
	}

	public void run() {

		cm.start();
		Console console = new Console();

		cm.addCommand("r", (e) -> {
			console.printGrid(model.getMarsLive(), Mac.class);
			console.printGrid(model.getOrbit(), Mac.class);
		});
		cm.addCommand("o", (e) -> {

			model.setMaxOran(Integer.parseInt(e.split(" ")[1]) * 100);

		});

		cm.addCommand("d", (e) -> {
			System.out.println(e);
			int ind = Integer.parseInt(e.split(" ")[1]);
			model.excludeLig(ind);

		});

		for (int i = 0; i < 1000; i++) {
			model.setOrbit(orbitFromDb());
			model.setMarsLive(new Marsbahis(model.getMarsNo()).getLiveMatches());
			model.setTempoLive(tempoFromDb());

			if (!checkOrbitUptime()) {
				Util.sleep(30);
				continue;
			}

			model.dualMacs();
			this.view.refresh();

			for (DualMac dualMac : model.getDms()) {

				// System.out.println(dualMac);
			}
			Util.sleep(10);
		}

	}

	private boolean checkOrbitUptime() {
		if (model.getOrbit().size() > 0) {
			Mac mac = model.getOrbit().get(0);
			long milis = System.currentTimeMillis();
			long diff = (milis - mac.getTarih().getTime()) / 1000;
			if (diff > 60) {
				Util.tone();
				Util.tone();
				System.out.println("orbit is " + diff + " sec behind.");

				return false;
			}
		}
		return true;
	}

	private List<Mac> tempoFromDb() {
		return matchesFromDb("tempo");
	}

	private List<Mac> orbitFromDb() {
		return matchesFromDb("bf");
	}

	private List<Mac> matchesFromDb(String buro) {
		List<Mac> maces = new ArrayList<Mac>();
		Db.setDB_URL("jdbc:mysql://localhost:3306/betting?useUnicode=true&characterEncoding=utf8");

		Db.selectFast("select * from mac where buro='" + buro + "'", rs -> {
			Mac mac = new Mac();
			try {
				mac.setHometeam(rs.getString("hometeam"));

				mac.setAwayteam(rs.getString("awayteam"));

				mac.setHt(rs.getInt("ht"));

				mac.setDraw(rs.getInt("draw"));

				mac.setAt(rs.getInt("at"));
				mac.setBuro(buro);

				Date date = Util.getTimeFromString(rs.getString("tarih"));
				mac.setTarih(date);
				maces.add(mac);
			} catch (SQLException e) {

				e.printStackTrace();
			}
		});

		return maces;
	}

}
