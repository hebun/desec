package livebetting;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Calendar;

import bettingutil.Mac;
import util.Util;

public class UnderdogFile {

	public void saveunderdogMac(Mac dm) {

		Calendar ins = Calendar.getInstance();
		String match = ins.get(Calendar.DAY_OF_YEAR) + " " + dm.getHometeam() + " v " + dm.getAwayteam();

		try {
			if (!checkMatch(match)) {
				Files.write(Paths.get("underdogs"),
						(match + (" " + dm.getHomeScore() + ":" + dm.getAwayScore()) + "\n").getBytes(),
						StandardOpenOption.CREATE, StandardOpenOption.APPEND);
				Util.tone(1200, 400, 0.3);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private boolean checkMatch(String match) {
		String fileName = "underdogs";

		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {

			String line = br.readLine();

			while (line != null) {

				String m = line.substring(0, line.lastIndexOf(" "));

				if (m.equals(match)) {

					return true;

				}

				line = br.readLine();
			}
			return false;

		} catch (IOException e) {

			e.printStackTrace();

		}
		return false;

	}
}
