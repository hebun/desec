package livebetting;

public interface View {

	void refresh();

}
