package livebetting;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;

import bettingutil.Mac;
import util.MyLogger;
import util.dataprint.Console;
import util.datarequest.DataRequest;
import util.datarequest.WebRequest;

public class Marsbahis implements Buro {
	private String marsNo;
	private Underdog ud;
	private SaveSurebet ss;

	public Marsbahis(String marsNo) {
		this.marsNo = marsNo;
		ud = new Underdog();
		ss = new SaveSurebet();
	}

	public List<Mac> getLiveMatches() {

		String url = "https://sport.marsbahis" + marsNo
				+ ".com/Live/GetEventsList?sportId=1&langId=4&partnerId=250&stTypes=1&stTypes=702&stTypes=2&stTypes=3&stTypes=37&countryCode=TR";
		System.out.println(marsNo);
		//System.out.println(url);
	

		DataRequest r = new WebRequest();
		StringBuffer res = r.getFromNet(url);

		JsonReader red = Json.createReader(new StringReader(res.toString()));
		JsonArray array = red.readArray();

		List<Mac> maces = new ArrayList<Mac>();
		for (int i = 0; i < array.size(); i++) {

			Mac mac = new Mac();

			JsonObject obj = array.getJsonObject(i);
			String macname = obj.getJsonString("N").getString();
			if(macname.contains("Vera")) {
				System.out.println();
			}
			try {
				String ligname = obj.getJsonString("CN").getString();
				mac.setLig(ligname);
			} catch (Exception e) {
				MyLogger.getInstance().warning(macname + " error reading lig name");
			}
			boolean isLi = obj.getBoolean("IsLI", false);//is live
			if (!isLi)
				continue;
			
			boolean isBS = obj.getBoolean("BS", false);// is suspended
			if (!isBS)
				continue;
			
			
			
			try {
				int hs = obj.getJsonNumber("HS").intValue();
				mac.setHomeScore(hs);
				int as = obj.getJsonNumber("AS").intValue();
				mac.setAwayScore(as);
			} catch (Exception e) {
				MyLogger.getInstance().warning(macname + " error reading score");
			}

			String[] split = macname.split(" - ");

			//
			mac.setHometeam(split[0]);
			if (split.length < 2) {
				System.out.println(macname + " has no 2 team name");
				continue;
			}
			mac.setAwayteam(split[1]);

			try {
				int min=obj.getInt("PT");
				
				mac.setMin(min);
				
				ss.updateSurbetScores(mac);
			} catch (Exception e1) {
				MyLogger.getInstance().warning(macname + " error updating last min");
			}
			JsonArray stakeTypes = obj.getJsonArray("StakeTypes");
			if (stakeTypes.size() < 1)
				continue;
			JsonObject stakeType0 = stakeTypes.getJsonObject(0);

			JsonString stakeName = stakeType0.getJsonString("N");

			
			if (!stakeName.toString().contains("Maç Sonucu 1X2")) {
			//	System.out.println(macname + " doesn't have mac sonucu. continuing and updating score");
				ud.updateScore(mac);
				continue;
			}

			JsonArray stakes = stakeType0.getJsonArray("Stakes");

			int stakeSize = stakes.size();

			boolean outRangeOdd = false;
			for (int j = 0; j < stakeSize; j++) {

				JsonObject stake = stakes.getJsonObject(j);

				JsonNumber hn = stake.getJsonNumber("F");
				int odd = (int) (hn.doubleValue() * 100);

				if (j == 0)
					mac.setHt(odd);
				else if (j == 1)
					mac.setDraw(odd);
				else if (j == 2)
					mac.setAt(odd);
				if (odd < 101 || odd >10000) {
					System.out.println(odd);
					outRangeOdd = true;
					break;
				}

			}
			if (outRangeOdd)
				continue;
			mac.setBuro("marsbahis");

			// System.out.println(mac.getHometeam() + ":" + isLi);

			maces.add(mac);
		}
		for (Mac mac : maces) {
		
			int hs = mac.getHomeScore();
			int as = mac.getAwayScore();

			ud.updateScore(mac);
			
			if (hs != as) {// non-draw

				if ((hs > as && mac.getHt() > 200) || (as > hs && mac.getAt() > 200)) {
					mac.setUnderdogGol(true);
					ud.saveunderdogMac(mac);
					
				}
			}

		}
		return maces;
	}

	public static void main(String[] args) {
	
		List<Mac> mars = new Marsbahis("420").getLiveMatches();
		new Console().printGrid(mars, Mac.class);
	}

}
