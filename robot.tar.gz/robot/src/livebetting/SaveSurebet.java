package livebetting;

import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;

import bettingutil.DualMac;
import bettingutil.Mac;
import util.Db;
import util.MyLogger;
import util.Util;
import util.db.Sql;
import util.db.Sql.Update;

public class SaveSurebet {

	int minSecondsForSb = 30;

	// Map<Mac,>

	private void insertSbMatch(DualMac dm, String name, String score, int doy) {

		Sql.Insert ins = new Sql.Insert("sbmars");

		ins.add("doy", doy);
		ins.add("name", name.replace("'", ""));
		ins.add("score", score);
		ins.add("orans", dm.getBuro().getHt() + " " + dm.getBuro().getDraw() + " " + dm.getBuro().getAt());
		ins.add("lig", dm.getBuro().getLig());
		ins.add("sbcol", dm.getProOdd());
		ins.add("prooran", dm.getProfitedOdd());
		ins.add("oranbf", dm.getProfitedOddBf());
		ins.add("updateMin", dm.getBuro().getMin());
		ins.add("sbamount", ((int) dm.getProfit()));
		Db.insert(ins.get());
	}

	public void saveSurebet(List<DualMac> sbmacs) {

		for (DualMac dualMac : sbmacs) {
			String name = dualMac.getBuro().getHometeam() + " v " + dualMac.getBuro().getAwayteam();
			String score = dualMac.getBuro().getHomeScore() + ":" + dualMac.getBuro().getAwayScore();
			int doy = getDoy();

			int savedId = checkAlreadySavedSbMatch(dualMac.getBuro());
			if (savedId == 0)

				insertSbMatch(dualMac, name, score, doy);
			else {
				updateSbMatchScore(dualMac.getBuro(), name, score, savedId);
			}
		}

	}

	MyLogger log = MyLogger.getInstance();

	private void updateSbMatchScore(Mac mac, String name, String score, int savedId) {

	//	log.info("upddating score of id" + savedId);
		Sql.Update up = new Update("sbmars");
		up.add("lastScore", score);
		up.add("updateMin", mac.getMin());
		up.add("updateTime", Util.getFormattedTime());
		up.where("id", savedId);
		up.run();

	}

	private int checkAlreadySavedSbMatch(Mac mac) {
		String name = mac.getHometeam() + " v " + mac.getAwayteam();

		List<Map<String, String>> tb = Db.selectTable(
				"select * from sbmars where doy=" + getDoy() + " and name like '" + name.replace("'", "") + "'");
		if (tb.size() == 0)
			return 0;
		else {
			return Integer.parseInt(tb.get(0).get("id"));
		}

	}

	private int getDoy() {
		return Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
	}

	public void updateSurbetScores(Mac mac) {

		String name = mac.getHometeam() + " v " + mac.getAwayteam();
		String score = mac.getHomeScore() + ":" + mac.getAwayScore();

		int savedId = checkAlreadySavedSbMatch(mac);
		if (savedId != 0) {

			updateSbMatchScore(mac, name, score, savedId);
		}
	}

	public void updateSbAmount(List<DualMac> dualmacs) {

		List<Map<String, String>> tb = Db.selectTable("select * from sbmars where  doy=" + getDoy());

		for (Map<String, String> map : tb) {

			Optional<DualMac> findAny = dualmacs.stream().filter(new Predicate<DualMac>() {
				@Override
				public boolean test(DualMac t) {
					String name = t.getBuro().getHometeam() + " v " + t.getBuro().getAwayteam();

					return name.equals(map.get("name"));

				}
			}).findAny();
			
			
			
			if (findAny.isPresent()) {
				DualMac dm = findAny.get();
				String sql = "update sbmars set sbamount=concat(sbamount,'," + ((int) (dm.getProfit())) + "') where id="
						+ map.get("id");
				Db.update(sql);
			}else {
				
				
				
				String sql = "update sbmars set sbamount=concat(sbamount,'0') where id="
						+ map.get("id");
				Db.update(sql);
			}
		}

	}
}
