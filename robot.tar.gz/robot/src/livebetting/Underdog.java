package livebetting;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.media.nativewindow.util.Point;

import org.hibernate.internal.build.AllowSysOut;

import bettingutil.DualMac;
import bettingutil.Mac;
import util.Db;
import util.MyLogger;
import util.Util;
import util.db.Sql;
import util.db.Sql.Update;

public class Underdog {

	public void saveunderdogMac(Mac dm) {

		if (!checkMatch(dm)) {

			Util.tone(1200, 400, 0.3);
		}

	}

	private boolean checkMatch(Mac dm) {

		String name = dm.getHometeam() + " v " + dm.getAwayteam();
		String score = dm.getHomeScore() + ":" + dm.getAwayScore();
		int doy = getDoy();
		String sql = "select * from underdog where doy=" + doy + " and name like '" + name + "' and score like '"
				+ score + "'";
		if (Db.selectTable(sql).size() > 0) {
			return true;
		}

		if (!checkOranRange(dm)) {
			return true;
		}
		// Db.selectTable(sql)

		insertMatch(dm, name, score, doy);
		return false;

	}

	private int getDoy() {
		return Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
	}

	private void insertMatch(Mac dm, String name, String score, int doy) {
		Sql.Insert ins = new Sql.Insert("underdog");

		ins.add("doy", doy);
		ins.add("name", name.replace("'", ""));
		ins.add("score", score);
		ins.add("orans", dm.getHt() + " " + dm.getDraw() + " " + dm.getAt());
		ins.add("lig", dm.getLig());
		Db.insert(ins.get());
	}

	private boolean checkOranRange(Mac dm) {
		if (dm.getHt() < 103 || dm.getAt() < 103 || dm.getDraw() < 103 || dm.getHt() > 10000 || dm.getAt() > 10000
				|| dm.getDraw() > 10000)
			return false;
		return true;
	}

	public void updateScore(Mac dm) {

		String name = dm.getHometeam() + " v " + dm.getAwayteam();
		if (name.contains("Vera")) {
			System.out.println();
		}
		String score = dm.getHomeScore() + ":" + dm.getAwayScore();
		int doy = getDoy();
		String sql = "select * from underdog where doy=" + doy + " and name like '" + name.replace("'", "") + "'";
		List<Map<String, String>> st = Db.selectTable(sql);
		if (st.size() == 0)
			return;
		for (Map<String, String> m : st) {
			if (m.get("score").equals(score))
				return;
			else {
				try {
					String[] split = m.get("score").split(":");
					int hs = Integer.parseInt(split[0]);
					int as = Integer.parseInt(split[1]);

					if (hs + as > dm.getHomeScore() + dm.getAwayScore()) {
						System.out.println("gol iptal" + m);

						Db.update("update underdog set txt='gol iptal' where id=" + m.get("id"));

						return;
					}
				} catch (Exception e) {
					System.out.println("err in gol iptal");
					e.printStackTrace();
				}

			}
		}

		if (!checkOranRange(dm)) {
			return;
		}
		insertMatch(dm, name, score, doy);
	}

	public static void main(String[] args) {

		List<Map<String, String>> table = Db.selectTable("select * from underdog where doy>250  order by id");

		Map<String, List<Map<String, String>>> names = new LinkedHashMap<String, List<Map<String, String>>>();

		for (Map<String, String> map : table) {

			String uname = map.get("doy") + map.get("name");

			boolean anyMatch = names.keySet().stream().anyMatch(p -> p.equals(uname));

			String orans = map.get("score") + "   " + map.get("orans") + "   " + map.get("created");
			if (anyMatch) {

				names.get(uname).add(map);
			} else {
				names.put(uname, new ArrayList<Map<String, String>>());
				names.get(uname).add(map);

			}

		}

		Set<Entry<String, List<Map<String, String>>>> set = names.entrySet();

		int draw = 0, duz = 0, dondu = 0;
		int drawp = 0, duzp = 0, dondup = 0;

		for (Entry<String, List<Map<String, String>>> entry : set) {
			System.out.println(entry.getKey());

			List<Map<String, String>> list = entry.getValue();

			String[] split = list.get(0).get("score").split(":");
			int hs = Integer.parseInt(split[0]);
			int as = Integer.parseInt(split[1]);

			String[] split1 = list.get(list.size() - 1).get("score").split(":");
			int hs1 = Integer.parseInt(split1[0]);
			int as1 = Integer.parseInt(split1[1]);

			if (hs1 == as1) {
				draw++;
				drawp += Integer.parseInt(list.get(0).get("orans").split(" ")[1]) - 100;
			} else if (hs > as && hs1 < as1) {
				dondup += Integer.parseInt(list.get(0).get("orans").split(" ")[2]) - 100;
				dondu++;

			} else if (hs < as && hs1 > as1) {
				dondup += Integer.parseInt(list.get(0).get("orans").split(" ")[0]) - 100;
				dondu++;

			} else if (hs > as && hs1 > as1) {
				duzp += Integer.parseInt(list.get(0).get("orans").split(" ")[0]) - 100;
				duz++;
			} else if (hs < as && hs1 < as1) {
				duzp += Integer.parseInt(list.get(0).get("orans").split(" ")[2]) - 100;
				duz++;
			}

			for (Map<String, String> o : list) {
				String orans = o.get("score") + "   " + o.get("orans") + "   " + o.get("created");
				System.out.println("            " + orans);

			}

		}
		drawp = drawp - (duz + dondu) * 100;
		duzp = duzp - (draw + dondu) * 100;
		dondup = dondup - (duz + draw) * 100;
		System.out.println("sonuclar:" + draw + " " + duz + " " + dondu);
		System.out.println("sonuclar:" + drawp + " " + duzp + " " + dondup);
	}

	
}
