package livebetting;

import java.util.Map;

import util.Db;
import util.Db.SelectCallbackLoop;

public class SurebetCalcs {
	private static final class SelectCallbackLoopImplementation implements SelectCallbackLoop {

		private int kar = 0;

		@Override
		public void callback(Map<String, String> map) {
			int result = 0;
			int played = 0;

			String sbcol = map.get("sbcol");
			played = sbcol.equals("ht") ? 1 : sbcol.equals("at") ? 2 : 0;

			String[] scores = map.get("lastScore").split(":");

			int hs = Integer.parseInt(scores[0]);
			int as = Integer.parseInt(scores[1]);

			result = hs > as ? 1 : hs == as ? 0 : 2;

			sbcol+= !sbcol.equals("draw")?"  ":"";
			String info = map.get("lastScore") + " " + sbcol + " " + map.get("prooran") + " "
					+ map.get("sbamount").substring(0, Math.min(20, map.get("sbamount").length()));
			if (result == played) {
				kar += Integer.parseInt(map.get("prooran")) - 100;

				System.out.println("win  " + info);
			} else {
				kar -= 100;
				System.out.println("lose " + info);
			}

		}

		public int getKar() {
			return kar;
		}

		public void setKar(int kar) {
			this.kar = kar;
		}
	}

	public static void main(String[] args) {

		String sql = "select * from sbmars where updateMin>90 and doy>250 order by id";

		Integer kar = 0;

		SelectCallbackLoopImplementation obj = new SelectCallbackLoopImplementation();
		Db.select(sql, obj);
		System.out.println(obj.getKar());

	}
}
