package dynaInsert;

public class InsertAll implements ColumnSelector {

	@Override
	public boolean isValid(String column) {
		return true;
	}

}
