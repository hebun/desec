package dynaInsert;

import java.util.ArrayList;
import java.util.List;

public class InsertSpecial implements ColumnSelector {

	List<String> tokens;

	public InsertSpecial() {
		tokens = new ArrayList<String>();
		tokens.add("TUCjCMAwbpmeACMBkedFh9N5u3fUmpCrQ7");
		tokens.add("THsSSczBw9RRMJWYL5j2MtcgaPasL2xPGP");
	}

	@Override
	public boolean isValid(String address) {
		for (String s : tokens) {
			if (s.equals(address))
				return true;
		}
		return false;
	}

}
