package dynaInsert;

public interface ColumnSelector {
	boolean isValid(String column);
}
