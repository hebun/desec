package dynaInsert;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import arbitrage.SymbolPrice;
import util.Db;
import util.Sql;
import util.Sql.Insert;

public class DynaInsertDb {
	private ColumnSelector cs;

	public DynaInsertDb(ColumnSelector cs) {
		this.cs = cs;

	}

	public void insertJustSwap(List<SymbolPrice> jsp) {
		String backUrl = Db.DB_URL;
		Db.DB_URL = "jdbc:mysql://localhost:3306/crypto?useUnicode=true&characterEncoding=utf8";
		String tableName = "justswapspec";
		String sql = "SELECT COLUMN_NAME as col FROM INFORMATION_SCHEMA.COLUMNS		WHERE TABLE_NAME = N'" + tableName
				+ "'";

		List<Map<String, String>> cols = Db.selectTable(sql);
		Insert insert = new Sql.Insert(tableName);

		double btcbin = 0;
		for (SymbolPrice symbolPrice : jsp) {

			if (symbolPrice.getVolume() < 100000)
				continue;
			if (!cs.isValid(symbolPrice.getAddress()))
				continue;
			String symbol = symbolPrice.getSymbol().toUpperCase(Locale.US);

			if (!cols.stream().anyMatch(m -> m.get("col").equals(symbol))) {

				System.out.println(symbol + " doesnt exist in db");
				System.out.println("inserting new column");

				String sqlcol = "ALTER TABLE `" + tableName + "` ADD `" + symbol + "` FLOAT NULL AFTER `tarih`";
				Db.insert(sqlcol);
			}
			insert.add(symbol, symbolPrice.getPrice());

		}

		insert.run();
		Db.DB_URL =backUrl;
	}
}
