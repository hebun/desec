package fxcomps;

import java.util.function.Supplier;

import javax.swing.JFrame;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import javafx.application.Application;
import javafx.application.Platform;

import javafx.scene.Scene;
import javafx.stage.Stage;

import util.Pro;

public class FxLauncher {

	private Scene scene;

	public FxLauncher(Scene scene) {
		this.scene = scene;

	}

	public void launchFx(Supplier<Scene> supp, String title) {
		JFrame window = new JFrame();

		Platform.runLater(() -> {

			throw new RuntimeException("SwingFx integration launcher is not implemented");

		});
	}

}
