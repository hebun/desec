package fxcomps;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ObservableValueBase;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import util.Pro;
import util.Row;
import java.util.*;

public class Grid<T> extends TableView<T> {
	private Row columns;
	private Consumer<T> enter;
	String css = ".hide-header .column-header-background { \r\n" + "    visibility: hidden; -fx-padding: -1em;\r\n"
			+ "}";

	public Grid() {
		getStyleClass().add("hide-header");
	}

	public Grid(Row columns) {
		this.columns = columns;

	}
	@Override
	public void resize(double width, double height) {
		super.resize(width, height);
		Pane header = (Pane) lookup("TableHeaderRow");
		header.setMinHeight(0);
		header.setPrefHeight(0);
		header.setMaxHeight(0);
		header.setVisible(false);
	}
	public void setColumns(Row columns) {
		this.columns = columns;

	}

	public void editCell(String colid, BiConsumer<T, String> newValue) {

		Optional<TableColumn<T, ?>> findAny = this.getColumns().stream().filter(e -> e.getId().equals(colid)).findAny();

		if (findAny.isPresent()) {

			TableColumn<T, String> column = (TableColumn<T, String>) findAny.get();
			column.setEditable(true);
			column.setCellFactory(TextFieldTableCell.forTableColumn());

			column.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<T, String>>() {

				@Override
				public void handle(CellEditEvent<T, String> event) {

					newValue.accept(event.getRowValue(), event.getNewValue());

				}
			});
		}
	}

	public void setData(ObservableList<T> data) {

		Pro pro = new Pro("setdata");

		this.getColumns().clear();

		if (columns == null) {
//			columns = new Row();
//			for (Map.Entry<String, String> entry : data.get(0).entrySet()) {
//
//				columns.put(entry.getKey(), entry.getValue());
//
//			}

		}

		for (Map.Entry<String, String> map : columns.entrySet()) {

			TableColumn<T, String> col = new TableColumn<>(map.getValue());

			String key = map.getKey();
			if (key.equals("tarih")) {
				TableColumn<T, Date> cold = new TableColumn<>(map.getValue());
				cold.setCellFactory(column -> {
					TableCell<T, Date> cell = new TableCell<T, Date>() {
						private SimpleDateFormat format = new SimpleDateFormat("E, dd.MM HH:mm");

						@Override
						protected void updateItem(Date item, boolean empty) {
							super.updateItem(item, empty);

							if (item == null || empty) {
								setText(null);
							} else {
								setText(format.format(item));
							}
						}
					};

					return cell;
				});
				cold.setCellValueFactory(new PropertyValueFactory<T, Date>(key));
				cold.setId(map.getKey());
				this.getColumns().add(cold);
			} else {
				col.setCellValueFactory(new PropertyValueFactory<T, String>(key));

				col.setId(map.getKey());
				this.getColumns().add(col);
			}
		}

		if (data.size() == 0)
			return;

		this.setItems(data);
		this.addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {

				if (event.getCode() == KeyCode.ENTER) {
//	                  event.consume(); // don't consume the event or else the values won't be updated;
					return;
				}

				// switch to edit mode on keypress, but only if we aren't already in edit mode
				if (getEditingCell() == null) {
					if (event.getCode().isLetterKey() || event.getCode().isDigitKey()) {

						TablePosition focusedCellPosition = getFocusModel().getFocusedCell();
						edit(focusedCellPosition.getRow(), focusedCellPosition.getTableColumn());

					}
				}

			}
		});

	}

	public void onEnter(Consumer<T> enter) {
		this.enter = enter;
		this.setOnKeyPressed(event -> {
			if (event.getCode() == KeyCode.ENTER) {
				if (this.enter != null)
					enter.accept(this.getSelectionModel().getSelectedItem());
			}
		});
	}
}
