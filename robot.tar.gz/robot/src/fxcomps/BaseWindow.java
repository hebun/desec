package fxcomps;


import java.util.Optional;
import java.util.logging.Level;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Control;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.stage.Stage;
import util.MyLogger;
import util.Observable;
import util.Observer;
import util.hiber.Hiber;
import util.hiber.HiberFactory;
import util.hiber.HiberImpl;

public abstract class BaseWindow<T extends Region> implements Observable ,Observer {

	protected static MyLogger log = null;
	protected Stage stage;
	protected Scene scene;
	protected T rootNode;
	protected int width;
	protected int height;
	protected Hiber hib;

	static {
		if (log == null) {
			log = MyLogger.getInstance();
		}

	}

	public BaseWindow() {

		if (log == null) {
			log = MyLogger.getInstance();
		}
		
	}

	public Stage getStage() {
		if (this.stage == null) {
			this.stage = new Stage();
			stage.setScene(this.getScene());
		}
		return stage;
	}

	public Scene getScene() {
		if (this.scene == null) {
			scene = new Scene(getRootNode(), this.width, this.height);
		}
		return scene;
	}

	public void onShown() {

	}

	public T getRootNode() {
		if (rootNode == null) {
			throw new RuntimeException("rootnode is not initialized:" + this.getClass().getName());
		}
		return rootNode;
	}

	
}
